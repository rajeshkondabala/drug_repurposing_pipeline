from __future__ import annotations

from drugrepurposing.schemas.target import TargetRecord


def safety_risk_score(target: TargetRecord) -> float:
    n = len(target.safety_liabilities)
    if n == 0:
        return 0.0
    return min(1.0, 0.2 + 0.15 * n)


def tractability_score(target: TargetRecord) -> float:
    entries = (target.tractability or {}).get("entries") or []
    if not entries:
        return 0.3
    approved = any("Approved Drug" in str(item) or str(item.get("label", "")).lower() == "approved_drug" for item in entries if isinstance(item, dict) or True)
    if approved:
        return 0.9
    return 0.55 if entries else 0.3
