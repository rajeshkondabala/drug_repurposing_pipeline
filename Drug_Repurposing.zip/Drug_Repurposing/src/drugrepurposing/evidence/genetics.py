from __future__ import annotations

from drugrepurposing.schemas.target import DatatypeScore, TargetRecord


def genetic_score(target: TargetRecord) -> float:
    by_id = {item.id.lower(): item.score for item in target.datatype_scores}
    for key in ("genetic_association", "somatic_mutation", "genetic"):
        if key in by_id:
            return float(by_id[key])
    return 0.0


def datatype(target: TargetRecord, name: str) -> float:
    for item in target.datatype_scores:
        if item.id.lower() == name.lower():
            return float(item.score)
    return 0.0
