from __future__ import annotations

from collections import Counter

from drugrepurposing.schemas.evidence import EvidenceClass, LiteratureRecord


def literature_component_scores(records: list[LiteratureRecord], weights: dict[str, float]) -> dict[str, float]:
    if not records:
        return {key: 0.0 for key in weights}
    counts = Counter(item.evidence_class for item in records)
    total = max(len(records), 1)
    recency = sum(1 for item in records if item.is_recent) / total
    mapping = {
        "genetic": EvidenceClass.GENETIC,
        "human_clinical": EvidenceClass.HUMAN_CLINICAL,
        "human_observational": EvidenceClass.HUMAN_OBSERVATIONAL,
        "functional_cellular": EvidenceClass.FUNCTIONAL_CELLULAR,
        "animal": EvidenceClass.ANIMAL,
        "mechanistic_biochemical": EvidenceClass.MECHANISTIC_BIOCHEMICAL,
        "review_only": EvidenceClass.REVIEW_ONLY,
        "computational": EvidenceClass.COMPUTATIONAL,
    }
    scores: dict[str, float] = {}
    for key, klass in mapping.items():
        scores[key] = counts.get(klass, 0) / total
    scores["recency_bonus"] = recency
    weighted = 0.0
    weight_sum = 0.0
    for key, weight in weights.items():
        weighted += scores.get(key, 0.0) * weight
        weight_sum += weight
    scores["overall"] = weighted / weight_sum if weight_sum else 0.0
    # Publication count is recorded but not used as strength by itself.
    scores["publication_count"] = float(len(records))
    return scores
