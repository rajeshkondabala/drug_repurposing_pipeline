from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from drugrepurposing.schemas.disease import ProvenanceMixin


class EvidenceClass(str, Enum):
    GENETIC = "genetic evidence"
    HUMAN_CLINICAL = "human clinical evidence"
    HUMAN_OBSERVATIONAL = "human observational evidence"
    FUNCTIONAL_CELLULAR = "functional cellular evidence"
    ANIMAL = "animal evidence"
    MECHANISTIC_BIOCHEMICAL = "mechanistic biochemical evidence"
    REVIEW_ONLY = "review-only evidence"
    COMPUTATIONAL = "computational evidence"


class NoveltyCategory(str, Enum):
    ESTABLISHED = "established_target"
    CLINICALLY_ACTIVE = "clinically_active_target"
    PRECLINICAL = "preclinical_target"
    UNDERSTUDIED = "understudied_target"
    CANDIDATE_NOVEL = "candidate_novel_target"
    INSUFFICIENT = "insufficient_evidence"


class ClinicalPhase(str, Enum):
    PRECLINICAL = "preclinical"
    PHASE_1 = "phase_1"
    PHASE_1_2 = "phase_1_2"
    PHASE_2 = "phase_2"
    PHASE_2_3 = "phase_2_3"
    PHASE_3 = "phase_3"
    PHASE_4 = "phase_4"
    NOT_APPLICABLE = "not_applicable"
    UNKNOWN = "unknown"


class LiteratureRecord(ProvenanceMixin):
    pmid: str | None = None
    pmcid: str | None = None
    doi: str | None = None
    title: str | None = None
    year: int | None = None
    publication_type: str | None = None
    evidence_class: EvidenceClass = EvidenceClass.COMPUTATIONAL
    experimental_system: str | None = None
    tissue: str | None = None
    directionality: str | None = None
    is_review: bool = False
    is_recent: bool = False


class ClinicalTrialRecord(ProvenanceMixin):
    nct_id: str
    title: str | None = None
    intervention: str | None = None
    target_or_mechanism: str | None = None
    condition: str | None = None
    phase: ClinicalPhase = ClinicalPhase.UNKNOWN
    recruitment_status: str | None = None
    study_type: str | None = None
    participants: int | None = None
    sponsor: str | None = None
    primary_completion_date: str | None = None
    results_available: bool | None = None
    trial_url: str | None = None


class CompoundRecord(ProvenanceMixin):
    compound_id: str
    preferred_name: str | None = None
    synonyms: list[str] = Field(default_factory=list)
    smiles: str | None = None
    inchi: str | None = None
    inchikey: str | None = None
    molecular_formula: str | None = None
    molecular_weight: float | None = None
    mechanism_of_action: str | None = None
    target: str | None = None
    disease: str | None = None
    development_phase: str | None = None
    approval_status: str | None = None


class EvidenceGraphItem(BaseModel):
    type: str
    source_id: str
    source_url: str
    retrieved_at: str
    score: float | None = None
    license_or_terms: str | None = None


class TargetScoreBreakdown(BaseModel):
    symbol: str
    ensembl_id: str | None = None
    overall_score: float
    evidence_confidence: str
    data_completeness: float
    known_therapeutic_maturity: str
    novelty_category: NoveltyCategory
    components: dict[str, float]
    contributors: list[str] = Field(default_factory=list)
    limitations: list[str] = Field(default_factory=list)
    uncertainties: list[str] = Field(default_factory=list)
    strengths: list[str] = Field(default_factory=list)
    recommended_experimental_follow_up: list[str] = Field(default_factory=list)
    explanation: str
    evidence_graph: list[EvidenceGraphItem] = Field(default_factory=list)
    extra: dict[str, Any] = Field(default_factory=dict)
