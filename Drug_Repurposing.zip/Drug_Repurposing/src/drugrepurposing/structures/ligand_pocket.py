from __future__ import annotations

import math

from drugrepurposing.schemas.structure import PocketDefinition
from drugrepurposing.structures.search import ligand_priority
from drugrepurposing.structures.seqres import ParsedPDB


def heavy_atom_box(coords: list[tuple[float, float, float]], padding: float) -> tuple[tuple[float, float, float], tuple[float, float, float], float]:
    xs, ys, zs = zip(*coords)
    center = ((min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2, (min(zs) + max(zs)) / 2)
    size = (
        max(xs) - min(xs) + 2 * padding,
        max(ys) - min(ys) + 2 * padding,
        max(zs) - min(zs) + 2 * padding,
    )
    radius = math.sqrt(sum((d / 2) ** 2 for d in size))
    return center, size, radius


def detect_cocrystal_pockets(parsed: ParsedPDB, padding: float) -> list[PocketDefinition]:
    pockets: list[PocketDefinition] = []
    grouped: dict[tuple[str, str, int], list[tuple[float, float, float]]] = {}
    for het in parsed.hetatms:
        grouped.setdefault((het.name, het.chain, het.resseq), []).extend(het.coords)
    ranked = sorted(
        grouped.items(),
        key=lambda item: ligand_priority(item[0][0], len(item[1])),
        reverse=True,
    )
    for (name, chain, resseq), coords in ranked:
        if ligand_priority(name, len(coords)) < 0:
            continue
        center, size, radius = heavy_atom_box(coords, padding)
        nearby: list[str] = []
        chain_ids: set[str] = set()
        for residue in parsed.residues.values():
            if residue.hetero:
                continue
            if not residue.coords:
                continue
            cx = sum(p[0] for p in residue.coords) / len(residue.coords)
            cy = sum(p[1] for p in residue.coords) / len(residue.coords)
            cz = sum(p[2] for p in residue.coords) / len(residue.coords)
            dist = math.sqrt((cx - center[0]) ** 2 + (cy - center[1]) ** 2 + (cz - center[2]) ** 2)
            if dist <= radius:
                nearby.append(f"{residue.chain}:{residue.resseq}")
                chain_ids.add(residue.chain)
        warnings = []
        if len(chain_ids) > 1:
            warnings.append("Pocket contacts multiple chains; interface pocket possible.")
        pockets.append(
            PocketDefinition(
                pocket_id=f"{name}_{chain}_{resseq}",
                method="cocrystal_ligand_box",
                ligand_resname=name,
                ligand_chain=chain,
                ligand_residue_number=resseq,
                residue_ids=nearby,
                center=center,
                dimensions=size,
                radius=radius,
                experimental=True,
                warnings=warnings,
            )
        )
    return pockets
