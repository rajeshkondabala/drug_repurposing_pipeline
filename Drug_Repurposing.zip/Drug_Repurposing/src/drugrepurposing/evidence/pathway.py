from __future__ import annotations

from drugrepurposing.evidence.genetics import datatype
from drugrepurposing.schemas.target import TargetRecord


def mechanistic_score(target: TargetRecord) -> float:
    pathway = datatype(target, "affected_pathway")
    literature = datatype(target, "literature")
    rna = datatype(target, "rna_expression")
    return min(1.0, 0.5 * pathway + 0.3 * literature + 0.2 * rna)
