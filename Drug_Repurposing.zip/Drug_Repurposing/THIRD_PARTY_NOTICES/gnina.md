GNINA is a user-supplied executable and is not bundled.

Published descriptions of GNINA note mixed Apache and GPL components,
with GPL historically associated with Open Babel. The exact licensing of
a given binary depends on how it was built, which libraries and CNN
models are included, and which notices ship with it.

This project does not assert that any particular GNINA binary is
commercially redistributable.
