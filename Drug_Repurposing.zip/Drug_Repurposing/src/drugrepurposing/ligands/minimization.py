from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import LigandsCfg
from drugrepurposing.schemas.ligand import LigandIssue, LigandRecord


def minimize_sdf(record: LigandRecord, cfg: LigandsCfg, dest_sdf: Path) -> LigandRecord:
    from rdkit import Chem  # type: ignore
    from rdkit.Chem import AllChem  # type: ignore

    if not record.sdf_path:
        record.issues.append(LigandIssue(code="no_3d", message="No 3D coordinates to minimize"))
        return record
    suppl = Chem.SDMolSupplier(record.sdf_path, removeHs=False)
    mol = next((item for item in suppl if item is not None), None)
    if mol is None:
        record.issues.append(LigandIssue(code="sdf_read", message="Could not read SDF for minimization"))
        return record
    ff_name = cfg.minimization_force_field.upper()
    record.force_field = ff_name
    record.preparation_manifest["minimization"] = (
        "Force-field minimization (not quantum-chemical optimization)."
    )
    energy_before = None
    energy_after = None
    converged = False
    try:
        if ff_name.startswith("MMFF"):
            props = AllChem.MMFFGetMoleculeProperties(mol, mmffVariant="MMFF94s" if "94S" in ff_name else "MMFF94")
            if props is None:
                raise ValueError("MMFF parameters unavailable")
            ff = AllChem.MMFFGetMoleculeForceField(mol, props)
        else:
            ff = AllChem.UFFGetMoleculeForceField(mol)
            record.force_field = "UFF"
        if ff is None:
            raise ValueError("No force field")
        energy_before = ff.CalcEnergy()
        result = ff.Minimize(maxIts=cfg.max_iterations)
        energy_after = ff.CalcEnergy()
        converged = result == 0
        if not converged:
            record.issues.append(
                LigandIssue(code="min_unconverged", message="Minimization did not fully converge", severity="warning")
            )
    except Exception as exc:
        record.issues.append(LigandIssue(code="min_failed", message=f"Minimization failed: {exc}"))
        try:
            ff = AllChem.UFFGetMoleculeForceField(mol)
            if ff:
                energy_before = ff.CalcEnergy()
                ff.Minimize(maxIts=cfg.max_iterations)
                energy_after = ff.CalcEnergy()
                record.force_field = "UFF"
                record.issues.append(LigandIssue(code="uff_fallback", message="Fell back to UFF", severity="warning"))
        except Exception as exc2:
            record.issues.append(LigandIssue(code="min_failed", message=f"UFF fallback failed: {exc2}"))
            return record
    record.energy_before = energy_before
    record.energy_after = energy_after
    dest_sdf.parent.mkdir(parents=True, exist_ok=True)
    writer = Chem.SDWriter(str(dest_sdf))
    writer.write(mol)
    writer.close()
    record.sdf_path = str(dest_sdf)
    return record
