RDKit — BSD-3-Clause
https://github.com/rdkit/rdkit/blob/master/license.txt
