from __future__ import annotations

from drugrepurposing.config import AppConfig
from drugrepurposing.schemas.evidence import LiteratureRecord
from drugrepurposing.sources.europe_pmc import classify_publication
from drugrepurposing.utils.http import HttpClient, HttpError


class PubMedClient:
    def __init__(self, config: AppConfig, http: HttpClient) -> None:
        self.config = config
        self.http = http
        self.base = config.sources.pubmed.base_url or (
            "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
        )

    def search_ids(self, query: str, retmax: int = 20) -> list[str]:
        if not self.config.sources.pubmed.enabled:
            return []
        params: dict[str, str | int] = {
            "db": "pubmed",
            "term": query,
            "retmode": "json",
            "retmax": retmax,
        }
        if self.config.sources.pubmed.api_key:
            params["api_key"] = self.config.sources.pubmed.api_key
        try:
            envelope = self.http.request_json(
                "GET",
                f"{self.base}/esearch.fcgi",
                params=params,
                namespace="literature",
                source_name="PubMed",
                license_or_terms="NLM terms; attribution required",
            )
        except HttpError:
            return []
        return list(envelope.get("payload", {}).get("esearchresult", {}).get("idlist") or [])

    def summarize(self, pmids: list[str]) -> list[LiteratureRecord]:
        if not pmids or not self.config.sources.pubmed.enabled:
            return []
        try:
            envelope = self.http.request_json(
                "GET",
                f"{self.base}/esummary.fcgi",
                params={"db": "pubmed", "id": ",".join(pmids), "retmode": "json"},
                namespace="literature",
                source_name="PubMed",
                license_or_terms="NLM terms; attribution required",
            )
        except HttpError:
            return []
        result = envelope.get("payload", {}).get("result", {})
        records: list[LiteratureRecord] = []
        for pmid in pmids:
            item = result.get(pmid) or {}
            title = item.get("title") or ""
            pub_types = ",".join(item.get("pubtype") or [])
            klass, is_review = classify_publication(title, pub_types)
            year = None
            date = item.get("pubdate") or ""
            if date[:4].isdigit():
                year = int(date[:4])
            records.append(
                LiteratureRecord(
                    source_name="PubMed",
                    source_url=f"https://pubmed.ncbi.nlm.nih.gov/{pmid}",
                    accessed_at=envelope["accessed_at"],
                    query=pmid,
                    raw_record_hash=envelope.get("raw_record_hash"),
                    license_or_terms=envelope.get("license_or_terms"),
                    pmid=pmid,
                    doi=None,
                    title=title,
                    year=year,
                    publication_type=pub_types or None,
                    evidence_class=klass,
                    is_review=is_review,
                )
            )
        return records
