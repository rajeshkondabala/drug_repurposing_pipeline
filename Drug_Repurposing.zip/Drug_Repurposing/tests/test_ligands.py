from __future__ import annotations

from pathlib import Path

import pytest

from drugrepurposing.config import load_config
from drugrepurposing.ligands.conformers import sdf_has_3d
from drugrepurposing.ligands.io import load_ligand_table
from drugrepurposing.ligands.minimization import minimize_sdf
from drugrepurposing.ligands.standardization import standardize_record
from drugrepurposing.ligands.validation import detect_duplicate_inchikeys
from drugrepurposing.schemas.ligand import LigandRecord

rdkit = pytest.importorskip("rdkit")
from rdkit import Chem  # noqa: E402
from rdkit.Chem import AllChem  # noqa: E402


def test_smiles_validation_and_duplicates(tmp_path: Path):
    csv_path = tmp_path / "lig.csv"
    csv_path.write_text("compound_id,smiles,name\nA,CCO,e\nB,not_a_smiles,x\nA,CCN,dup\n", encoding="utf-8")
    cfg = load_config().ligands
    records = load_ligand_table(csv_path, cfg)
    assert any(i.code == "duplicate_id" for i in records[2].issues)
    bad = standardize_record(records[1], cfg)
    assert any(i.code == "invalid_smiles" for i in bad.issues)
    good = standardize_record(records[0], cfg)
    assert good.canonical_smiles
    good2 = standardize_record(
        LigandRecord(compound_id="C", smiles="CCO", input_format="smi"), cfg
    )
    duped = detect_duplicate_inchikeys([good, good2])
    assert any(i.code == "duplicate_inchikey" for rec in duped for i in rec.issues)


def test_sdf_2d_vs_3d(tmp_path: Path):
    mol = Chem.MolFromSmiles("CCO")
    sdf2d = tmp_path / "two.sdf"
    w = Chem.SDWriter(str(sdf2d))
    w.write(mol)
    w.close()
    mol2 = Chem.SDMolSupplier(str(sdf2d), removeHs=False)[0]
    assert sdf_has_3d(mol2) is False
    mol3 = Chem.AddHs(Chem.MolFromSmiles("CCO"))
    AllChem.EmbedMolecule(mol3, randomSeed=42)
    sdf3d = tmp_path / "three.sdf"
    w = Chem.SDWriter(str(sdf3d))
    w.write(mol3)
    w.close()
    mol3b = Chem.SDMolSupplier(str(sdf3d), removeHs=False)[0]
    assert sdf_has_3d(mol3b) is True


def test_minimization_failure(tmp_path: Path):
    rec = LigandRecord(compound_id="x", smiles="CCO", input_format="smi")
    rec.sdf_path = None
    out = minimize_sdf(rec, load_config().ligands, tmp_path / "m.sdf")
    assert any(i.code == "no_3d" for i in out.issues)
