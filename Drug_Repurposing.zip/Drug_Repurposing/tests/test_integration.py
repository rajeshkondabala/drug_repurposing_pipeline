from __future__ import annotations

import json
from pathlib import Path

import pytest

from drugrepurposing.config import load_config
from drugrepurposing.docking.gnina_runner import run_gnina
from drugrepurposing.evidence.target_scoring import score_target
from drugrepurposing.provenance import ProvenanceTracker
from drugrepurposing.reports.html import write_html_report
from drugrepurposing.reports.json_report import write_json_report
from drugrepurposing.reports.pdb_export import export_pose_files
from drugrepurposing.reports.tables import write_csv_reports, write_license_report
from drugrepurposing.schemas.ligand import LigandRecord
from drugrepurposing.schemas.structure import PocketDefinition, StructureRecord
from drugrepurposing.schemas.target import TargetIdentifiers, TargetRecord
from drugrepurposing.store import WorkflowState
from drugrepurposing.workflows import ProjectWorkspace

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.mark.integration
def test_offline_mini_project(tmp_path: Path, monkeypatch):
    cfg = load_config()
    cfg.cache.offline = True
    ws = ProjectWorkspace(tmp_path / "proj")
    prov = ProvenanceTracker(ws.root, cfg)
    target = TargetRecord(
        source_name="Open Targets Platform",
        source_url="https://api.platform.opentargets.org/api/v4/graphql",
        identifiers=TargetIdentifiers(
            ensembl_gene_id="ENSG00000160712",
            approved_symbol="IL6R",
            uniprot_accessions=["P08887"],
        ),
        association_score=0.82,
    )
    score = score_target(
        target,
        weights=cfg.scoring["weights"],
        literature_weights=cfg.scoring["literature_components"],
        novelty_cfg=cfg.scoring["novelty"],
        literature=[],
        trials=[],
        drugs=[],
        search_succeeded=True,
        condition_id="EFO_0000685",
    )
    ws.write_json(
        "targets/condition_resolution.json",
        {
            "input_condition": "rheumatoid arthritis",
            "selected_condition": {"id": "EFO_0000685", "name": "Rheumatoid arthritis", "synonyms": [], "ontology": "EFO"},
            "alternatives": [],
        },
    )
    ws.write_json("targets/targets.json", [target.model_dump(mode="json")])
    ws.write_json("targets/scores.json", [score.model_dump(mode="json")])
    ws.write_json("targets/drugs.json", [])
    struct_dir = ws.root / "structures" / "IL6R"
    struct_dir.mkdir(parents=True)
    pdb = struct_dir / "repaired.pdb"
    pdb.write_text((FIXTURES / "mini.pdb").read_text(encoding="utf-8"), encoding="utf-8")
    structure = StructureRecord(
        source_name="RCSB PDB",
        source_url="https://www.rcsb.org/structure/1ABC",
        pdb_id="1ABC",
        target_symbol="IL6R",
        file_path=str(pdb),
        pockets=[
            PocketDefinition(
                pocket_id="LIG_A_101",
                method="cocrystal_ligand_box",
                center=(2.5, 2.0, 2.0),
                dimensions=(12.0, 12.0, 12.0),
                experimental=True,
            )
        ],
    )
    ws.write_json("structures/selected.json", [structure.model_dump(mode="json")])
    lig_dir = ws.root / "ligands"
    lig_dir.mkdir(exist_ok=True)
    ligands = [
        LigandRecord(compound_id="TOFA", smiles="CCO", input_format="smi", pdbqt_path=str(lig_dir / "TOFA.pdbqt")),
        LigandRecord(compound_id="MTX", smiles="CCN", input_format="smi", pdbqt_path=str(lig_dir / "MTX.pdbqt")),
    ]
    for lig in ligands:
        Path(lig.pdbqt_path).write_text("REMARK ligand\n", encoding="utf-8")
    ws.write_json("ligands/ligands.json", [l.model_dump(mode="json") for l in ligands])

    gnina_bin = tmp_path / "gnina"
    gnina_bin.write_text("#!/bin/sh\necho gnina 1.0\n", encoding="utf-8")
    gnina_bin.chmod(0o755)

    def fake_run(gnina, receptor, ligand, output, box, cfg, log_dir):
        log_dir.mkdir(parents=True, exist_ok=True)
        output.write_text((FIXTURES / "gnina_out.sdf").read_text(encoding="utf-8"), encoding="utf-8")
        from drugrepurposing.schemas.docking import DockingRun

        return DockingRun(
            receptor_path=str(receptor),
            ligand_path=str(ligand),
            command=[str(gnina)],
            exit_code=0,
            gnina_version="gnina 1.0",
        )

    monkeypatch.setattr("drugrepurposing.workflows.docking_workflow.validate_gnina", lambda p: "gnina 1.0")
    monkeypatch.setattr("drugrepurposing.workflows.docking_workflow.run_gnina", fake_run)
    def fake_prep(receptor, dest):
        dest.write_text("REMARK receptor\n", encoding="utf-8")
        return dest, {"backend": "mock"}

    monkeypatch.setattr("drugrepurposing.workflows.docking_workflow.prepare_receptor_pdbqt", fake_prep)

    from drugrepurposing.workflows.docking_workflow import dock_project

    poses = dock_project(cfg, ws, prov, gnina_path=str(gnina_bin))
    assert poses
    write_csv_reports(ws, cfg)
    write_json_report(ws, cfg, prov)
    write_html_report(ws, cfg, prov)
    write_license_report(ws, cfg)
    prov.set_status(WorkflowState.REPORT_GENERATED.value)
    prov.write()
    html = (ws.root / "reports" / "report.html").read_text(encoding="utf-8")
    assert "hypothesis generation" in html.lower()
    assert (ws.root / "reports" / "targets.csv").exists()
    assert (ws.root / "reports" / "docking_results.csv").exists()
    assert (ws.root / "provenance.json").exists()
    export_pose_files(poses[0], pdb, FIXTURES / "gnina_out.sdf", ws.root / "docking" / "export")
    assert (ws.root / "docking" / "export" / "best_pose.pdb").exists()
