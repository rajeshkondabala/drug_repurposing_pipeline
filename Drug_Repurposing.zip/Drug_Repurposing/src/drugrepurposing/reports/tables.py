from __future__ import annotations

import csv
from pathlib import Path

from drugrepurposing.config import AppConfig
from drugrepurposing.workflows import ProjectWorkspace


def _write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_csv_reports(workspace: ProjectWorkspace, config: AppConfig) -> None:
    reports = workspace.root / "reports"
    scores = workspace.read_json("targets/scores.json") or []
    _write_csv(
        reports / "targets.csv",
        [
            {
                "symbol": s.get("symbol"),
                "ensembl_id": s.get("ensembl_id"),
                "overall_score": s.get("overall_score"),
                "evidence_confidence": s.get("evidence_confidence"),
                "data_completeness": s.get("data_completeness"),
                "novelty_category": s.get("novelty_category"),
                "maturity": s.get("known_therapeutic_maturity"),
            }
            for s in scores
        ],
    )
    _write_csv(
        reports / "novel_targets.csv",
        [
            {
                "symbol": s.get("symbol"),
                "novelty_category": s.get("novelty_category"),
                "overall_score": s.get("overall_score"),
                "note": "Candidate novel or understudied based on searched sources and analysis date.",
            }
            for s in scores
            if s.get("novelty_category") in {"candidate_novel_target", "understudied_target"}
        ],
    )
    evidence_rows = []
    for s in scores:
        comps = s.get("components") or {}
        row = {"symbol": s.get("symbol"), **comps}
        evidence_rows.append(row)
    _write_csv(reports / "target_evidence.csv", evidence_rows)
    structures = workspace.read_json("structures/selected.json") or []
    _write_csv(
        reports / "structures.csv",
        [
            {
                "pdb_id": item.get("pdb_id"),
                "chain_id": item.get("chain_id"),
                "experimental_method": item.get("experimental_method"),
                "resolution": item.get("resolution"),
                "ligand_ids": ",".join(item.get("ligand_ids") or []),
                "structure_score": item.get("structure_score"),
                "selection_reason": item.get("selection_reason"),
                "predicted": item.get("predicted"),
            }
            for item in structures
        ],
    )
    pocket_rows = []
    for item in structures:
        for pocket in item.get("pockets") or []:
            pocket_rows.append(
                {
                    "structure": item.get("pdb_id") or item.get("alphafold_id"),
                    "pocket_id": pocket.get("pocket_id"),
                    "method": pocket.get("method"),
                    "center": pocket.get("center"),
                    "experimental": pocket.get("experimental"),
                }
            )
    _write_csv(reports / "pockets.csv", pocket_rows)
    ligands = workspace.read_json("ligands/ligands.json") or []
    _write_csv(
        reports / "ligands.csv",
        [
            {
                "compound_id": item.get("compound_id"),
                "smiles": item.get("canonical_smiles") or item.get("smiles"),
                "inchikey": item.get("inchikey"),
                "force_field": item.get("force_field"),
                "energy_after": item.get("energy_after"),
            }
            for item in ligands
        ],
    )
    poses = workspace.read_json("docking/poses.json") or []
    _write_csv(
        reports / "docking_results.csv",
        [
            {
                "ligand_id": p.get("ligand_id"),
                "structure_id": p.get("structure_id"),
                "pocket_id": p.get("pocket_id"),
                "pose_rank": p.get("pose_rank"),
                "vina_score": p.get("vina_score"),
                "cnn_score": p.get("cnn_score"),
                "cnn_affinity": p.get("cnn_affinity"),
                "final_pose_score": p.get("final_pose_score"),
                "note": p.get("score_note"),
            }
            for p in poses
        ],
    )
    cross_rows = []
    for target in workspace.read_json("targets/targets.json") or []:
        symbol = (target.get("identifiers") or {}).get("approved_symbol")
        for item in target.get("cross_condition") or []:
            cross_rows.append({"symbol": symbol, **item})
    _write_csv(reports / "cross_condition_targets.csv", cross_rows)
    _ = config


def write_license_report(workspace: ProjectWorkspace, config: AppConfig) -> Path:
    rows = []
    software = (config.licenses or {}).get("software_dependencies") or {}
    data = (config.licenses or {}).get("data_sources") or {}
    for name, meta in software.items():
        rows.append(
            {
                "kind": "software",
                "name": name,
                "license": meta.get("license"),
                "classification": meta.get("classification"),
                "notes": meta.get("notes") or "",
            }
        )
    for name, meta in data.items():
        rows.append(
            {
                "kind": "data",
                "name": name,
                "license": meta.get("data_license") or meta.get("license"),
                "classification": meta.get("classification"),
                "notes": meta.get("notes") or "",
            }
        )
    path = workspace.root / "reports" / "license_report.csv"
    _write_csv(path, rows)
    return path
