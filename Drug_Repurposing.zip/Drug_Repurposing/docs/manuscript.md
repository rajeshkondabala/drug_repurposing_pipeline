# drug-repurposing: a license-aware, evidence-first platform for computational drug-repurposing hypotheses

**Manuscript type:** Software / methods article  
**Status:** Draft for journal submission. Replace bracketed fields before submission. Docking of the curated ligand library was not completed and is not reported as a result.

**Suggested venues:** *Journal of Cheminformatics*; *Bioinformatics* (Application Note); *BMC Bioinformatics*.

---

## Title

drug-repurposing: an open, license-aware workflow that keeps target-evidence ranking separate from molecular docking

## Authors

[Author list, affiliations, ORCID, and corresponding author email to be completed by the submitting group.]

## Abstract

**Background.** Computational drug-repurposing studies often collapse heterogeneous target evidence and docking scores into a single rank. That practice hides uncertainty, mixes incompatible licenses, and can be misread as a therapeutic recommendation.

**Results.** We describe *drug-repurposing* (version 0.1.1), an Apache-2.0 command-line platform for research hypothesis generation. The workflow resolves a disease in the Open Targets Platform, retrieves literature, trial, and known-drug context from public sources, and ranks targets with an explicit weighted evidence score. A separate, optional stage prepares experimental protein structures (with AlphaFold coordinates only when no suitable experimental model is available) and user-supplied ligands, then docks them with a user-supplied GNINA binary. Evidence scores and docking scores are stored in different tables and are never combined. Restricted databases (DrugBank, BindingDB, DrugCentral, Semantic Scholar) are disabled by default. Copyleft docking helpers (Meeko, pyKVFinder) are optional extras, and GNINA is not distributed with the package.

As a reproducibility check on a well-studied disease, we ranked targets for rheumatoid arthritis (MONDO:0008383) using cached public APIs on 6 October 2026. The top 25 targets were all labelled *established* in the searched sources. Interleukin-6 receptor (IL6R) had the highest evidence score (0.701). A locally curated ChEMBL parent-molecule table was reduced from 10,991 to 10,787 structures for optional docking; that screen was not finished and no docking enrichment is claimed.

**Conclusions.** The software is suitable for transparent, source-attributed hypothesis generation. It does not establish efficacy, safety, or clinical suitability of any target or compound.

**Keywords:** drug repurposing; target prioritization; Open Targets; molecular docking; GNINA; provenance; research software

## 1. Introduction

Drug repurposing seeks new uses for compounds that already have some chemical, pharmacological, or clinical history [1]. Public resources now cover target–disease associations, genetics, literature, trials, protein structures, and bioactive molecules [2–7]. Pipelines that query these resources are common, but three problems recur.

First, evidence of different kinds is often multiplied with a docking score to produce one “repurposing score.” Association, trial phase, and a physics-based or learned docking score answer different questions. Merging them conceals which evidence moved the rank and encourages over-interpretation of poses.

Second, redistribution is constrained by license. ChEMBL content is CC BY-SA 3.0 [5]. Several cheminformatics tools used for pocket detection or ligand preparation are GPL or LGPL. Some GNINA builds link components whose redistribution terms are not uniform [8]. A package that vendors those pieces, or that ships a large ChEMBL extract under an Apache-2.0 claim, is not a clean source release.

Third, software papers and internal scripts often omit the retrieval date, query, and the statement that a “novel target” label is conditional on the sources that were actually searched.

*drug-repurposing* was built to address those three points for research use. It is not a diagnostic device and does not recommend treatment.

## 2. Implementation

### 2.1 Software design

The package is Python 3.11 software (`drugrepurposing`) with a Typer command-line interface (`drug-repurposing`). Configuration is YAML (Pydantic v2). HTTP calls use timeouts, exponential back-off for transport errors and HTTP 5xx responses, and a content-addressed cache. HTTP 4xx responses are not retried. Each project directory stores provenance (package version, config hash, source URLs, license notes, and warnings) and CSV/JSON/HTML reports.

The workflow states are: condition resolved, targets ranked, structures prepared, ligands prepared, docking completed, and report generated. Commands can be re-run; finished structure and ligand files are reused.

Core installation is a conda-forge environment (RDKit, PDBFixer, OpenMM, and the HTTP/reporting stack). Meeko (LGPL-2.1) and pyKVFinder (GPL-3.0) are not installed by the core environment file. GNINA is never bundled; the user passes `--gnina-path` or a local, untracked config overlay.

### 2.2 Disease and target evidence

A free-text condition is searched in the Open Targets Platform GraphQL API (v4). If several diseases match, the user must confirm an identifier; a unique match can be selected automatically. For the demonstration we fixed rheumatoid arthritis as MONDO:0008383.

For each associated target, up to a configured maximum (25 in the demonstration), the client records the Open Targets association and datatype scores, baseline expression when returned, and known drugs or clinical candidates. Europe PMC and ClinicalTrials.gov supply literature and trial context. Queries, access times, and license notes are written into the provenance record.

The evidence score \(S\) is a weighted sum of components in \([0,1]\), minus penalties:

\[
\begin{align*}
S ={}& 0.22\,S_{\mathrm{assoc}} + 0.16\,S_{\mathrm{gen}} + 0.12\,S_{\mathrm{lit}} + 0.14\,S_{\mathrm{clin}}\\
&+ 0.12\,S_{\mathrm{drug}} + 0.08\,S_{\mathrm{mech}} + 0.08\,S_{\mathrm{tract}} + 0.06\,S_{\mathrm{tissue}}\\
&- 0.10\,S_{\mathrm{safety}} - 0.08\,S_{\mathrm{conflict}} - 0.06\,S_{\mathrm{incomplete}}.
\end{align*}
\]

Literature weight is not raw publication count. It mixes evidence classes (genetic, human clinical, observational, cellular, animal, biochemical, review, computational) with a small recency term. Clinical phase contributes to \(S_{\mathrm{clin}}\) but a trial’s existence is not treated as evidence of success. Weights are in `configs/scoring.yaml` and are hashed into provenance.

Novelty labels are `established_target`, `clinically_active_target`, `preclinical_target`, `understudied_target`, `candidate_novel_target`, or `insufficient_evidence`. The candidate-novel label requires association or mechanistic support, more than one independent source, completeness above a threshold, successful searches, and no phase 3/4 program in the sources that were queried. The stored sentence is: “Candidate novel or understudied target based on the searched sources and date of analysis.” Confidence is high only when \(S \ge 0.7\) and completeness is at least 0.6; otherwise it is moderate or low.

Docking scores are excluded from \(S\).

### 2.3 Structures

When docking is requested, the platform walks the evidence-ranked list until `max_prepared_targets` structures are prepared (default 5). For each target it searches the RCSB PDB by UniProt accession [6], ranks experimental entries by a weighted structure score (sequence mapping, experimental method, co-crystal ligand, resolution, pocket completeness, missing residues, mutations, and oligomer context), and downloads coordinates. Resolution is one term, not the only criterion. Entries above a resolution cutoff (4.0 Å in the default configuration) are dropped before ranking.

If the legacy PDB file returns HTTP 404 or 410, the mmCIF file is downloaded and converted to PDB with Biopython. If that conversion or later repair fails, the entry is skipped and the next ranked experimental model is tried. AlphaFold Database coordinates [7] are used only when no usable experimental structure remains and predicted models are allowed. Pockets from co-crystal ligands are preferred. Computational pockets are labelled as such. PDBFixer/OpenMM may add missing atoms; long internal gaps are not treated as experimental density. Orphan `TER` records that break the PDB parser are removed before repair.

### 2.4 Ligands

Ligand tables use columns `compound_id`, `smiles`, and `name`. SMILES are parsed with RDKit, salts are stripped, the largest organic fragment is kept, and a canonical isomeric SMILES and InChIKey are stored. Stereochemistry is preserved. Invalid SMILES, radicals, molecules with fewer than three heavy atoms, molecules without carbon, and elements outside a defined organic set (plus arsenic) are rejected. Duplicate InChIKeys after salt stripping keep the first identifier.

For a local ChEMBL parent-molecule export (not part of the Apache-2.0 source tree), this filter retained 10,787 of 10,991 rows. Rejections were duplicate structures after salt stripping (120), molecules without carbon (49), disallowed elements (19), too few heavy atoms (14), and radicals (2). Because ChEMBL data are CC BY-SA 3.0, the cleaned table is generated by the user and is not shipped in the source distribution.

Conformers use ETKDGv3 with a fixed seed. Minimization uses MMFF94s when parameters exist, otherwise UFF. Finished SDF files are skipped on restart.

### 2.5 Docking

Docking calls GNINA through `subprocess` with an argument list (no shell). The box comes from the selected pocket. Default demonstration settings in the example config were exhaustiveness 8, nine modes, CNN rescoring, and a fixed seed; the software defaults are exhaustiveness 16 and 20 modes. For GNINA builds whose version string contains `rdkit`, the ligand is an SDF and the receptor is a PDB, avoiding AutoDock atom types that those builds reject. Pose tables record Vina-like score, CNN score, and CNN affinity. A pose rank may combine those terms with geometry and clash penalties, but that rank is not multiplied by \(S\). Reports state that these values are computational scores, not binding free energies.

### 2.6 What is deliberately omitted

DrugBank, BindingDB, DrugCentral, and Semantic Scholar are off unless a user enables them after their own license review. Open Babel is not installed. The package does not claim that a particular GNINA binary may be redistributed.

## 3. Results

### 3.1 Rheumatoid arthritis evidence ranking

On 6 October 2026 we ran evidence-only mode (`--skip-docking`) for “rheumatoid arthritis” with disease identifier MONDO:0008383. API responses were served from the local content-addressed cache of earlier queries to Open Targets, Europe PMC, and ClinicalTrials.gov. Twenty-five targets were ranked (Table 1). All 25 were labelled `established_target`. One target, IL6R, had high evidence confidence; four targets (PTGS2, NR3C1, DHFR, PTGS1) had low confidence because their scores were below 0.4. The remainder were moderate. No target met the candidate-novel rule. That pattern is expected for rheumatoid arthritis, which already has multiple approved mechanisms, and it functions as a sanity check of the labeler rather than as a discovery claim.

**Table 1.** Top ten evidence scores for rheumatoid arthritis (MONDO:0008383), 6 October 2026. Scores are unitless weighted sums, not probabilities of clinical success.

| Rank | Symbol | Ensembl gene | Evidence score | Confidence | Completeness | Novelty label |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | IL6R | ENSG00000160712 | 0.701 | high | 1.00 | established |
| 2 | JAK1 | ENSG00000162434 | 0.690 | moderate | 1.00 | established |
| 3 | CD40 | ENSG00000101017 | 0.663 | moderate | 1.00 | established |
| 4 | CTLA4 | ENSG00000163599 | 0.614 | moderate | 1.00 | established |
| 5 | TYK2 | ENSG00000105397 | 0.601 | moderate | 0.875 | established |
| 6 | IL12B | ENSG00000113302 | 0.586 | moderate | 0.875 | established |
| 7 | JAK2 | ENSG00000096968 | 0.585 | moderate | 1.00 | established |
| 8 | MIF | ENSG00000240972 | 0.577 | moderate | 0.875 | established |
| 9 | PADI4 | ENSG00000159339 | 0.573 | moderate | 0.875 | established |
| 10 | PTPN22 | ENSG00000134242 | 0.560 | moderate | 0.875 | established |

The full 25-row table is `outputs/ra_chembl_evidence/reports/targets.csv` in the demonstration project. IL6R is the only high-confidence row. JAK1 is second by score but remains moderate confidence under the published rule (\(S < 0.7\)).

### 3.2 Structure preparation observed during docking setup

A subsequent run that requested docking resumed or prepared experimental structures for the first targets that yielded a usable model: TYK2 (PDB 3LXP), IL6R (PDB 1N26), IL12B (PDB 3D85), TNF (PDB 2AZ5), and JAK1 (PDB 4GS0). PDB 10PI was not used: the PDB-format file was absent (HTTP 404) and the converted coordinate file was not accepted by PDBFixer, so the workflow continued to a later JAK1 entry. These identifications document software behaviour. They are not a claim that 4GS0, 1N26, or 3LXP is the single best therapeutic structure, and they are not paired with docking results in this manuscript.

### 3.3 Docking

Docking of the 10,787-compound curated set against the prepared receptors was started and then stopped during ligand preparation. No pose table, enrichment, or hit list is reported. Publishing such numbers would require a finished, archived GNINA run with version, seed, and box parameters in provenance.

## 4. Discussion

The rheumatoid arthritis ranking recovers mechanisms that are already central in the disease: IL-6 receptor signalling, JAK and TYK2 kinases, TNF, co-stimulation (CTLA4, CD80, CD86), and IL-12/23 subunits [9]. Recovery of established biology supports the evidence layer. It does not show that the weights are optimal, transportable to rare diseases, or a substitute for genetics and experiments.

Separating \(S\) from docking is the main design choice. A low docking score on an established target, or a favourable score on a weakly evidenced target, stays visible as two facts. Users who want a joint view can join the tables themselves and must then justify the join.

License boundaries are part of the scientific method here, not only a legal appendix. A result that cannot be regenerated without a redistributable prohibited database is a weaker methods claim. The implementation therefore prefers runtime retrieval of CC0 or CC BY resources and leaves share-alike compound tables outside the source tree.

Several limits follow. Open Targets association scores are themselves aggregates; this platform does not re-derive them from raw GWAS summary statistics. Literature classification is incomplete relative to manual systematic review. Structure choice is sensitive to UniProt mapping, resolution cutoffs, and co-crystal ligands that may occupy an allosteric or crystallographic site rather than the site of interest. PDBFixer repairs are model coordinates. GNINA CNN scores depend on the binary and model files the user supplies. The demonstration cache means the 6 October 2026 ranking reflects the cached API payloads, not a guarantee that a live query on another day returns the same 25 genes.

## 5. Conclusions

*drug-repurposing* 0.1.1 is research software for disease-to-target evidence ranking, optional structure preparation, and optional GNINA docking, with provenance and with docking kept out of the evidence score. On rheumatoid arthritis it labelled the top 25 targets as established, with IL6R highest. A curated 10,787-compound ligand table is supported as input, but a docking campaign using that table is future work. The outputs are hypotheses for experimental follow-up, not clinical recommendations.

## Declarations

**Ethics approval and consent to participate.** Not applicable. The study used public computational data and did not enrol human participants.

**Consent for publication.** Not applicable.

**Availability of data and materials.** Platform source code is Apache-2.0 and is available from the authors’ repository [URL to be added upon release]. Demonstration evidence tables for MONDO:0008383 are produced by the command in Section 6. The ChEMBL-derived ligand file is not included in the source distribution; users must obtain ChEMBL data under CC BY-SA 3.0 and may run `scripts/clean_chembl_ligands.py`. Open Targets, RCSB PDB, AlphaFold DB, UniProt, Europe PMC, PubMed, ClinicalTrials.gov, and ChEMBL remain subject to their own terms.

**Competing interests.** The authors declare that they have no competing interests. [Edit if untrue.]

**Funding.** [Funding statement, or “No specific funding was received for this work.”]

**Authors’ contributions.** [CRediT roles.]

**Acknowledgements.** We thank the maintainers of the public resources listed above. GNINA was used as a locally built executable and is not part of this distribution.

## 6. Reproducing the evidence table

```bash
conda env create -f environment.yml
conda activate drug-repurposing
python -m pip install -e .
drug-repurposing run \
  --condition "rheumatoid arthritis" \
  --select MONDO_0008383 \
  --output outputs/ra_chembl_evidence \
  --config examples/config.yaml \
  --skip-docking
```

Live API results can differ as upstream databases change. For a frozen comparison, archive the project `cache/` and `reports/` directories with the software version.

## References

1. Pushpakom S, Iorio F, Eyers PA, et al. Drug repurposing: progress, challenges and recommendations. *Nat Rev Drug Discov.* 2019;18:41–58.
2. Ochoa D, Hercules A, Carmona M, et al. The next-generation Open Targets Platform: reimagined, redesigned, rebuilt. *Nucleic Acids Res.* 2023;51:D1353–D1359.
3. Ferguson C, Araújo D, Faulk L, et al. Europe PMC in 2020. *Nucleic Acids Res.* 2021;49:D1507–D1514. [Confirm year/pages against the latest Europe PMC database paper before submission.]
4. National Library of Medicine. ClinicalTrials.gov. https://clinicaltrials.gov/. Accessed 6 October 2026.
5. Zdrazil B, Felix E, Hunter F, et al. The ChEMBL Database in 2023: a drug discovery platform spanning multiple bioactivity data types and time periods. *Nucleic Acids Res.* 2024;52:D1180–D1192.
6. Burley SK, Bhikadiya C, Bi C, et al. RCSB Protein Data Bank: powerful new tools for exploring 3D structures of biological macromolecules for basic and applied research and education. *Nucleic Acids Res.* 2023;51:D488–D508. [Confirm against the current RCSB NAR paper.]
7. Varadi M, Bertoni D, Magana P, et al. AlphaFold Protein Structure Database in 2024: providing structure coverage for over 214 million protein sequences. *Nucleic Acids Res.* 2024;52:D368–D375.
8. McNutt AT, Francoeur P, Aggarwal R, et al. GNINA 1.0: molecular docking with deep learning. *J Cheminform.* 2021;13:43.
9. Smolen JS, Aletaha D, McInnes IB. Rheumatoid arthritis. *Lancet.* 2016;388:2023–2038.
10. Landrum G, et al. RDKit: Open-source cheminformatics. https://www.rdkit.org. Accessed 6 October 2026.
11. Eastman P, Swails J, Chodera JD, et al. OpenMM 7: Rapid development of high performance algorithms for molecular dynamics. *PLoS Comput Biol.* 2017;13:e1005659.

[Authors should verify every reference in PubMed or Crossref before submission. Do not add docking performance numbers that are not in an archived run.]
