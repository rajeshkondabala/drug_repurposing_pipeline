Meeko — GNU Lesser General Public License v2.1
Copyleft. Redistribution of modified Meeko requires LGPL compliance.
This platform treats Meeko as an optional preparation backend.
