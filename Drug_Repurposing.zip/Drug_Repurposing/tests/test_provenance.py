from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import load_config
from drugrepurposing.provenance import ProvenanceTracker
from drugrepurposing.reports.tables import write_license_report
from drugrepurposing.utils.cache import ContentAddressedCache
from drugrepurposing.workflows import ProjectWorkspace


def test_provenance_and_license(tmp_path: Path):
    cfg = load_config()
    ws = ProjectWorkspace(tmp_path / "proj")
    prov = ProvenanceTracker(ws.root, cfg)
    sample = tmp_path / "in.csv"
    sample.write_text("a\n", encoding="utf-8")
    prov.add_input(sample)
    prov.add_command(["drugrepurposing", "run"])
    prov.warn("test warning")
    path = prov.write()
    assert path.exists()
    assert (ws.root / "manifest.json").exists()
    license_path = write_license_report(ws, cfg)
    text = license_path.read_text(encoding="utf-8")
    assert "opentargets" in text
    assert "gnina" in text
    assert "software" in text
    assert "data" in text


def test_cache_resume(tmp_path: Path):
    cache = ContentAddressedCache(tmp_path / "cache")
    key = {"url": "https://example.org", "q": 1}
    cache.put_json("http", key, {"hello": "world"})
    assert cache.get_json("http", key)["hello"] == "world"
    cache.enabled = False
    assert cache.get_json("http", key) is None
