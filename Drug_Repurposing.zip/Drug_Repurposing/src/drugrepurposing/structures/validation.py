from __future__ import annotations

from drugrepurposing.schemas.structure import PocketDefinition, StructureRecord
from drugrepurposing.structures.seqres import ParsedPDB


def pocket_missing_residues(parsed: ParsedPDB, pocket: PocketDefinition) -> list[str]:
    missing: list[str] = []
    observed = {(res.chain, res.resseq) for res in parsed.residues.values() if not res.hetero}
    for residue_id in pocket.residue_ids:
        parts = residue_id.split(":")
        if len(parts) < 2:
            continue
        chain, seq = parts[0], int(parts[1])
        if (chain, seq) not in observed:
            missing.append(residue_id)
    return missing


def validate_structure(record: StructureRecord, warnings: list[str]) -> list[str]:
    if record.predicted:
        warnings.append("Predicted structure used because no suitable experimental structure was selected.")
        warnings.append("AlphaFold-derived pockets are not experimentally validated.")
        if record.plddt_mean is not None and record.plddt_mean < 70:
            warnings.append("Low AlphaFold confidence.")
    if record.resolution and record.resolution > 3.5:
        warnings.append("Poor experimental resolution.")
    if record.repaired:
        warnings.append("Structure was repaired; rebuilt loops are not experimental.")
    if "metalloprotein" in record.special_handling:
        warnings.append("Metal present; coordination geometry may be unreliable in docking.")
    return warnings
