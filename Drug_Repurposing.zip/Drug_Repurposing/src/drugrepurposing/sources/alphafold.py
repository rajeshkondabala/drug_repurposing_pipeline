from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import AppConfig
from drugrepurposing.schemas.structure import StructureRecord
from drugrepurposing.utils.http import HttpClient, HttpError
from drugrepurposing.utils.io import atomic_write_bytes


class AlphaFoldClient:
    def __init__(self, config: AppConfig, http: HttpClient) -> None:
        self.config = config
        self.http = http
        self.api = config.sources.alphafold.api_url or "https://alphafold.ebi.ac.uk/api"

    def prediction(self, uniprot: str) -> dict | None:
        if not self.config.sources.alphafold.enabled:
            return None
        try:
            envelope = self.http.request_json(
                "GET",
                f"{self.api}/prediction/{uniprot}",
                namespace="alphafold",
                source_name="AlphaFold DB",
                license_or_terms="CC-BY-4.0; attribution required",
            )
        except HttpError:
            return None
        payload = envelope.get("payload")
        if isinstance(payload, list) and payload:
            item = payload[0]
        elif isinstance(payload, dict):
            item = payload
        else:
            return None
        item["_provenance"] = {
            "source_name": envelope.get("source_name"),
            "source_url": envelope.get("source_url"),
            "accessed_at": envelope.get("accessed_at"),
            "raw_record_hash": envelope.get("raw_record_hash"),
            "license_or_terms": envelope.get("license_or_terms"),
        }
        return item

    def download_pdb(self, pdb_url: str, dest: Path) -> tuple[Path, dict]:
        data, meta = self.http.get_bytes(
            pdb_url,
            namespace="alphafold",
            suffix=".pdb",
            source_name="AlphaFold DB",
            license_or_terms="CC-BY-4.0",
        )
        atomic_write_bytes(dest, data)
        return dest, meta

    def to_structure_record(self, uniprot: str, item: dict) -> StructureRecord:
        prov = item.get("_provenance") or {}
        return StructureRecord(
            source_name="AlphaFold DB",
            source_url=item.get("pdbUrl") or f"https://alphafold.ebi.ac.uk/entry/{uniprot}",
            accessed_at=prov.get("accessed_at") or "1970-01-01T00:00:00+00:00",
            query=uniprot,
            raw_record_hash=prov.get("raw_record_hash"),
            license_or_terms="CC-BY-4.0",
            alphafold_id=item.get("entryId") or uniprot,
            experimental_method="AlphaFold prediction",
            predicted=True,
            uniprot=uniprot,
            plddt_mean=item.get("globalMetricValue"),
            selection_reason="Fallback predicted structure; pocket is not experimentally validated.",
        )
