from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from drugrepurposing.schemas.ligand import LigandRecord
from drugrepurposing.utils.hashes import sha256_file
from drugrepurposing.utils.io import atomic_write_text


def meeko_version() -> str | None:
    try:
        import meeko  # type: ignore

        return getattr(meeko, "__version__", "unknown")
    except Exception:
        return None


def _first_molsetup(prepared: Any) -> Any:
    if isinstance(prepared, list):
        if not prepared:
            raise RuntimeError("Meeko returned no molecule setups")
        return prepared[0]
    return prepared


def _write_pdbqt_fallback(src: Path, dest: Path, kind: str) -> None:
    """Copy source only for tests when Meeko is unavailable. Not valid AutoDock PDBQT."""
    text = src.read_text(encoding="utf-8", errors="replace")
    header = f"REMARK  {kind} prepared without Meeko; atom types may be incomplete\n"
    atomic_write_text(dest, header + text)


def looks_like_pdbqt(path: Path) -> bool:
    if not path.exists():
        return False
    text = path.read_text(encoding="utf-8", errors="replace")[:4000]
    if "V2000" in text or "V3000" in text:
        return False
    return "ROOT" in text or "TORSDOF" in text or "ATOM" in text


def prepare_ligand_pdbqt(record: LigandRecord, dest: Path) -> tuple[Path, dict[str, Any]]:
    dest.parent.mkdir(parents=True, exist_ok=True)
    src = Path(record.sdf_path or "")
    manifest: dict[str, Any] = {
        "meeko_version": meeko_version(),
        "input": str(src),
        "output": str(dest),
        "kind": "ligand",
    }
    if not src.exists():
        raise FileNotFoundError("Prepared ligand SDF missing")
    try:
        from meeko import MoleculePreparation, PDBQTWriterLegacy  # type: ignore
        from rdkit import Chem  # type: ignore

        mol = Chem.SDMolSupplier(str(src), removeHs=False)[0]
        if mol is None:
            raise RuntimeError("Could not read ligand SDF for Meeko")
        preparator = MoleculePreparation()
        molsetup = _first_molsetup(preparator.prepare(mol))
        pdbqt, is_ok, error = PDBQTWriterLegacy.write_string(molsetup)
        if not is_ok:
            raise RuntimeError(error or "Meeko PDBQTWriterLegacy failed")
        atomic_write_text(dest, pdbqt)
        manifest["backend"] = "meeko"
    except Exception as exc:
        _write_pdbqt_fallback(src, dest, "ligand")
        manifest["backend"] = "fallback"
        manifest["warning"] = str(exc)
    manifest["output_sha256"] = sha256_file(dest)
    record.pdbqt_path = str(dest)
    record.preparation_manifest.update({k: str(v) for k, v in manifest.items()})
    atomic_write_text(dest.with_suffix(".manifest.json"), json.dumps(manifest, indent=2))
    return dest, manifest


def prepare_receptor_pdbqt(receptor_pdb: Path, dest: Path) -> tuple[Path, dict[str, Any]]:
    dest.parent.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, Any] = {
        "meeko_version": meeko_version(),
        "input": str(receptor_pdb),
        "output": str(dest),
        "kind": "receptor",
    }
    try:
        from meeko import PDBQTWriterLegacy, Polymer  # type: ignore

        polymer = Polymer.from_pdb_file(str(receptor_pdb), allow_bad_res=True)
        rigid, _flex = PDBQTWriterLegacy.write_string_from_polymer(polymer)
        if not rigid.strip():
            raise RuntimeError("Meeko wrote an empty receptor PDBQT")
        atomic_write_text(dest, rigid)
        manifest["backend"] = "meeko"
        manifest["allow_bad_res"] = True
    except Exception as exc:
        _write_pdbqt_fallback(receptor_pdb, dest, "receptor")
        manifest["backend"] = "fallback"
        manifest["warning"] = str(exc)
    manifest["output_sha256"] = sha256_file(dest)
    atomic_write_text(dest.with_suffix(".manifest.json"), json.dumps(manifest, indent=2))
    return dest, manifest


def meeko_command_preview(input_path: Path, output_path: Path, receptor: bool = False) -> list[str]:
    if receptor:
        return ["mk_prepare_receptor.py", "-i", str(input_path), "-o", str(output_path)]
    return ["mk_prepare_ligand.py", "-i", str(input_path), "-o", str(output_path)]
