from __future__ import annotations

from drugrepurposing.config import LigandsCfg
from drugrepurposing.schemas.ligand import LigandIssue, LigandRecord

REACTIVE = ("[N+](=O)[O-]", "C(=O)Cl", "[CH2]Cl", "N=[N+]=[N-]")


def _rdkit():
    try:
        from rdkit import Chem  # type: ignore
        from rdkit.Chem import Descriptors, inchi, rdMolDescriptors  # type: ignore
        from rdkit.Chem.SaltRemover import SaltRemover  # type: ignore
    except Exception as exc:  # pragma: no cover
        raise RuntimeError("RDKit is required for ligand standardization") from exc
    return Chem, Descriptors, inchi, rdMolDescriptors, SaltRemover


def standardize_record(record: LigandRecord, cfg: LigandsCfg) -> LigandRecord:
    if not record.smiles:
        return record
    Chem, _Descriptors, inchi, _rdMolDescriptors, SaltRemover = _rdkit()
    mol = Chem.MolFromSmiles(record.smiles)
    if mol is None:
        record.issues.append(LigandIssue(code="invalid_smiles", message="RDKit could not parse SMILES"))
        return record
    if "." in record.smiles and not cfg.strip_salts:
        record.issues.append(LigandIssue(code="unresolved_salt", message="Mixture/salt retained by configuration", severity="warning"))
    if cfg.strip_salts:
        remover = SaltRemover()
        stripped = remover.StripMol(mol)
        if stripped is not None and stripped.GetNumAtoms() > 0:
            if stripped.GetNumAtoms() != mol.GetNumAtoms():
                record.salt_stripped = True
            mol = stripped
    if not cfg.preserve_stereochemistry:
        record.issues.append(
            LigandIssue(
                code="stereo_policy",
                message="Stereochemistry preservation is disabled; this is not a silent change.",
                severity="warning",
            )
        )
    undefined = False
    for atom in mol.GetAtoms():
        if atom.HasProp("_ChiralityPossible") or atom.GetChiralTag() != Chem.ChiralType.CHI_UNSPECIFIED:
            if atom.GetChiralTag() == Chem.ChiralType.CHI_UNSPECIFIED and atom.HasProp("_CIPCode") is False:
                pass
    from rdkit.Chem.EnumerateStereoisomers import GetStereoisomerCount  # type: ignore

    try:
        if GetStereoisomerCount(mol) > 1:
            undefined = True
    except Exception:
        undefined = False
    record.stereochemistry_undefined = undefined
    if undefined:
        record.issues.append(
            LigandIssue(
                code="undefined_stereo",
                message="Undefined stereocenters detected; stereochemistry was not changed silently.",
                severity="warning",
            )
        )
    smiles_blob = Chem.MolToSmiles(mol)
    if any(token in record.smiles for token in REACTIVE):
        record.covalent_or_reactive = True
        record.issues.append(LigandIssue(code="reactive", message="Possible covalent/reactive functionality", severity="warning"))
    record.canonical_smiles = Chem.MolToSmiles(mol, canonical=True)
    try:
        record.inchi = inchi.MolToInchi(mol)
        record.inchikey = inchi.MolToInchiKey(mol)
    except Exception:
        record.issues.append(LigandIssue(code="inchi_failed", message="InChI generation failed", severity="warning"))
    _ = smiles_blob
    return record
