from drugrepurposing.reports.tables import write_csv_reports

# CSV helpers live in tables.py; this module exists for the required layout.
write_csv = write_csv_reports
