# Docking

GNINA is a **user-supplied** binary. The runner calls `subprocess.run` with a argument list (no shell), records version, CUDA-related environment variables, checksums, stdout/stderr, and supports resume via `.done` markers.

Default: `structures.max_prepared_targets` is 5. Docking scores each prepared receptor separately. Pose ranking uses vina, CNN score, CNN affinity, geometry quality, pocket contacts, and clash penalty. CNN score is never used alone. Labels state that these are computational scores, not binding free energies.

## CUDA

Install a GPU GNINA build yourself. This conda environment does not vendor CUDA or GNINA. Example:

```bash
# After obtaining a gnina binary compatible with your CUDA driver
drug-repurposing dock --project outputs/project_001 --gnina-path /usr/local/bin/gnina
```

## Licensing

Do not redistribute a GNINA binary with this product until you inspect that build’s Apache/GPL components, Open Babel linkage, CNN models, and notices.
