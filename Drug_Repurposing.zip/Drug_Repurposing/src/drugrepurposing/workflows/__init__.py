from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from drugrepurposing.config import AppConfig
from drugrepurposing.store import WorkflowState
from drugrepurposing.utils.io import atomic_write_text


class ProjectWorkspace:
    def __init__(self, root: Path) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        for name in (
            "raw",
            "targets",
            "evidence",
            "structures",
            "ligands",
            "docking",
            "reports",
            "logs",
        ):
            (self.root / name).mkdir(exist_ok=True)

    @property
    def state_path(self) -> Path:
        return self.root / "workflow_state.json"

    def write_json(self, rel: str, payload: Any) -> Path:
        path = self.root / rel
        atomic_write_text(path, json.dumps(payload, indent=2, default=str))
        return path

    def read_json(self, rel: str) -> Any | None:
        path = self.root / rel
        if not path.exists():
            return None
        return json.loads(path.read_text(encoding="utf-8"))

    def set_state(self, state: WorkflowState, extra: dict[str, Any] | None = None) -> None:
        payload = {"state": state.value, **(extra or {})}
        self.write_json("workflow_state.json", payload)

    def state(self) -> str:
        data = self.read_json("workflow_state.json") or {}
        return data.get("state", WorkflowState.INITIALIZED.value)


def attach_known_drugs(targets, drugs) -> None:
    by_symbol: dict[str, list] = {}
    for drug in drugs:
        # Open Targets known drugs are disease-level; attach to all for visibility.
        for target in targets:
            symbol = target.identifiers.approved_symbol
            if symbol:
                by_symbol.setdefault(symbol, [])
    for target in targets:
        target.known_drugs = list(drugs)
