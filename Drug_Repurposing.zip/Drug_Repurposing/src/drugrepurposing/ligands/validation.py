from __future__ import annotations

from collections import Counter

from drugrepurposing.schemas.ligand import LigandIssue, LigandRecord


def detect_duplicate_inchikeys(records: list[LigandRecord]) -> list[LigandRecord]:
    counts = Counter(item.inchikey for item in records if item.inchikey)
    for record in records:
        if record.inchikey and counts[record.inchikey] > 1:
            record.issues.append(
                LigandIssue(code="duplicate_inchikey", message=f"Duplicate InChIKey {record.inchikey}", severity="warning")
            )
    return records


def has_blocking_errors(record: LigandRecord) -> bool:
    return any(issue.severity == "error" for issue in record.issues)
