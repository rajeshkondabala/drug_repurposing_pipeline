from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import AppConfig
from drugrepurposing.logging_utils import get_logger
from drugrepurposing.provenance import ProvenanceTracker
from drugrepurposing.schemas.structure import StructureRecord
from drugrepurposing.sources.alphafold import AlphaFoldClient
from drugrepurposing.sources.rcsb import RCSBClient
from drugrepurposing.store import WorkflowState
from drugrepurposing.structures.alphafold_pockets import rank_alphafold_pockets
from drugrepurposing.structures.chains import analyze_chains
from drugrepurposing.structures.cleaning import clean_pdb
from drugrepurposing.structures.ligand_pocket import detect_cocrystal_pockets
from drugrepurposing.structures.pdbfixer_adapter import PDBFixerUnavailable, prepare_with_pdbfixer
from drugrepurposing.structures.ranking import choose_chain, group_identical_chains, rank_structures
from drugrepurposing.structures.seqres import parse_pdb_file
from drugrepurposing.structures.validation import pocket_missing_residues, validate_structure
from drugrepurposing.utils.http import HttpClient, HttpError
from drugrepurposing.workflows import ProjectWorkspace

LOGGER = get_logger("structures")


def _load_existing_structure(struct_dir: Path) -> StructureRecord | None:
    payload_path = struct_dir / "structure.json"
    repaired = struct_dir / "repaired.pdb"
    if not payload_path.exists() or not repaired.exists() or repaired.stat().st_size == 0:
        return None
    record = StructureRecord.model_validate(__import__("json").loads(payload_path.read_text(encoding="utf-8")))
    record.file_path = str(repaired)
    return record


def _materialize_structure(
    best: StructureRecord,
    *,
    symbol: str,
    accession: str | None,
    config: AppConfig,
    workspace: ProjectWorkspace,
    provenance: ProvenanceTracker,
    rcsb: RCSBClient,
    alphafold: AlphaFoldClient,
    struct_dir: Path,
) -> StructureRecord:
    struct_dir.mkdir(parents=True, exist_ok=True)
    raw_path = struct_dir / "raw.pdb"
    if best.pdb_id:
        path, meta = rcsb.download_pdb(best.pdb_id, raw_path)
        provenance.add_source(meta)
        best.file_path = str(path)
        best.checksum = meta.get("raw_record_hash")
        if meta.get("converted_from") == "mmcif":
            provenance.warn(f"{best.pdb_id} had no PDB download; coordinates were converted from mmCIF.")
    elif best.predicted:
        pred = alphafold.prediction(accession or "")
        if not pred or not pred.get("pdbUrl"):
            raise RuntimeError("AlphaFold coordinates unavailable")
        path, meta = alphafold.download_pdb(pred["pdbUrl"], raw_path)
        provenance.add_source(meta)
        best.file_path = str(path)
    else:
        raise RuntimeError("Structure record has neither pdb_id nor predicted coordinates")
    parsed = parse_pdb_file(Path(best.file_path))
    chains = analyze_chains(parsed)
    pockets = detect_cocrystal_pockets(parsed, config.structures.pocket_padding_angstrom)
    if best.predicted or not pockets:
        pockets = rank_alphafold_pockets(
            best.file_path, parsed, None, config.structures.alphafold_top_pockets
        )
        provenance.warn("Using computationally derived pocket(s).")
    pocket = pockets[0] if pockets else None
    interface = bool(pocket and len({r.split(":")[0] for r in pocket.residue_ids}) > 1)
    groups = group_identical_chains(chains, config.structures.chain_identity_threshold)
    chains = choose_chain(chains, groups, set(pocket.residue_ids if pocket else []), interface)
    selected_ids = {c.chain_id for c in chains if c.selected} or None
    cleaned = clean_pdb(parsed, struct_dir / "clean.pdb", config, selected_ids)
    try:
        repair = prepare_with_pdbfixer(cleaned, struct_dir / "repaired.pdb", parsed, config, list(selected_ids or []))
        best.repaired = True
        best.inserted_residues = repair.get("inserted_residues") or []
        (struct_dir / "preparation.log").write_text(str(repair), encoding="utf-8")
        if pocket:
            missing = pocket_missing_residues(parsed, pocket)
            if missing:
                provenance.warn(f"Missing residues in pocket: {missing}")
                if config.structures.exclude_if_pocket_missing_residues:
                    provenance.warn("Pocket missing residues; repaired loops are not treated as experimental.")
    except PDBFixerUnavailable as exc:
        provenance.warn(str(exc))
        (struct_dir / "repaired.pdb").write_text(Path(cleaned).read_text(encoding="utf-8"), encoding="utf-8")
    best.chains = chains
    best.pockets = pockets[: config.structures.alphafold_top_pockets] if best.predicted else pockets[:1]
    special_path = Path(str(cleaned)).with_suffix(".special.txt")
    if special_path.exists():
        best.special_handling = [line for line in special_path.read_text(encoding="utf-8").splitlines() if line]
    warnings: list[str] = []
    validate_structure(best, warnings)
    for warning in warnings:
        provenance.warn(warning)
    best.target_symbol = symbol
    if (struct_dir / "repaired.pdb").exists():
        best.file_path = str(struct_dir / "repaired.pdb")
    workspace.write_json(f"structures/{symbol}/structure.json", best.model_dump(mode="json"))
    return best


def prepare_structures(
    config: AppConfig,
    workspace: ProjectWorkspace,
    http: HttpClient,
    provenance: ProvenanceTracker,
    max_targets: int | None = None,
) -> list[StructureRecord]:
    targets = workspace.read_json("targets/targets.json") or []
    if not targets:
        raise RuntimeError("No targets found. Run analyze-targets first.")
    limit = max_targets if max_targets is not None else config.structures.max_prepared_targets
    rcsb = RCSBClient(config, http)
    alphafold = AlphaFoldClient(config, http)
    selected: list[StructureRecord] = []
    for target in targets:
        if len(selected) >= limit:
            break
        ident = target.get("identifiers") or {}
        symbol = ident.get("approved_symbol") or ident.get("ensembl_gene_id") or "target"
        struct_dir = workspace.root / "structures" / symbol
        existing = _load_existing_structure(struct_dir)
        if existing is not None:
            existing.target_symbol = symbol
            selected.append(existing)
            LOGGER.info("structure_resumed", extra={"target": symbol, "pdb": existing.pdb_id})
            continue
        accessions = ident.get("uniprot_accessions") or []
        accession = accessions[0] if accessions else None
        records: list[StructureRecord] = []
        if accession:
            try:
                pdb_ids = rcsb.search_by_uniprot(accession)
                for pdb_id in pdb_ids[: max(config.structures.max_structures_per_target, 15)]:
                    try:
                        meta = rcsb.entry_metadata(pdb_id)
                        records.append(rcsb.to_structure_record(pdb_id, meta, uniprot=accession))
                    except HttpError as exc:
                        provenance.warn(f"RCSB metadata failed for {pdb_id}: {exc}")
            except HttpError as exc:
                provenance.warn(f"RCSB search failed: {exc}")
        ranked = rank_structures(records, config)
        prepared = None
        last_error: Exception | None = None
        for candidate in ranked:
            try:
                prepared = _materialize_structure(
                    candidate,
                    symbol=symbol,
                    accession=accession,
                    config=config,
                    workspace=workspace,
                    provenance=provenance,
                    rcsb=rcsb,
                    alphafold=alphafold,
                    struct_dir=struct_dir,
                )
                break
            except Exception as exc:
                if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                    raise
                last_error = exc
                provenance.warn(f"Skipping {symbol} structure {candidate.pdb_id or candidate.alphafold_id}: {exc}")
                continue
        if prepared is None and accession and config.structures.allow_predicted_structure:
            pred = alphafold.prediction(accession)
            if pred:
                try:
                    prepared = _materialize_structure(
                        alphafold.to_structure_record(accession, pred),
                        symbol=symbol,
                        accession=accession,
                        config=config,
                        workspace=workspace,
                        provenance=provenance,
                        rcsb=rcsb,
                        alphafold=alphafold,
                        struct_dir=struct_dir,
                    )
                except Exception as exc:
                    if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                        raise
                    last_error = exc
                    provenance.warn(f"AlphaFold fallback failed for {symbol}: {exc}")
        if prepared is None:
            provenance.warn(f"No usable structure for {symbol}" + (f" ({last_error})" if last_error else ""))
            continue
        selected.append(prepared)
        LOGGER.info(
            "structure_selected",
            extra={"target": symbol, "pdb": prepared.pdb_id, "af": prepared.alphafold_id},
        )
    workspace.write_json("structures/selected.json", [s.model_dump(mode="json") for s in selected])
    workspace.set_state(WorkflowState.STRUCTURES_PREPARED)
    provenance.set_status(WorkflowState.STRUCTURES_PREPARED.value)
    return selected
