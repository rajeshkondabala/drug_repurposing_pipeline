from __future__ import annotations

from drugrepurposing.schemas.docking import DockingPose


def rescore_note() -> str:
    return (
        "CNN rescoring is a computational score. It is not a binding free energy "
        "and is not combined with the target evidence score."
    )


def attach_notes(poses: list[DockingPose]) -> list[DockingPose]:
    note = rescore_note()
    for pose in poses:
        pose.score_note = note
    return poses
