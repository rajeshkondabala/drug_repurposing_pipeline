from __future__ import annotations

from drugrepurposing.evidence.clinical import clinical_score
from drugrepurposing.evidence.genetics import datatype, genetic_score
from drugrepurposing.evidence.literature import literature_component_scores
from drugrepurposing.evidence.novelty import classify_novelty
from drugrepurposing.evidence.pathway import mechanistic_score
from drugrepurposing.evidence.safety import safety_risk_score, tractability_score
from drugrepurposing.schemas.evidence import (
    ClinicalTrialRecord,
    EvidenceGraphItem,
    LiteratureRecord,
    TargetScoreBreakdown,
)
from drugrepurposing.schemas.target import KnownDrug, TargetRecord


def _clip(value: float) -> float:
    return max(0.0, min(1.0, value))


def _confidence(overall: float, completeness: float) -> str:
    if completeness < 0.4:
        return "low"
    if overall >= 0.7 and completeness >= 0.6:
        return "high"
    if overall >= 0.4:
        return "moderate"
    return "low"


def _maturity(drugs: list[KnownDrug], clinical: float) -> str:
    if any((drug.phase or "").lower() in {"4", "phase_4", "approved"} for drug in drugs):
        return "high"
    if clinical >= 0.6 or drugs:
        return "moderate"
    return "low"


def score_target(
    target: TargetRecord,
    *,
    weights: dict[str, float],
    literature_weights: dict[str, float],
    novelty_cfg: dict[str, float | int],
    literature: list[LiteratureRecord],
    trials: list[ClinicalTrialRecord],
    drugs: list[KnownDrug],
    search_succeeded: bool,
    condition_id: str,
) -> TargetScoreBreakdown:
    assoc = _clip(target.association_score)
    genetic = _clip(genetic_score(target))
    lit_parts = literature_component_scores(literature, literature_weights)
    lit = _clip(float(lit_parts.get("overall", 0.0)))
    clinical, clinical_note = clinical_score(trials)
    drug = _clip(1.0 if drugs else datatype(target, "known_drug"))
    mechanistic = _clip(mechanistic_score(target))
    tract = _clip(tractability_score(target))
    safety = _clip(safety_risk_score(target))
    tissue = _clip(1.0 if target.expression_tissues else datatype(target, "rna_expression"))
    conflict = 0.15 if safety > 0.5 and assoc > 0.5 else 0.0
    present = [
        assoc > 0,
        genetic > 0,
        lit > 0,
        clinical > 0,
        drug > 0,
        mechanistic > 0,
        bool(target.expression_tissues),
        search_succeeded,
    ]
    completeness = sum(1 for item in present if item) / len(present)
    completeness_penalty = 1.0 - completeness

    overall = (
        weights.get("association", 0) * assoc
        + weights.get("genetic", 0) * genetic
        + weights.get("literature", 0) * lit
        + weights.get("clinical", 0) * clinical
        + weights.get("drug", 0) * drug
        + weights.get("mechanistic", 0) * mechanistic
        + weights.get("tractability", 0) * tract
        + weights.get("tissue", 0) * tissue
        - weights.get("safety_risk", 0) * safety
        - weights.get("conflict", 0) * conflict
        - weights.get("completeness_penalty", 0) * completeness_penalty
    )
    overall = _clip(overall)

    independent_sources = sum(
        1
        for flag in (
            assoc > 0,
            genetic > 0,
            bool(literature),
            bool(trials),
            bool(drugs),
            mechanistic > 0,
        )
        if flag
    )
    novelty, novelty_text = classify_novelty(
        target=target,
        association=assoc,
        mechanistic=mechanistic,
        completeness=completeness,
        independent_sources=independent_sources,
        trials=trials,
        drugs=drugs,
        search_succeeded=search_succeeded,
        min_association_or_mechanistic=float(novelty_cfg.get("min_association_or_mechanistic", 0.45)),
        min_completeness=float(novelty_cfg.get("min_completeness", 0.4)),
        min_independent_sources=int(novelty_cfg.get("min_independent_sources", 2)),
    )

    symbol = target.identifiers.approved_symbol or target.identifiers.ensembl_gene_id or "unknown"
    contributors: list[str] = []
    if assoc >= 0.5:
        contributors.append("Strong target–disease association.")
    if genetic >= 0.3:
        contributors.append("Human genetic evidence.")
    if drugs:
        contributors.append("Known drugs or mechanisms annotated.")
    if clinical >= 0.3:
        contributors.append("Clinical-stage records found.")
    if lit >= 0.3:
        contributors.append("Disease-relevant literature beyond publication count.")
    limitations = [
        "Docking, if performed later, does not establish efficacy.",
        novelty_text,
        clinical_note,
    ]
    if not literature:
        limitations.append("No human literature retrieved or source outage.")
    uncertainties = []
    if completeness < 0.5:
        uncertainties.append("Incomplete source coverage.")
    if target.safety_liabilities:
        uncertainties.append("Safety liabilities annotated; association is not therapeutic proof.")
    follow_up = [
        "Orthogonal genetic or perturbation experiments in a disease-relevant system.",
        "Orthogonal biophysical or cellular target-engagement assays if a ligand is pursued.",
    ]
    explanation = (
        f"Target: {symbol}. Overall evidence score {overall:.2f} is a weighted combination of "
        "association, genetic, literature quality, clinical, drug, mechanistic, tractability, "
        "and tissue scores minus safety, conflict, and completeness penalties. "
        "This evidence score is independent of any docking score."
    )
    graph = [
        EvidenceGraphItem(
            type="association",
            source_id=target.identifiers.ensembl_gene_id or symbol,
            source_url=target.source_url,
            retrieved_at=target.accessed_at.isoformat(),
            score=assoc,
            license_or_terms=target.license_or_terms,
        )
    ]
    for trial in trials[:10]:
        graph.append(
            EvidenceGraphItem(
                type="clinical_trial",
                source_id=trial.nct_id,
                source_url=trial.source_url,
                retrieved_at=trial.accessed_at.isoformat(),
                score=clinical,
                license_or_terms=trial.license_or_terms,
            )
        )
    return TargetScoreBreakdown(
        symbol=symbol,
        ensembl_id=target.identifiers.ensembl_gene_id,
        overall_score=round(overall, 4),
        evidence_confidence=_confidence(overall, completeness),
        data_completeness=round(completeness, 4),
        known_therapeutic_maturity=_maturity(drugs, clinical),
        novelty_category=novelty,
        components={
            "association": round(assoc, 4),
            "genetic": round(genetic, 4),
            "literature": round(lit, 4),
            "clinical": round(clinical, 4),
            "drug": round(drug, 4),
            "mechanistic": round(mechanistic, 4),
            "tractability": round(tract, 4),
            "safety_risk": round(safety, 4),
            "tissue": round(tissue, 4),
            "conflict": round(conflict, 4),
            "completeness_penalty": round(completeness_penalty, 4),
            **{f"literature_{k}": round(float(v), 4) for k, v in lit_parts.items() if k != "overall"},
        },
        contributors=contributors,
        limitations=limitations,
        uncertainties=uncertainties,
        strengths=contributors,
        recommended_experimental_follow_up=follow_up,
        explanation=explanation,
        evidence_graph=graph,
        extra={"condition_id": condition_id, "literature_count": len(literature)},
    )
