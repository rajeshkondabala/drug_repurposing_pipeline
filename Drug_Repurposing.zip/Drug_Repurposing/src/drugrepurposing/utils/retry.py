from __future__ import annotations

import time
from collections import deque
from threading import Lock


class TokenBucket:
    def __init__(self, rate_per_second: float) -> None:
        self.rate = max(rate_per_second, 0.1)
        self._times: deque[float] = deque()
        self._lock = Lock()

    def acquire(self) -> None:
        with self._lock:
            now = time.monotonic()
            window = 1.0
            while self._times and now - self._times[0] > window:
                self._times.popleft()
            if len(self._times) >= self.rate:
                sleep_for = window - (now - self._times[0])
                if sleep_for > 0:
                    time.sleep(sleep_for)
            self._times.append(time.monotonic())
