#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
drug-repurposing validate-installation
drug-repurposing init-config --output examples/generated-config.yaml
drug-repurposing search-condition --condition "rheumatoid arthritis" --config examples/config.yaml
drug-repurposing analyze-targets \
  --condition "rheumatoid arthritis" \
  --config examples/config.yaml \
  --output outputs/rheumatoid_arthritis
# Docking requires a user-supplied GNINA binary:
# drug-repurposing run \
#   --condition "rheumatoid arthritis" \
#   --ligands examples/input.csv \
#   --gnina-path /path/to/gnina \
#   --output outputs/rheumatoid_arthritis \
#   --config examples/config.yaml
echo "Example target analysis complete. See outputs/rheumatoid_arthritis"
