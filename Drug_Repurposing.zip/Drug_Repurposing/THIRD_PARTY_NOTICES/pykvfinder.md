pyKVFinder — GPL-3.0
Optional pocket-detection plugin. Do not statically link into proprietary
binaries without legal review.
