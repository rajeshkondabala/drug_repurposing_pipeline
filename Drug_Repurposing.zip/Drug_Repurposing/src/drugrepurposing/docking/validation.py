from __future__ import annotations

from pathlib import Path

from drugrepurposing.schemas.docking import DockingPose


def parse_gnina_sdf(path: Path, ligand_id: str, structure_id: str, pocket_id: str, target: str | None) -> list[DockingPose]:
    text = path.read_text(encoding="utf-8", errors="replace")
    blocks = [block for block in text.split("$$$$") if block.strip()]
    poses: list[DockingPose] = []
    for idx, block in enumerate(blocks, start=1):
        props: dict[str, str] = {}
        lines = block.splitlines()
        for i, line in enumerate(lines):
            if line.startswith("> <") and line.endswith(">"):
                key = line[3:-1]
                value = lines[i + 1].strip() if i + 1 < len(lines) else ""
                props[key] = value
            if line.strip().startswith("REMARK"):
                for token in ("minimizedAffinity", "CNNscore", "CNNaffinity"):
                    if token in line:
                        parts = line.split()
                        for j, part in enumerate(parts):
                            if part == token and j + 1 < len(parts):
                                props[token] = parts[j + 1]
        def _f(name: str) -> float | None:
            raw = props.get(name) or props.get(name.lower())
            try:
                return float(raw) if raw is not None else None
            except ValueError:
                return None

        vina = _f("minimizedAffinity") or _f("vina_score")
        cnn = _f("CNNscore") or _f("cnn_score")
        aff = _f("CNNaffinity") or _f("cnn_affinity")
        poses.append(
            DockingPose(
                ligand_id=ligand_id,
                target=target,
                structure_id=structure_id,
                pocket_id=pocket_id,
                pose_rank=idx,
                vina_score=vina,
                cnn_score=cnn,
                cnn_affinity=aff,
                docking_score=vina,
            )
        )
    return poses
