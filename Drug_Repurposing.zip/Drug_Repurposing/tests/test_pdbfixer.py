from __future__ import annotations

from drugrepurposing.structures.pdbfixer_adapter import PDBFixerUnavailable


def test_pdbfixer_unavailable_message():
    err = PDBFixerUnavailable("PDBFixer/OpenMM are required")
    assert "PDBFixer" in str(err)
