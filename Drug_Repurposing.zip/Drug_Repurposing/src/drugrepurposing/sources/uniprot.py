from __future__ import annotations

from drugrepurposing.config import AppConfig
from drugrepurposing.utils.http import HttpClient, HttpError


class UniProtClient:
    def __init__(self, config: AppConfig, http: HttpClient) -> None:
        self.config = config
        self.http = http
        self.base = config.sources.uniprot.base_url or "https://rest.uniprot.org"

    def fetch(self, accession: str) -> dict | None:
        if not self.config.sources.uniprot.enabled:
            return None
        try:
            envelope = self.http.request_json(
                "GET",
                f"{self.base}/uniprotkb/{accession}.json",
                namespace="http",
                source_name="UniProt",
                license_or_terms="CC-BY-4.0; attribution required",
            )
        except HttpError:
            return None
        payload = envelope.get("payload") or {}
        payload["_provenance"] = {
            "source_name": envelope.get("source_name"),
            "source_url": envelope.get("source_url"),
            "accessed_at": envelope.get("accessed_at"),
            "raw_record_hash": envelope.get("raw_record_hash"),
            "license_or_terms": envelope.get("license_or_terms"),
        }
        return payload

    def canonical_accession(self, payload: dict) -> str | None:
        return payload.get("primaryAccession")
