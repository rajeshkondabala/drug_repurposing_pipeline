# Security

This software is for computational research. It does not store clinical credentials by default.

- Do not commit API keys. PubMed keys belong in a local config overlay (`*.local.yaml`) or environment-specific files listed in `.gitignore`.
- Report vulnerabilities privately to the repository maintainers. Do not file a public issue with exploit details.
- Generated reports may contain compound structures and disease identifiers; treat project `outputs/` as potentially sensitive in your organization.
