from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import load_config
from drugrepurposing.docking.gnina_runner import build_gnina_command
from drugrepurposing.docking.meeko_adapter import meeko_command_preview
from drugrepurposing.docking.pose_selection import rank_poses
from drugrepurposing.docking.validation import parse_gnina_sdf

FIXTURES = Path(__file__).parent / "fixtures"


def test_meeko_command_generation(tmp_path: Path):
    cmd = meeko_command_preview(tmp_path / "in.sdf", tmp_path / "out.pdbqt", receptor=False)
    assert cmd[0] == "mk_prepare_ligand.py"
    rec = meeko_command_preview(tmp_path / "in.pdb", tmp_path / "out.pdbqt", receptor=True)
    assert rec[0] == "mk_prepare_receptor.py"


def test_gnina_command_generation(tmp_path: Path):
    cfg = load_config().docking
    cmd = build_gnina_command(
        "/opt/gnina",
        tmp_path / "r.pdbqt",
        tmp_path / "l.pdbqt",
        tmp_path / "out.sdf",
        {"center_x": 1.0, "center_y": 2.0, "center_z": 3.0, "size_x": 20, "size_y": 20, "size_z": 20},
        cfg,
    )
    assert cmd[0] == "/opt/gnina"
    assert "--center_x" in cmd
    assert "1.0" in cmd
    assert all(isinstance(x, str) for x in cmd)


def test_gnina_cpu_maps_to_no_gpu(tmp_path: Path):
    cfg = load_config().docking
    cfg.cpu = True
    cmd = build_gnina_command(
        "/opt/gnina",
        tmp_path / "r.pdb",
        tmp_path / "l.sdf",
        tmp_path / "out.sdf",
        {"center_x": 1.0, "center_y": 2.0, "center_z": 3.0, "size_x": 20, "size_y": 20, "size_z": 20},
        cfg,
    )
    assert "--no_gpu" in cmd
    assert cmd.count("--cpu") == 0


def test_rdkit_gnina_detection():
    from drugrepurposing.docking.gnina_runner import gnina_uses_rdkit_io

    assert gnina_uses_rdkit_io("gnina-rdkit 1.3.3")
    assert not gnina_uses_rdkit_io("gnina 1.0")


def test_parse_and_rank_poses():
    poses = parse_gnina_sdf(FIXTURES / "gnina_out.sdf", "TOFA", "1ABC", "LIG_A_101", "IL6R")
    assert len(poses) == 2
    ranked = rank_poses(poses, {"docking_score": 0.25, "cnn_score": 0.2, "cnn_affinity": 0.15, "pose_geometry_quality": 0.15, "pocket_contact_score": 0.15, "clash_penalty": 0.1})
    assert ranked[0].final_pose_score is not None
    assert ranked[0].vina_score == -9.1
    assert "not a binding free energy" in ranked[0].score_note.lower() or "computational" in ranked[0].score_note.lower()
