from __future__ import annotations

from pathlib import Path

import pytest

from drugrepurposing.config import load_config
from drugrepurposing.schemas.structure import StructureRecord
from drugrepurposing.structures.alphafold_pockets import fallback_grid_pockets, rank_alphafold_pockets
from drugrepurposing.structures.ligand_pocket import detect_cocrystal_pockets, heavy_atom_box
from drugrepurposing.structures.pdbfixer_adapter import PDBFixerUnavailable
from drugrepurposing.structures.ranking import rank_structures
from drugrepurposing.structures.seqres import parse_pdb_file

FIXTURES = Path(__file__).parent / "fixtures"


def test_cocrystal_and_box():
    parsed = parse_pdb_file(FIXTURES / "mini.pdb")
    pockets = detect_cocrystal_pockets(parsed, padding=5.0)
    assert pockets
    assert pockets[0].ligand_resname == "LIG"
    center, size, radius = heavy_atom_box([(0.0, 0.0, 0.0), (2.0, 0.0, 0.0)], 4.0)
    assert center[0] == 1.0
    assert size[0] == 10.0
    assert radius > 0


def test_structure_rank_prefers_experimental_ligand():
    cfg = load_config()
    experimental = StructureRecord(
        source_name="RCSB",
        source_url="https://www.rcsb.org/structure/1ABC",
        pdb_id="1ABC",
        resolution=2.1,
        ligand_ids=["LIG"],
        predicted=False,
        uniprot="P08887",
    )
    predicted = StructureRecord(
        source_name="AF",
        source_url="https://alphafold.ebi.ac.uk/entry/P08887",
        alphafold_id="AF-P08887",
        predicted=True,
        plddt_mean=90,
        uniprot="P08887",
    )
    ranked = rank_structures([experimental, predicted], cfg)
    assert ranked[0].pdb_id == "1ABC"


def test_alphafold_pocket_fallback():
    parsed = parse_pdb_file(FIXTURES / "mini.pdb")
    pockets = rank_alphafold_pockets(str(FIXTURES / "mini.pdb"), parsed, {1: 50.0}, top_n=3)
    assert 1 <= len(pockets) <= 3
    assert all(p.experimental is False for p in pockets)
    assert any("not experimentally validated" in " ".join(p.warnings).lower() for p in pockets)
    _ = fallback_grid_pockets(parsed, n=2)


def test_pdbfixer_adapter_missing_optional(monkeypatch, tmp_path):
    parsed = parse_pdb_file(FIXTURES / "mini.pdb")
    cfg = load_config()

    def boom(*args, **kwargs):
        raise PDBFixerUnavailable("missing")

    import drugrepurposing.structures.pdbfixer_adapter as adapter

    monkeypatch.setattr(adapter, "prepare_with_pdbfixer", boom)
    try:
        adapter.prepare_with_pdbfixer(FIXTURES / "mini.pdb", tmp_path / "out.pdb", parsed, cfg)
    except PDBFixerUnavailable:
        return
    assert (tmp_path / "out.pdb").exists()


def test_pdbfixer_can_parse_fixture(tmp_path):
    pytest.importorskip("pdbfixer")
    parsed = parse_pdb_file(FIXTURES / "mini.pdb")
    cfg = load_config()
    from drugrepurposing.structures.pdbfixer_adapter import prepare_with_pdbfixer

    out = tmp_path / "out.pdb"
    result = prepare_with_pdbfixer(FIXTURES / "mini.pdb", out, parsed, cfg)
    assert out.exists()
    assert result["repaired"] is True
