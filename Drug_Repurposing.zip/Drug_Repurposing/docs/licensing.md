# Licensing

Platform code: **Apache-2.0**.

A **dependency license** and a **data license** are recorded independently in `configs/licenses.yaml` and in each project `license_report.csv`.

## Classification

| Class | Meaning |
| --- | --- |
| permissive | Redistribute with notice |
| attribution_required | Commercial use with attribution |
| copyleft | Source-sharing obligations may apply |
| restricted_or_unclear | Disabled or not bundled until reviewed |
| not_for_redistribution | Keep disabled / runtime retrieval only |

## Software (selected)

- NumPy, SciPy, pandas, RDKit, Pydantic, httpx, Jinja2, Typer: permissive
- PDBFixer: MIT
- OpenMM: MIT with some components that need binary review
- Meeko: LGPL-2.1 (copyleft; **not** in `environment.yml`; install via `environment-extras.yml`)
- pyKVFinder: GPL-3.0 (copyleft; **not** in `environment.yml`; install via `environment-extras.yml`)
- GNINA: mixed historically; user binary; **no commercial-redistribution claim**
- Open Babel: GPL; **not installed by default**

## Data (selected)

- Open Targets data: CC0; software Apache-2.0; linked evidence keeps original licenses
- RCSB/wwPDB archive and API: CC0 (external annotations may differ)
- AlphaFold DB: CC BY 4.0
- UniProt, PubChem: CC BY 4.0
- ChEMBL: CC-BY-SA-3.0 (do not ship parent-molecule dumps in the source tree)
- ClinicalTrials.gov: US government work
- PubMed: NLM terms
- DrugBank: not enabled by default

Datasets with unclear licenses are not bundled. The platform prefers runtime retrieval with provenance.
