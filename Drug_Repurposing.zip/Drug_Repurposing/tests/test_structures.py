from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import load_config
from drugrepurposing.structures.chains import analyze_chains, identity
from drugrepurposing.structures.cleaning import clean_pdb
from drugrepurposing.structures.ranking import choose_chain, group_identical_chains
from drugrepurposing.structures.seqres import parse_pdb_file

FIXTURES = Path(__file__).parent / "fixtures"


def test_seqres_and_missing_internal():
    parsed = parse_pdb_file(FIXTURES / "seqres_gap.pdb")
    chains = analyze_chains(parsed)
    assert chains[0].seqres_length == 4
    assert any("3" in item for item in chains[0].missing_internal)


def test_chain_identity_and_selection():
    parsed = parse_pdb_file(FIXTURES / "mini.pdb")
    # mini.pdb has no SEQRES; inject identical sequences
    chains = analyze_chains(parsed)
    for chain in chains:
        chain.sequence = "AV"
    groups = group_identical_chains(chains, 0.95)
    assert identity("AV", "AV") == 1.0
    assert any(len(g) == 2 for g in groups)
    chosen = choose_chain(chains, groups, {"A:1"}, interface=False)
    selected = [c for c in chosen if c.selected]
    assert len(selected) == 1


def test_interface_keeps_multiple_chains():
    parsed = parse_pdb_file(FIXTURES / "mini.pdb")
    chains = analyze_chains(parsed)
    for chain in chains:
        chain.sequence = "AV"
    groups = group_identical_chains(chains, 0.95)
    chosen = choose_chain(chains, groups, {"A:1", "B:1"}, interface=True)
    assert sum(1 for c in chosen if c.selected) >= 2


def test_clean_drops_orphan_ter(tmp_path: Path):
    raw = Path(tmp_path / "orphan.pdb")
    raw.write_text(
        "TER\n"
        "ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00 20.00           N\n"
        "TER\n"
        "TER\n"
        "END\n",
        encoding="utf-8",
    )
    parsed = parse_pdb_file(raw)
    cleaned = clean_pdb(parsed, tmp_path / "clean.pdb", load_config(), None)
    text = cleaned.read_text(encoding="utf-8")
    assert text.splitlines()[0].startswith("ATOM")
    assert text.count("TER") == 1
