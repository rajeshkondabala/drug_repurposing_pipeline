from __future__ import annotations

from drugrepurposing.evidence.literature import literature_component_scores
from drugrepurposing.schemas.evidence import EvidenceClass, LiteratureRecord
from drugrepurposing.sources.europe_pmc import classify_publication


def test_literature_classification_not_count_only():
    klass, review = classify_publication("GWAS of rheumatoid arthritis", "Journal Article")
    assert klass == EvidenceClass.GENETIC
    assert not review
    records = [
        LiteratureRecord(
            source_name="Europe PMC",
            source_url="https://example.org",
            pmid="1",
            title="GWAS",
            evidence_class=EvidenceClass.GENETIC,
            is_recent=True,
        ),
        LiteratureRecord(
            source_name="Europe PMC",
            source_url="https://example.org",
            pmid="2",
            title="review",
            evidence_class=EvidenceClass.REVIEW_ONLY,
            is_review=True,
        ),
    ]
    scores = literature_component_scores(records, {"genetic": 0.5, "review_only": 0.5, "recency_bonus": 0.2})
    assert scores["genetic"] == 0.5
    assert scores["publication_count"] == 2
    assert "overall" in scores
