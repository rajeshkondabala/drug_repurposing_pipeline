from __future__ import annotations

import re

from drugrepurposing.config import AppConfig
from drugrepurposing.schemas.evidence import ClinicalPhase, ClinicalTrialRecord
from drugrepurposing.utils.http import HttpClient, HttpError

PHASE_MAP = {
    "EARLY_PHASE1": ClinicalPhase.PHASE_1,
    "PHASE1": ClinicalPhase.PHASE_1,
    "PHASE1/PHASE2": ClinicalPhase.PHASE_1_2,
    "PHASE2": ClinicalPhase.PHASE_2,
    "PHASE2/PHASE3": ClinicalPhase.PHASE_2_3,
    "PHASE3": ClinicalPhase.PHASE_3,
    "PHASE4": ClinicalPhase.PHASE_4,
    "NA": ClinicalPhase.NOT_APPLICABLE,
    "N/A": ClinicalPhase.NOT_APPLICABLE,
    "PRECLINICAL": ClinicalPhase.PRECLINICAL,
}


def normalize_phase(value: str | list[str] | None) -> ClinicalPhase:
    if value is None or value == []:
        return ClinicalPhase.UNKNOWN
    if isinstance(value, list):
        phases = [normalize_phase(item) for item in value]
        order = [
            ClinicalPhase.PHASE_4,
            ClinicalPhase.PHASE_3,
            ClinicalPhase.PHASE_2_3,
            ClinicalPhase.PHASE_2,
            ClinicalPhase.PHASE_1_2,
            ClinicalPhase.PHASE_1,
            ClinicalPhase.PRECLINICAL,
            ClinicalPhase.NOT_APPLICABLE,
        ]
        for candidate in order:
            if candidate in phases:
                return candidate
        return phases[0] if phases else ClinicalPhase.UNKNOWN
    key = re.sub(r"[^A-Z0-9/]", "", str(value).upper())
    key = key.replace("PHASE", "PHASE")
    if key in PHASE_MAP:
        return PHASE_MAP[key]
    compact = key.replace("/", "")
    aliases = {
        "PHASE1PHASE2": ClinicalPhase.PHASE_1_2,
        "PHASE2PHASE3": ClinicalPhase.PHASE_2_3,
        "EARLYPHASE1": ClinicalPhase.PHASE_1,
    }
    return aliases.get(compact, PHASE_MAP.get(key, ClinicalPhase.UNKNOWN))


class ClinicalTrialsClient:
    def __init__(self, config: AppConfig, http: HttpClient) -> None:
        self.config = config
        self.http = http
        self.base = config.sources.clinicaltrials.base_url or "https://clinicaltrials.gov/api/v2"

    def search(self, condition: str, intervention: str | None = None) -> list[ClinicalTrialRecord]:
        if not self.config.sources.clinicaltrials.enabled:
            return []
        params: dict[str, str | int | bool] = {
            "query.cond": condition,
            "pageSize": self.config.evidence.trials_page_size,
            "countTotal": True,
            "format": "json",
        }
        if intervention:
            params["query.intr"] = intervention
        try:
            envelope = self.http.request_json(
                "GET",
                f"{self.base}/studies",
                params=params,
                namespace="trials",
                source_name="ClinicalTrials.gov",
                license_or_terms="US government work; public domain",
            )
        except HttpError:
            return []
        studies = envelope.get("payload", {}).get("studies") or []
        records: list[ClinicalTrialRecord] = []
        for study in studies:
            protocol = study.get("protocolSection") or {}
            ident = protocol.get("identificationModule") or {}
            status = protocol.get("statusModule") or {}
            design = protocol.get("designModule") or {}
            desc = protocol.get("descriptionModule") or {}
            sponsor = protocol.get("sponsorCollaboratorsModule") or {}
            nct = ident.get("nctId")
            if not nct:
                continue
            phases = design.get("phases") or []
            enrollment = (design.get("enrollmentInfo") or {}).get("count")
            lead = (sponsor.get("leadSponsor") or {}).get("name")
            records.append(
                ClinicalTrialRecord(
                    source_name="ClinicalTrials.gov",
                    source_url=f"https://clinicaltrials.gov/study/{nct}",
                    accessed_at=envelope["accessed_at"],
                    query=condition,
                    raw_record_hash=envelope.get("raw_record_hash"),
                    license_or_terms=envelope.get("license_or_terms"),
                    nct_id=nct,
                    title=ident.get("briefTitle") or ident.get("officialTitle"),
                    intervention=intervention,
                    condition=condition,
                    phase=normalize_phase(phases),
                    recruitment_status=status.get("overallStatus"),
                    study_type=design.get("studyType"),
                    participants=int(enrollment) if enrollment is not None else None,
                    sponsor=lead,
                    primary_completion_date=(status.get("primaryCompletionDateStruct") or {}).get("date"),
                    results_available=bool((study.get("hasResults") if "hasResults" in study else status.get("resultsFirstPostDateStruct"))),
                    trial_url=f"https://clinicaltrials.gov/study/{nct}",
                    target_or_mechanism=desc.get("briefSummary"),
                )
            )
        return records
