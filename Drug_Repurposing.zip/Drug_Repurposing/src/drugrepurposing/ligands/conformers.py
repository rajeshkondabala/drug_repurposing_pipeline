from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import LigandsCfg
from drugrepurposing.schemas.ligand import LigandIssue, LigandRecord


def _rdkit():
    from rdkit import Chem  # type: ignore
    from rdkit.Chem import AllChem, rdDistGeom  # type: ignore

    return Chem, AllChem, rdDistGeom


def sdf_has_3d(mol) -> bool:
    if mol.GetNumConformers() == 0:
        return False
    conf = mol.GetConformer()
    zs = [conf.GetAtomPosition(i).z for i in range(mol.GetNumAtoms())]
    return max(zs) - min(zs) > 0.01


def generate_conformers(record: LigandRecord, cfg: LigandsCfg, dest_sdf: Path) -> LigandRecord:
    Chem, AllChem, rdDistGeom = _rdkit()
    mol = None
    if record.input_format in {"sdf", "sd"} and record.input_path:
        suppl = Chem.SDMolSupplier(record.input_path, removeHs=False)
        mol = next((item for item in suppl if item is not None), None)
        if mol is not None:
            record.had_3d_coordinates = sdf_has_3d(mol)
            if not record.smiles:
                record.smiles = Chem.MolToSmiles(mol)
    if mol is None:
        if not record.canonical_smiles and not record.smiles:
            record.issues.append(LigandIssue(code="empty_structure", message="No SMILES for 3D generation"))
            return record
        mol = Chem.MolFromSmiles(record.canonical_smiles or record.smiles or "")
        if mol is None:
            record.issues.append(LigandIssue(code="invalid_smiles", message="Cannot embed invalid SMILES"))
            return record
        mol = Chem.AddHs(mol)
    else:
        mol = Chem.AddHs(mol)
        if not record.had_3d_coordinates:
            record.issues.append(LigandIssue(code="sdf_2d", message="SDF had 2D coordinates; regenerating 3D", severity="warning"))

    if cfg.generate_conformers or not record.had_3d_coordinates:
        params = rdDistGeom.ETKDGv3()
        params.randomSeed = cfg.random_seed
        cids = rdDistGeom.EmbedMultipleConfs(mol, numConfs=cfg.num_conformers, params=params)
        if not cids:
            record.issues.append(LigandIssue(code="embed_failed", message="Conformer embedding failed"))
            return record
    dest_sdf.parent.mkdir(parents=True, exist_ok=True)
    writer = Chem.SDWriter(str(dest_sdf))
    writer.write(mol)
    writer.close()
    record.sdf_path = str(dest_sdf)
    record.preparation_manifest["conformer_backend"] = "rdkit_etkdg"
    record.preparation_manifest["random_seed"] = cfg.random_seed
    return record
