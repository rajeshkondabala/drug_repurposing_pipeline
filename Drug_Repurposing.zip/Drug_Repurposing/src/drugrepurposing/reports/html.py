from __future__ import annotations

from jinja2 import Environment, BaseLoader

from drugrepurposing import RESEARCH_DISCLAIMER
from drugrepurposing.config import AppConfig
from drugrepurposing.provenance import ProvenanceTracker
from drugrepurposing.utils.io import atomic_write_text
from drugrepurposing.workflows import ProjectWorkspace

TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <title>drug-repurposing report</title>
  <style>
    body { font-family: Georgia, serif; margin: 2rem; color: #222; }
    .banner { background: #fff3cd; border: 1px solid #ffeeba; padding: 1rem; }
    table { border-collapse: collapse; width: 100%; margin: 1rem 0; font-size: 0.9rem; }
    th, td { border: 1px solid #ccc; padding: 0.4rem 0.5rem; text-align: left; }
    h1,h2 { color: #1b4f72; }
    .muted { color: #555; }
  </style>
</head>
<body>
  <h1>drug-repurposing report</h1>
  <p class="banner">{{ disclaimer }}</p>
  <h2>1. User condition</h2>
  <p>{{ condition.input_condition if condition else "n/a" }}</p>
  <h2>2. Condition resolution</h2>
  {% if condition and condition.selected_condition %}
  <p>Selected: {{ condition.selected_condition.name }} ({{ condition.selected_condition.id }}, {{ condition.selected_condition.ontology }})</p>
  <p>Method: {{ condition.resolution_method }}</p>
  {% if condition.alternatives %}
  <p>Alternatives: {% for a in condition.alternatives %}{{ a.name }} ({{ a.id }}){% if not loop.last %}; {% endif %}{% endfor %}</p>
  {% endif %}
  {% else %}<p>Unresolved</p>{% endif %}

  <h2>3. Ranked targets (evidence score only)</h2>
  <table>
    <tr><th>Target</th><th>Overall</th><th>Confidence</th><th>Completeness</th><th>Novelty</th><th>Maturity</th></tr>
    {% for t in scores %}
    <tr>
      <td>{{ t.symbol }}</td><td>{{ t.overall_score }}</td><td>{{ t.evidence_confidence }}</td>
      <td>{{ t.data_completeness }}</td><td>{{ t.novelty_category }}</td><td>{{ t.known_therapeutic_maturity }}</td>
    </tr>
    {% endfor %}
  </table>

  <h2>4. Evidence breakdown</h2>
  {% for t in scores %}
    <h3>{{ t.symbol }} — {{ t.overall_score }}</h3>
    <p>{{ t.explanation }}</p>
    <ul>
      {% for c in t.contributors %}<li>{{ c }}</li>{% endfor %}
    </ul>
    <p>Limitations:</p>
    <ul>{% for c in t.limitations %}<li>{{ c }}</li>{% endfor %}</ul>
    <p>Uncertainties:</p>
    <ul>{% for c in t.uncertainties %}<li>{{ c }}</li>{% endfor %}</ul>
    <p>Recommended follow-up:</p>
    <ul>{% for c in t.recommended_experimental_follow_up %}<li>{{ c }}</li>{% endfor %}</ul>
  {% endfor %}

  <h2>5. Existing drugs and clinical-stage compounds</h2>
  <table>
    <tr><th>Name</th><th>ChEMBL</th><th>MoA</th><th>Phase</th></tr>
    {% for d in drugs %}
    <tr><td>{{ d.name }}</td><td>{{ d.chembl_id }}</td><td>{{ d.mechanism_of_action }}</td><td>{{ d.phase }}</td></tr>
    {% endfor %}
  </table>

  <h2>6. Candidate novel or understudied targets</h2>
  <ul>
    {% for t in scores if t.novelty_category in ["candidate_novel_target", "understudied_target"] %}
    <li>{{ t.symbol }} ({{ t.novelty_category }}): Candidate novel or understudied target based on the searched sources and date of analysis.</li>
    {% endfor %}
  </ul>

  <h2>7. Other diseases associated with each target</h2>
  <p class="muted">Association with another disease is not proof that the target is useful for the requested condition.</p>
  {% for tgt in targets %}
    <h4>{{ tgt.identifiers.approved_symbol }}</h4>
    <ul>
      {% for c in tgt.cross_condition[:8] %}
      <li>{{ c.disease_name }} ({{ c.association_class }}, score={{ c.score }})</li>
      {% endfor %}
    </ul>
  {% endfor %}

  <h2>8–11. Structures, chains, repairs, pockets</h2>
  {% for s in structures %}
    <p><strong>{{ s.pdb_id or s.alphafold_id }}</strong> score={{ s.structure_score }} — {{ s.selection_reason }}</p>
    <ul>
      {% for ch in s.chains %}
      <li>Chain {{ ch.chain_id }} selected={{ ch.selected }} {{ ch.selection_reason }} missing_internal={{ ch.missing_internal|length }}</li>
      {% endfor %}
      {% for p in s.pockets %}
      <li>Pocket {{ p.pocket_id }} method={{ p.method }} experimental={{ p.experimental }} {{ p.warnings }}</li>
      {% endfor %}
    </ul>
    {% if s.repaired %}<p>Repaired residues: {{ s.inserted_residues }}. Repaired loops are not experimental.</p>{% endif %}
  {% endfor %}

  <h2>12. Ligand preparation</h2>
  <table>
    <tr><th>ID</th><th>SMILES</th><th>Force field</th><th>E_after</th></tr>
    {% for lig in ligands %}
    <tr><td>{{ lig.compound_id }}</td><td>{{ lig.canonical_smiles or lig.smiles }}</td><td>{{ lig.force_field }}</td><td>{{ lig.energy_after }}</td></tr>
    {% endfor %}
  </table>

  <h2>13–14. Docking results and best poses</h2>
  <p class="muted">Docking scores are computational scores, not binding free energies, and are not merged with the evidence score.</p>
  <table>
    <tr><th>Ligand</th><th>Structure</th><th>Pocket</th><th>Rank</th><th>Vina</th><th>CNN</th><th>Final pose</th></tr>
    {% for p in poses %}
    <tr>
      <td>{{ p.ligand_id }}</td><td>{{ p.structure_id }}</td><td>{{ p.pocket_id }}</td>
      <td>{{ p.pose_rank }}</td><td>{{ p.vina_score }}</td><td>{{ p.cnn_score }}</td><td>{{ p.final_pose_score }}</td>
    </tr>
    {% endfor %}
  </table>

  <h2>15. Warnings and limitations</h2>
  <ul>{% for w in warnings %}<li>{{ w }}</li>{% endfor %}</ul>

  <h2>16–17. Citations, licenses, attribution</h2>
  <p>See reports/license_report.csv and provenance.json. Open Targets data CC0; software Apache-2.0.
  RCSB/wwPDB archive and API data CC0. AlphaFold DB CC-BY-4.0. PubChem CC-BY-4.0. UniProt CC-BY-4.0.
  ChEMBL CC-BY-SA-3.0. PDBFixer MIT. GNINA licensing depends on the user-supplied binary.</p>
</body>
</html>
"""


def write_html_report(workspace: ProjectWorkspace, config: AppConfig, provenance: ProvenanceTracker) -> None:
    env = Environment(loader=BaseLoader(), autoescape=True)
    template = env.from_string(TEMPLATE)
    html = template.render(
        disclaimer=RESEARCH_DISCLAIMER,
        condition=workspace.read_json("targets/condition_resolution.json"),
        scores=workspace.read_json("targets/scores.json") or [],
        drugs=workspace.read_json("targets/drugs.json") or [],
        targets=workspace.read_json("targets/targets.json") or [],
        structures=workspace.read_json("structures/selected.json") or [],
        ligands=workspace.read_json("ligands/ligands.json") or [],
        poses=workspace.read_json("docking/poses.json") or [],
        warnings=provenance.manifest.get("warnings") or [],
    )
    atomic_write_text(workspace.root / "reports" / "report.html", html)
    _ = config
