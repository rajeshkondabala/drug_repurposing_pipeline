# Changelog

## 0.1.1

Distribution-prep release. Research/hypothesis generation only.

- Core conda environment no longer installs Meeko (LGPL) or pyKVFinder (GPL-3). Use `environment-extras.yml`.
- Example config no longer embeds a machine-local GNINA path. Put it in `examples/config.local.yaml` (gitignored) or pass `--gnina-path`.
- ChEMBL cleaned ligand dumps are gitignored; they are not part of the source distribution (CC-BY-SA-3.0).
- Structure prep walks the ranked evidence list until `structures.max_prepared_targets` (default 5) succeed, instead of only the first target.
- Missing RCSB PDB files (HTTP 404, including mmCIF-only entries) no longer abort `run`; the next ranked structure is used, with mmCIF→PDB conversion when possible.
- Docking uses the repaired receptor for each target, not the first `repaired.pdb` in the project.
- Ligand preparation and receptor PDBQT generation skip finished files.
- PDB fixture columns are OpenMM-compatible; PDBFixer tests no longer false-fail.
- Added GitHub Actions CI, MANIFEST.in, CHANGELOG, CONTRIBUTING, and SECURITY notes.

## 0.1.0

Initial internal research CLI: Open Targets evidence, structure prep, RDKit ligands, user-supplied GNINA docking, provenance reports.
