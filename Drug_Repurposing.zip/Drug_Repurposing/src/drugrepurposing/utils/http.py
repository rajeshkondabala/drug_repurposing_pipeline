from __future__ import annotations

import json
from typing import Any

import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from drugrepurposing.config import AppConfig
from drugrepurposing.logging_utils import get_logger
from drugrepurposing.utils.cache import ContentAddressedCache, utcnow_iso
from drugrepurposing.utils.hashes import sha256_bytes, sha256_json
from drugrepurposing.utils.retry import TokenBucket

LOGGER = get_logger("http")


class HttpError(RuntimeError):
    pass


class RetryableHttpError(HttpError):
    pass


class HttpClient:
    def __init__(self, config: AppConfig, cache: ContentAddressedCache) -> None:
        self.config = config
        self.cache = cache
        self.bucket = TokenBucket(config.http.rate_limit_per_second)
        self._client = httpx.Client(
            timeout=config.http.timeout_seconds,
            headers={"User-Agent": config.project.user_agent},
            follow_redirects=True,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "HttpClient":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def _cache_payload(
        self, method: str, url: str, params: dict[str, Any] | None, json_body: Any
    ) -> dict[str, Any]:
        return {
            "method": method.upper(),
            "url": url,
            "params": params or {},
            "body": json_body,
            "api_version": url,
        }

    def request_json(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        json_body: Any = None,
        namespace: str = "http",
        source_name: str,
        license_or_terms: str | None,
        source_version: str | None = None,
    ) -> dict[str, Any]:
        cache_key = self._cache_payload(method, url, params, json_body)
        cached = self.cache.get_json(namespace, cache_key)
        if cached is not None:
            LOGGER.debug("cache_hit", extra={"url": url, "source": source_name})
            return cached
        if self.config.cache.offline:
            raise HttpError(f"Offline cache miss for {url}")
        envelope = self._live_json(method, url, params=params, json_body=json_body)
        record = {
            "source_name": source_name,
            "source_url": url,
            "accessed_at": utcnow_iso(),
            "source_version": source_version,
            "query": {"params": params, "body": json_body},
            "raw_record_hash": sha256_json(envelope),
            "license_or_terms": license_or_terms,
            "payload": envelope,
        }
        self.cache.put_json(namespace, cache_key, record)
        return record

    @retry(
        reraise=True,
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=1, max=30),
        retry=retry_if_exception_type((httpx.TransportError, RetryableHttpError)),
    )
    def _live_json(
        self,
        method: str,
        url: str,
        params: dict[str, Any] | None,
        json_body: Any,
    ) -> Any:
        self.bucket.acquire()
        response = self._client.request(method, url, params=params, json=json_body)
        if response.status_code >= 500:
            raise RetryableHttpError(f"{url} returned {response.status_code}")
        if response.status_code >= 400:
            raise HttpError(f"{url} returned {response.status_code}: {response.text[:400]}")
        if not response.content:
            return {}
        try:
            return response.json()
        except json.JSONDecodeError as exc:
            raise HttpError(f"Non-JSON response from {url}") from exc

    def get_bytes(
        self,
        url: str,
        *,
        namespace: str,
        suffix: str,
        source_name: str,
        license_or_terms: str | None,
    ) -> tuple[bytes, dict[str, Any]]:
        cache_key = {"url": url}
        cached = self.cache.get_bytes(namespace, cache_key, suffix=suffix)
        meta = self.cache.get_json(namespace, {**cache_key, "meta": True})
        if cached is not None and meta is not None:
            return cached, meta
        if self.config.cache.offline:
            raise HttpError(f"Offline cache miss for binary {url}")
        data = self._live_bytes(url)
        path = self.cache.put_bytes(namespace, cache_key, data, suffix=suffix)
        meta = {
            "source_name": source_name,
            "source_url": url,
            "accessed_at": utcnow_iso(),
            "raw_record_hash": sha256_bytes(data),
            "license_or_terms": license_or_terms,
            "path": str(path),
        }
        self.cache.put_json(namespace, {**cache_key, "meta": True}, meta)
        return data, meta

    @retry(
        reraise=True,
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=1, max=30),
        retry=retry_if_exception_type((httpx.TransportError, RetryableHttpError)),
    )
    def _live_bytes(self, url: str) -> bytes:
        self.bucket.acquire()
        response = self._client.get(url)
        if response.status_code >= 500:
            raise RetryableHttpError(f"{url} returned {response.status_code}")
        if response.status_code >= 400:
            raise HttpError(f"{url} returned {response.status_code}")
        return response.content
