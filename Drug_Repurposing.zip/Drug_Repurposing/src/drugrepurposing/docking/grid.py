from __future__ import annotations

from drugrepurposing.schemas.structure import PocketDefinition


def box_from_pocket(pocket: PocketDefinition) -> dict[str, float]:
    cx, cy, cz = pocket.center
    sx, sy, sz = pocket.dimensions
    return {
        "center_x": float(cx),
        "center_y": float(cy),
        "center_z": float(cz),
        "size_x": max(float(sx), 10.0),
        "size_y": max(float(sy), 10.0),
        "size_z": max(float(sz), 10.0),
    }


def validate_box(box: dict[str, float]) -> list[str]:
    warnings = []
    for key in ("size_x", "size_y", "size_z"):
        if box[key] > 40:
            warnings.append(f"Large docking box {key}={box[key]:.1f} Å")
        if box[key] < 8:
            warnings.append(f"Small docking box {key}={box[key]:.1f} Å")
    return warnings
