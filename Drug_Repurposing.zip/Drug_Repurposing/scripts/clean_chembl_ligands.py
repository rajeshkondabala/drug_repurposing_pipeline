#!/usr/bin/env python3
"""Clean a ChEMBL parent-molecule SMILES table into project ligand CSV format."""

from __future__ import annotations

import argparse
import csv
import re
from collections import defaultdict
from pathlib import Path

CHEMBL_RE = re.compile(r"^CHEMBL\d+$")
ORGANIC_CORE = {"H", "C", "N", "O", "F", "P", "S", "Cl", "Br", "I", "B", "Si", "Se", "As"}


def _rdkit():
    from rdkit import Chem, RDLogger
    from rdkit.Chem import Descriptors, inchi, rdMolDescriptors, SaltRemover
    from rdkit.Chem.MolStandardize import rdMolStandardize

    RDLogger.DisableLog("rdApp.*")
    return Chem, Descriptors, inchi, rdMolDescriptors, SaltRemover, rdMolStandardize


def _largest_organic_fragment(Chem, mol):
    frags = Chem.GetMolFrags(mol, asMols=True, sanitizeFrags=False)
    if not frags:
        return mol
    return max(
        frags,
        key=lambda m: (
            sum(1 for a in m.GetAtoms() if a.GetAtomicNum() == 6),
            m.GetNumHeavyAtoms(),
        ),
    )


def clean_table(
    src: Path,
    cleaned: Path,
    qc: Path,
    rejected: Path,
    *,
    min_heavy: int = 3,
    max_heavy: int = 120,
) -> dict[str, int]:
    Chem, Descriptors, inchi, rdMolDescriptors, SaltRemover, rdMolStandardize = _rdkit()
    remover = SaltRemover.SaltRemover()
    lfc = rdMolStandardize.LargestFragmentChooser()
    uncharger = rdMolStandardize.Uncharger()

    with src.open(newline="", encoding="utf-8") as handle:
        sample = handle.read(4096)
        handle.seek(0)
        dialect = csv.Sniffer().sniff(sample, delimiters=",\t;")
        reader = csv.DictReader(handle, dialect=dialect)
        fieldnames = reader.fieldnames or []
        id_col = next((c for c in fieldnames if c.lower() in {"parent molecule", "chembl_id", "compound_id", "molecule_chembl_id"}), fieldnames[0])
        smi_col = next((c for c in fieldnames if c.lower() in {"smiles", "canonical_smiles", "canonical smiles"}), fieldnames[1] if len(fieldnames) > 1 else fieldnames[0])
        raw_rows = [(i, (row.get(id_col) or "").strip(), (row.get(smi_col) or "").strip()) for i, row in enumerate(reader, start=2)]

    reject: list[dict[str, str]] = []
    keep: list[dict] = []

    def add_reject(line: int, cid: str, smi: str, reason: str, detail: str = "") -> None:
        reject.append({"line": str(line), "compound_id": cid, "smiles": smi, "reason": reason, "detail": detail})

    for line, cid, smi in raw_rows:
        if not cid:
            add_reject(line, cid, smi, "empty_id")
            continue
        if not CHEMBL_RE.match(cid):
            add_reject(line, cid, smi, "bad_chembl_id")
            continue
        if not smi:
            add_reject(line, cid, smi, "empty_smiles")
            continue
        mol = Chem.MolFromSmiles(smi)
        if mol is None:
            add_reject(line, cid, smi, "invalid_smiles")
            continue
        try:
            Chem.SanitizeMol(mol)
        except Exception as exc:
            add_reject(line, cid, smi, "sanitize_failed", str(exc))
            continue
        n_atoms0 = mol.GetNumHeavyAtoms()
        was_mixture = "." in smi
        stripped = remover.StripMol(mol)
        mol2 = stripped if stripped is not None and stripped.GetNumHeavyAtoms() > 0 else lfc.choose(mol)
        if mol2 is None or mol2.GetNumHeavyAtoms() == 0:
            add_reject(line, cid, smi, "empty_after_salt_strip")
            continue
        mol2 = _largest_organic_fragment(Chem, mol2)
        try:
            Chem.SanitizeMol(mol2)
        except Exception as exc:
            add_reject(line, cid, smi, "sanitize_failed_fragment", str(exc))
            continue
        salt_stripped = mol2.GetNumHeavyAtoms() != n_atoms0 or was_mixture
        try:
            mol3 = uncharger.uncharge(mol2)
            Chem.SanitizeMol(mol3)
            mol2 = mol3
        except Exception:
            pass
        elems = {a.GetSymbol() for a in mol2.GetAtoms()}
        forbidden = elems - ORGANIC_CORE
        if forbidden:
            add_reject(line, cid, smi, "disallowed_elements", ",".join(sorted(forbidden)))
            continue
        ha = mol2.GetNumHeavyAtoms()
        if ha < min_heavy:
            add_reject(line, cid, smi, "too_few_heavy_atoms", str(ha))
            continue
        if ha > max_heavy:
            add_reject(line, cid, smi, "too_many_heavy_atoms", str(ha))
            continue
        if not any(a.GetAtomicNum() == 6 for a in mol2.GetAtoms()):
            add_reject(line, cid, smi, "no_carbon")
            continue
        if any(a.GetNumRadicalElectrons() for a in mol2.GetAtoms()):
            add_reject(line, cid, smi, "radical")
            continue
        try:
            can = Chem.MolToSmiles(mol2, canonical=True, isomericSmiles=True)
        except Exception as exc:
            add_reject(line, cid, smi, "canonical_failed", str(exc))
            continue
        try:
            ik = inchi.MolToInchiKey(mol2) or ""
        except Exception:
            ik = ""
        keep.append(
            {
                "compound_id": cid,
                "smiles": can,
                "name": cid,
                "inchikey": ik,
                "heavy_atoms": ha,
                "molwt": round(Descriptors.MolWt(mol2), 2),
                "n_rotatable": rdMolDescriptors.CalcNumRotatableBonds(mol2),
                "formal_charge": Chem.GetFormalCharge(mol2),
                "salt_stripped": int(salt_stripped),
                "has_stereo": int(any(tok in can for tok in ("@", "/", "\\"))),
                "input_smiles": smi,
                "source_line": line,
            }
        )

    final: list[dict] = []
    seen_id: set[str] = set()
    seen_ik: set[str] = set()
    for rec in keep:
        cid = rec["compound_id"]
        if cid in seen_id:
            add_reject(rec["source_line"], cid, rec["input_smiles"], "duplicate_chembl_id")
            continue
        seen_id.add(cid)
        ik = rec["inchikey"]
        if ik and ik in seen_ik:
            add_reject(rec["source_line"], cid, rec["input_smiles"], "duplicate_structure", ik)
            continue
        if ik:
            seen_ik.add(ik)
        final.append(rec)

    cleaned.parent.mkdir(parents=True, exist_ok=True)
    with cleaned.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["compound_id", "smiles", "name"])
        writer.writeheader()
        for rec in final:
            writer.writerow({k: rec[k] for k in ["compound_id", "smiles", "name"]})
    with qc.open("w", newline="", encoding="utf-8") as handle:
        fields = [
            "compound_id",
            "smiles",
            "name",
            "inchikey",
            "heavy_atoms",
            "molwt",
            "n_rotatable",
            "formal_charge",
            "salt_stripped",
            "has_stereo",
            "input_smiles",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for rec in final:
            writer.writerow({k: rec[k] for k in fields})
    with rejected.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["line", "compound_id", "smiles", "reason", "detail"])
        writer.writeheader()
        writer.writerows(reject)

    reasons: dict[str, int] = defaultdict(int)
    for row in reject:
        reasons[row["reason"]] += 1
    return {"input": len(raw_rows), "kept": len(final), "rejected": len(reject), **reasons}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("--out-dir", type=Path, default=Path("data/ligands"))
    args = parser.parse_args()
    out = args.out_dir
    stats = clean_table(
        args.input_csv,
        out / "Drugs_Chembl.cleaned.csv",
        out / "Drugs_Chembl.cleaned_with_qc.csv",
        out / "Drugs_Chembl.rejected.csv",
    )
    print(stats)


if __name__ == "__main__":
    main()
