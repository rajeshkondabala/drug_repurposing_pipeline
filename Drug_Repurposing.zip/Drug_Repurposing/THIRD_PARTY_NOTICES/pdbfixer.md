PDBFixer — MIT License
https://github.com/openmm/pdbfixer/blob/master/LICENSE

Copyright notices from upstream must be preserved when redistributing.
