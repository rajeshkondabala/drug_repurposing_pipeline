from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import AppConfig
from drugrepurposing.provenance import ProvenanceTracker
from drugrepurposing.reports.html import write_html_report
from drugrepurposing.reports.json_report import write_json_report
from drugrepurposing.reports.tables import write_csv_reports, write_license_report
from drugrepurposing.store import WorkflowState
from drugrepurposing.utils.cache import ContentAddressedCache
from drugrepurposing.utils.http import HttpClient
from drugrepurposing.workflows import ProjectWorkspace
from drugrepurposing.workflows.docking_workflow import dock_project
from drugrepurposing.workflows.ligand_workflow import prepare_ligands
from drugrepurposing.workflows.structure_workflow import prepare_structures
from drugrepurposing.workflows.target_workflow import analyze_targets


def run_pipeline(
    *,
    condition: str,
    ligands: Path | None,
    gnina_path: str | None,
    output: Path,
    config: AppConfig,
    selected_id: str | None = None,
    skip_docking: bool = False,
) -> Path:
    workspace = ProjectWorkspace(output)
    provenance = ProvenanceTracker(output, config)
    cache = ContentAddressedCache(Path(config.cache.directory), enabled=config.cache.enabled)
    with HttpClient(config, cache) as http:
        analyze_targets(condition, config, workspace, http, provenance, selected_id=selected_id)
        if skip_docking:
            provenance.warn(
                "--skip-docking: structure preparation, ligand preparation, and GNINA were not run. "
                "This output is evidence ranking only."
            )
            if ligands:
                provenance.warn(f"Ignoring ligand table {ligands} because --skip-docking was set.")
        else:
            prepare_structures(
                config, workspace, http, provenance, max_targets=config.structures.max_prepared_targets
            )
            if ligands:
                prepare_ligands(ligands, output / "ligands", config, provenance, workspace)
            if (gnina_path or config.docking.gnina_path) and ligands:
                dock_project(config, workspace, provenance, gnina_path=gnina_path)
            elif ligands:
                provenance.warn("Ligands were prepared but docking was skipped (no GNINA path).")
        write_csv_reports(workspace, config)
        write_json_report(workspace, config, provenance)
        write_html_report(workspace, config, provenance)
        write_license_report(workspace, config)
        workspace.set_state(WorkflowState.REPORT_GENERATED)
        provenance.set_status(WorkflowState.REPORT_GENERATED.value)
        provenance.write()
    return output
