from __future__ import annotations

from drugrepurposing.config import AppConfig
from drugrepurposing.evidence.target_scoring import score_target
from drugrepurposing.logging_utils import get_logger
from drugrepurposing.provenance import ProvenanceTracker
from drugrepurposing.schemas.evidence import TargetScoreBreakdown
from drugrepurposing.schemas.target import TargetRecord
from drugrepurposing.sources.clinicaltrials import ClinicalTrialsClient
from drugrepurposing.sources.europe_pmc import EuropePMCClient
from drugrepurposing.sources.opentargets import OpenTargetsClient
from drugrepurposing.store import WorkflowState
from drugrepurposing.utils.http import HttpClient, HttpError
from drugrepurposing.workflows import ProjectWorkspace, attach_known_drugs

LOGGER = get_logger("targets")


def analyze_targets(
    condition_text: str,
    config: AppConfig,
    workspace: ProjectWorkspace,
    http: HttpClient,
    provenance: ProvenanceTracker,
    selected_id: str | None = None,
) -> dict:
    ot = OpenTargetsClient(config, http)
    cached = workspace.read_json("targets/condition_resolution.json")
    if cached and cached.get("selected_condition"):
        from drugrepurposing.schemas.disease import ConditionResolution

        resolution = ConditionResolution.model_validate(cached)
    else:
        resolution = ot.search_conditions(condition_text)
        if selected_id:
            resolution = ot.confirm(resolution, selected_id)
        workspace.write_json("targets/condition_resolution.json", resolution.model_dump(mode="json"))
    if resolution.requires_confirmation and not resolution.selected_condition:
        provenance.warn("Multiple conditions require user confirmation.")
        workspace.set_state(WorkflowState.INITIALIZED, {"awaiting_confirmation": True})
        return {"resolution": resolution.model_dump(mode="json"), "awaiting_confirmation": True}
    if not resolution.selected_condition:
        raise RuntimeError(
            f"Could not resolve condition '{condition_text}'. Try an EFO/MONDO identifier."
        )
    provenance.add_source({"source_name": "Open Targets Platform", "source_url": ot.api_url, "license_or_terms": ot.license, "accessed_at": None})
    workspace.set_state(WorkflowState.CONDITION_RESOLVED)
    disease = resolution.selected_condition
    targets: list[TargetRecord] = ot.associated_targets(disease.id)
    drugs = ot.known_drugs(disease.id)
    attach_known_drugs(targets, drugs)
    search_ok = True
    literature_client = EuropePMCClient(config, http)
    trials_client = ClinicalTrialsClient(config, http)
    scored: list[TargetScoreBreakdown] = []
    weights = (config.scoring or {}).get("weights") or {}
    lit_w = (config.scoring or {}).get("literature_components") or {}
    novelty_cfg = (config.scoring or {}).get("novelty") or {}
    for target in targets:
        symbol = target.identifiers.approved_symbol or target.identifiers.ensembl_gene_id or "unknown"
        query = f'("{symbol}" AND "{disease.name}")'
        try:
            literature = literature_client.search(query)
        except HttpError:
            literature = []
            search_ok = False
            provenance.warn(f"Literature source outage for {symbol}")
        try:
            trials = trials_client.search(disease.name, intervention=symbol)
        except HttpError:
            trials = []
            search_ok = False
            provenance.warn(f"ClinicalTrials.gov outage for {symbol}")
        if target.identifiers.ensembl_gene_id:
            target.cross_condition = ot.cross_condition(target.identifiers.ensembl_gene_id)
        breakdown = score_target(
            target,
            weights=weights,
            literature_weights=lit_w,
            novelty_cfg=novelty_cfg,
            literature=literature,
            trials=trials,
            drugs=target.known_drugs,
            search_succeeded=search_ok,
            condition_id=disease.id,
        )
        if not literature:
            provenance.warn(f"No human literature retrieved for {symbol}.")
        scored.append(breakdown)
        workspace.write_json(
            f"evidence/{symbol}.json",
            {
                "target": target.model_dump(mode="json"),
                "score": breakdown.model_dump(mode="json"),
                "literature": [item.model_dump(mode="json") for item in literature],
                "trials": [item.model_dump(mode="json") for item in trials],
            },
        )
    scored.sort(key=lambda item: item.overall_score, reverse=True)
    workspace.write_json("targets/targets.json", [t.model_dump(mode="json") for t in targets])
    workspace.write_json("targets/scores.json", [s.model_dump(mode="json") for s in scored])
    workspace.write_json("targets/drugs.json", [d.model_dump(mode="json") for d in drugs])
    workspace.set_state(WorkflowState.TARGETS_RANKED)
    provenance.set_status(WorkflowState.TARGETS_RANKED.value)
    LOGGER.info("ranked_targets", extra={"n": len(scored)})
    return {
        "resolution": resolution.model_dump(mode="json"),
        "targets": [t.model_dump(mode="json") for t in targets],
        "scores": [s.model_dump(mode="json") for s in scored],
        "drugs": [d.model_dump(mode="json") for d in drugs],
    }
