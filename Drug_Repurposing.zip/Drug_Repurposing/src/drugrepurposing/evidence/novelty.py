from __future__ import annotations

from drugrepurposing import NOVELTY_DISCLAIMER
from drugrepurposing.schemas.evidence import ClinicalPhase, ClinicalTrialRecord, NoveltyCategory
from drugrepurposing.schemas.target import KnownDrug, TargetRecord


PHASE_RANK = {
    ClinicalPhase.UNKNOWN: 0,
    ClinicalPhase.NOT_APPLICABLE: 0,
    ClinicalPhase.PRECLINICAL: 1,
    ClinicalPhase.PHASE_1: 2,
    ClinicalPhase.PHASE_1_2: 3,
    ClinicalPhase.PHASE_2: 4,
    ClinicalPhase.PHASE_2_3: 5,
    ClinicalPhase.PHASE_3: 6,
    ClinicalPhase.PHASE_4: 7,
}


def highest_phase(trials: list[ClinicalTrialRecord], drugs: list[KnownDrug]) -> ClinicalPhase:
    best = ClinicalPhase.UNKNOWN
    for trial in trials:
        if PHASE_RANK[trial.phase] > PHASE_RANK[best]:
            best = trial.phase
    for drug in drugs:
        text = str(drug.phase or "").lower()
        mapped = ClinicalPhase.UNKNOWN
        if "4" in text:
            mapped = ClinicalPhase.PHASE_4
        elif "3" in text:
            mapped = ClinicalPhase.PHASE_3
        elif "2" in text:
            mapped = ClinicalPhase.PHASE_2
        elif "1" in text:
            mapped = ClinicalPhase.PHASE_1
        if PHASE_RANK[mapped] > PHASE_RANK[best]:
            best = mapped
    return best


def classify_novelty(
    *,
    target: TargetRecord,
    association: float,
    mechanistic: float,
    completeness: float,
    independent_sources: int,
    trials: list[ClinicalTrialRecord],
    drugs: list[KnownDrug],
    search_succeeded: bool,
    min_association_or_mechanistic: float,
    min_completeness: float,
    min_independent_sources: int,
) -> tuple[NoveltyCategory, str]:
    phase = highest_phase(trials, drugs)
    if phase in {ClinicalPhase.PHASE_4, ClinicalPhase.PHASE_3}:
        return NoveltyCategory.ESTABLISHED, "Approved or late-stage programs identified in searched sources."
    if PHASE_RANK[phase] >= PHASE_RANK[ClinicalPhase.PHASE_1]:
        return NoveltyCategory.CLINICALLY_ACTIVE, "Clinical-stage activity identified; not a novel target."
    if phase == ClinicalPhase.PRECLINICAL or drugs:
        return NoveltyCategory.PRECLINICAL, "Preclinical or compound-level activity identified."
    if not search_succeeded or completeness < min_completeness:
        return NoveltyCategory.INSUFFICIENT, "Search completeness below threshold; novelty not assessed."
    strong = max(association, mechanistic) >= min_association_or_mechanistic
    if not strong or independent_sources < min_independent_sources:
        if association < 0.15 and mechanistic < 0.15:
            return NoveltyCategory.INSUFFICIENT, "Weak or single-source evidence is insufficient for a novelty claim."
        return NoveltyCategory.UNDERSTUDIED, (
            "Limited therapeutic annotation in searched sources. This is not proof of novelty. "
            + NOVELTY_DISCLAIMER
        )
    if not drugs and PHASE_RANK[phase] <= PHASE_RANK[ClinicalPhase.UNKNOWN]:
        return NoveltyCategory.CANDIDATE_NOVEL, NOVELTY_DISCLAIMER
    return NoveltyCategory.UNDERSTUDIED, NOVELTY_DISCLAIMER
