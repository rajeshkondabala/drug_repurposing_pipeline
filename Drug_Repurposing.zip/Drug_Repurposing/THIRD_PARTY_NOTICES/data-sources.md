Open Targets Platform data: CC0 1.0. Software: Apache-2.0.
Linked external evidence retains original licenses.
https://platform-docs.opentargets.org/data-access

RCSB PDB / wwPDB archive files and programmatic API data: CC0.
https://www.rcsb.org/pages/usage-policy

AlphaFold DB: CC BY 4.0 with attribution.
https://alphafold.ebi.ac.uk/assets/License-Disclaimer.pdf

PubChem: CC BY 4.0 with attribution.

UniProt: CC BY 4.0 with attribution.

ChEMBL: CC BY-SA 3.0 (share-alike may apply to adapted data products).

ClinicalTrials.gov: US government work.

PubMed / NLM: subject to NLM terms.

DrugBank is not enabled by default.
