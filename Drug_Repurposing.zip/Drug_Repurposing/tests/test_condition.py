from __future__ import annotations

import json
from pathlib import Path

from drugrepurposing.config import load_config
from drugrepurposing.sources.opentargets import OpenTargetsClient
from drugrepurposing.utils.cache import ContentAddressedCache
from drugrepurposing.utils.http import HttpClient

FIXTURES = Path(__file__).parent / "fixtures"


def test_exact_name_resolution(monkeypatch):
    cfg = load_config()
    cfg.condition.require_user_confirmation = True
    cache = ContentAddressedCache(Path("."), enabled=False)
    client = OpenTargetsClient(cfg, HttpClient(cfg, cache))
    payload = json.loads((FIXTURES / "ot_search.json").read_text())

    def fake_graphql(query, variables):
        return payload

    monkeypatch.setattr(client, "graphql", fake_graphql)
    result = client.search_conditions("rheumatoid arthritis")
    assert result.selected_condition is not None
    assert result.selected_condition.id == "EFO_0000685"
    assert result.resolution_method == "exact_name"
    assert result.alternatives
    data = json.loads(result.model_dump_json())
    assert data["input_condition"] == "rheumatoid arthritis"
    assert "selected_condition" in data


def test_ambiguous_requires_confirmation(monkeypatch):
    cfg = load_config()
    cfg.condition.require_user_confirmation = True
    cfg.condition.auto_select_if_unique = False
    cache = ContentAddressedCache(Path("."), enabled=False)
    client = OpenTargetsClient(cfg, HttpClient(cfg, cache))
    payload = json.loads((FIXTURES / "ot_search.json").read_text())
    payload["payload"]["data"]["search"]["hits"][0]["name"] = "RA like"
    monkeypatch.setattr(client, "graphql", lambda q, v: payload)
    result = client.search_conditions("mystery arthritis")
    assert result.requires_confirmation
    confirmed = client.confirm(result, "EFO_0000685")
    assert confirmed.selected_condition.id == "EFO_0000685"
