# Data sources

All adapters are optional, rate-limited, and provenance-bearing. Raw responses are cached separately from normalized records.

| Source | Default | Interface | Data license (see licensing.md) |
| --- | --- | --- | --- |
| Open Targets | on | GraphQL `https://api.platform.opentargets.org/api/v4/graphql` | data CC0; software Apache-2.0 |
| Europe PMC | on | REST search | mixed / attribution |
| PubMed | on | NCBI E-utilities | NLM terms |
| ClinicalTrials.gov | on | API v2 `/studies` | US government work |
| ChEMBL | on | REST | CC-BY-SA-3.0 |
| PubChem | on | PUG REST | CC-BY-4.0 |
| UniProt | on | REST | CC-BY-4.0 |
| RCSB PDB | on | search + data API + file download | CC0 archive/API |
| AlphaFold DB | on (fallback only) | prediction API | CC-BY-4.0 |
| Crossref | on | metadata | terms apply |
| Semantic Scholar | **off** | — | review terms first |
| DrugBank | **off** | — | redistribution restricted |
| DrugCentral | **off** | — | verify first |
| BindingDB | **off** | — | verify first |

Linked evidence inside Open Targets records is **not** assumed to be CC0.
