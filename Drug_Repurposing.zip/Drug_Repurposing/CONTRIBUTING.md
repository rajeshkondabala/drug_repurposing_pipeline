# Contributing

This is a research tool, not a clinical product. Do not add language that recommends drugs or diagnoses disease.

## Setup

```bash
conda env create -f environment.yml
conda activate drug-repurposing
python -m pip install -e ".[dev]"
pytest
```

Copyleft docking extras (optional, license review required):

```bash
conda env update -n drug-repurposing -f environment-extras.yml
```

## Rules

- Keep evidence scores and docking scores in separate tables. Never multiply them into a single “repurposing score”.
- Do not vendor GNINA, Open Babel, DrugBank, BindingDB, or DrugCentral.
- Do not commit ChEMBL compound dumps under `data/ligands/`.
- Machine-specific paths belong in `*.local.yaml`, not in tracked config.
- Add or update tests with behavior changes.
