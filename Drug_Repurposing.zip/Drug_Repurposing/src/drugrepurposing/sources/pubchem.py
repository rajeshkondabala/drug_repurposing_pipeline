from __future__ import annotations

from drugrepurposing.config import AppConfig
from drugrepurposing.schemas.evidence import CompoundRecord
from drugrepurposing.utils.http import HttpClient, HttpError


class PubChemClient:
    def __init__(self, config: AppConfig, http: HttpClient) -> None:
        self.config = config
        self.http = http
        self.base = config.sources.pubchem.base_url or "https://pubchem.ncbi.nlm.nih.gov/rest/pug"

    def compound_from_smiles(self, smiles: str, compound_id: str) -> CompoundRecord | None:
        if not self.config.sources.pubchem.enabled:
            return None
        url = f"{self.base}/compound/smiles/{smiles}/property/CanonicalSMILES,InChI,InChIKey,MolecularFormula,MolecularWeight/JSON"
        try:
            envelope = self.http.request_json(
                "GET",
                url,
                namespace="http",
                source_name="PubChem",
                license_or_terms="CC-BY-4.0; attribution required",
            )
        except HttpError:
            return None
        props = (envelope.get("payload", {}).get("PropertyTable", {}).get("Properties") or [{}])[0]
        return CompoundRecord(
            source_name="PubChem",
            source_url="https://pubchem.ncbi.nlm.nih.gov",
            accessed_at=envelope["accessed_at"],
            query=smiles,
            raw_record_hash=envelope.get("raw_record_hash"),
            license_or_terms="CC-BY-4.0",
            compound_id=compound_id,
            smiles=props.get("CanonicalSMILES") or smiles,
            inchi=props.get("InChI"),
            inchikey=props.get("InChIKey"),
            molecular_formula=props.get("MolecularFormula"),
            molecular_weight=props.get("MolecularWeight"),
        )
