from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field


class ProvenanceMixin(BaseModel):
    source_name: str
    source_url: str
    accessed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    source_version: str | None = None
    query: str | dict[str, Any] | None = None
    raw_record_hash: str | None = None
    license_or_terms: str | None = None


class DiseaseIdentifier(BaseModel):
    id: str
    name: str
    synonyms: list[str] = Field(default_factory=list)
    ontology: str | None = None
    description: str | None = None
    xrefs: dict[str, str] = Field(default_factory=dict)


class ConditionResolution(BaseModel):
    input_condition: str
    selected_condition: DiseaseIdentifier | None = None
    alternatives: list[DiseaseIdentifier] = Field(default_factory=list)
    requires_confirmation: bool = False
    resolution_method: str | None = None
    warnings: list[str] = Field(default_factory=list)
