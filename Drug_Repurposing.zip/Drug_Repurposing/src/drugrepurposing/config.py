from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field


class ProjectCfg(BaseModel):
    name: str = "example_project"
    output_dir: str = "outputs/example_project"
    random_seed: int = 42
    user_agent: str = "drug-repurposing/0.1.0 (research; not-for-clinical-use)"


class ConditionCfg(BaseModel):
    require_user_confirmation: bool = True
    max_search_hits: int = 10
    auto_select_if_unique: bool = True


class SourceItemCfg(BaseModel):
    enabled: bool = True
    api_url: str | None = None
    base_url: str | None = None
    search_url: str | None = None
    data_url: str | None = None
    files_url: str | None = None
    page_size: int | None = None
    api_key: str | None = None
    reason: str | None = None


class SourcesCfg(BaseModel):
    opentargets: SourceItemCfg = Field(
        default_factory=lambda: SourceItemCfg(
            enabled=True,
            api_url="https://api.platform.opentargets.org/api/v4/graphql",
            page_size=50,
        )
    )
    europe_pmc: SourceItemCfg = Field(default_factory=SourceItemCfg)
    pubmed: SourceItemCfg = Field(default_factory=SourceItemCfg)
    clinicaltrials: SourceItemCfg = Field(default_factory=SourceItemCfg)
    chembl: SourceItemCfg = Field(default_factory=SourceItemCfg)
    pubchem: SourceItemCfg = Field(default_factory=SourceItemCfg)
    uniprot: SourceItemCfg = Field(default_factory=SourceItemCfg)
    rcsb: SourceItemCfg = Field(default_factory=SourceItemCfg)
    alphafold: SourceItemCfg = Field(default_factory=SourceItemCfg)
    crossref: SourceItemCfg = Field(default_factory=SourceItemCfg)
    semantic_scholar: SourceItemCfg = Field(default_factory=lambda: SourceItemCfg(enabled=False))
    drugbank: SourceItemCfg = Field(default_factory=lambda: SourceItemCfg(enabled=False))
    drugcentral: SourceItemCfg = Field(default_factory=lambda: SourceItemCfg(enabled=False))
    bindingdb: SourceItemCfg = Field(default_factory=lambda: SourceItemCfg(enabled=False))


class EvidenceCfg(BaseModel):
    minimum_publication_count: int = 0
    recent_years: int = 10
    require_source_provenance: bool = True
    literature_page_size: int = 25
    trials_page_size: int = 50


class TargetsCfg(BaseModel):
    max_targets: int = 100
    include_non_druggable_targets: bool = True
    min_association_score: float = 0.0


class StructuresCfg(BaseModel):
    experimental_only_if_available: bool = True
    minimum_resolution: float = 4.0
    prefer_co_crystal_ligands: bool = True
    allow_mutants: bool = False
    allow_engineered_constructs: bool = True
    allow_predicted_structure: bool = True
    alphafold_top_pockets: int = 3
    pocket_padding_angstrom: float = 5.0
    keep_relevant_waters: bool = False
    keep_metals: bool = True
    keep_cofactors: bool = True
    max_structures_per_target: int = 5
    max_prepared_targets: int = 5
    chain_identity_threshold: float = 0.95
    exclude_if_pocket_missing_residues: bool = True
    modeller_plugin_enabled: bool = False


class LigandsCfg(BaseModel):
    strip_salts: bool = True
    preserve_stereochemistry: bool = True
    generate_conformers: bool = True
    num_conformers: int = 10
    minimization_force_field: str = "MMFF94s"
    random_seed: int = 42
    id_column: str = "compound_id"
    smiles_column: str = "smiles"
    name_column: str = "name"
    max_iterations: int = 200
    minimize_sdf_even_if_3d: bool = True


class DockingCfg(BaseModel):
    gnina_path: str | None = None
    exhaustiveness: int = 16
    num_modes: int = 20
    cnn_scoring: str = "rescore"
    cnn_model: str = "default"
    cpu: bool = False
    seed: int = 42
    gpu_device: int | None = None
    timeout_seconds: int = 3600


class ReportCfg(BaseModel):
    model_config = ConfigDict(populate_by_name=True, protected_namespaces=())
    html: bool = True
    json_report: bool = Field(True, alias="json")
    csv: bool = True
    include_intermediate_files: bool = True
    include_license_report: bool = True


class CacheCfg(BaseModel):
    enabled: bool = True
    directory: str = "cache"
    http_ttl_seconds: int = 604800
    offline: bool = False


class DatabaseCfg(BaseModel):
    url: str = "sqlite:///drugrepurposing.sqlite"


class HttpCfg(BaseModel):
    timeout_seconds: float = 30
    max_retries: int = 5
    rate_limit_per_second: float = 3


class AppConfig(BaseModel):
    project: ProjectCfg = Field(default_factory=ProjectCfg)
    condition: ConditionCfg = Field(default_factory=ConditionCfg)
    sources: SourcesCfg = Field(default_factory=SourcesCfg)
    evidence: EvidenceCfg = Field(default_factory=EvidenceCfg)
    targets: TargetsCfg = Field(default_factory=TargetsCfg)
    structures: StructuresCfg = Field(default_factory=StructuresCfg)
    ligands: LigandsCfg = Field(default_factory=LigandsCfg)
    docking: DockingCfg = Field(default_factory=DockingCfg)
    report: ReportCfg = Field(default_factory=ReportCfg)
    cache: CacheCfg = Field(default_factory=CacheCfg)
    database: DatabaseCfg = Field(default_factory=DatabaseCfg)
    http: HttpCfg = Field(default_factory=HttpCfg)
    scoring: dict[str, Any] = Field(default_factory=dict)
    licenses: dict[str, Any] = Field(default_factory=dict)

    def sha256(self) -> str:
        payload = json.dumps(self.model_dump(mode="json"), sort_keys=True).encode()
        return hashlib.sha256(payload).hexdigest()


def _deep_merge(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    out = dict(base)
    for key, value in overlay.items():
        if key in out and isinstance(out[key], dict) and isinstance(value, dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out


def load_yaml(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    if not isinstance(data, dict):
        raise ValueError(f"YAML root must be a mapping: {path}")
    return data


def package_config_dir() -> Path:
    here = Path(__file__).resolve().parent
    candidates = [
        Path(__file__).resolve().parents[2] / "configs",
        here / "config_data",
        Path.cwd() / "configs",
    ]
    for candidate in candidates:
        if (candidate / "default.yaml").exists():
            return candidate
    raise FileNotFoundError("Could not locate configs/default.yaml")


def load_config(path: str | Path | None = None) -> AppConfig:
    defaults = load_yaml(package_config_dir() / "default.yaml")
    scoring = load_yaml(package_config_dir() / "scoring.yaml")
    licenses = load_yaml(package_config_dir() / "licenses.yaml")
    merged = dict(defaults)
    merged["scoring"] = scoring
    merged["licenses"] = licenses
    if path is not None:
        config_path = Path(path)
        overlay = load_yaml(config_path)
        merged = _deep_merge(merged, overlay)
        local = config_path.with_name(f"{config_path.stem}.local{config_path.suffix}")
        if local.exists():
            merged = _deep_merge(merged, load_yaml(local))
    return AppConfig.model_validate(merged)


def dump_config(config: AppConfig, path: Path) -> None:
    payload = config.model_dump(mode="json", by_alias=True)
    payload.pop("scoring", None)
    payload.pop("licenses", None)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(payload, handle, sort_keys=False)
