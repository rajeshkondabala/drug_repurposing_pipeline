from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import AppConfig
from drugrepurposing.docking.meeko_adapter import prepare_ligand_pdbqt
from drugrepurposing.ligands.conformers import generate_conformers
from drugrepurposing.ligands.io import load_ligand_table
from drugrepurposing.ligands.minimization import minimize_sdf
from drugrepurposing.ligands.standardization import standardize_record
from drugrepurposing.ligands.validation import detect_duplicate_inchikeys, has_blocking_errors
from drugrepurposing.logging_utils import get_logger
from drugrepurposing.provenance import ProvenanceTracker
from drugrepurposing.schemas.ligand import LigandRecord
from drugrepurposing.store import WorkflowState
from drugrepurposing.workflows import ProjectWorkspace

LOGGER = get_logger("ligands")


def _resume_prepared(dest: Path, record: LigandRecord) -> LigandRecord | None:
    sdf = dest / "minimized.sdf"
    if not sdf.exists() or sdf.stat().st_size == 0:
        sdf = dest / "raw.sdf"
    if not sdf.exists() or sdf.stat().st_size == 0:
        return None
    record.sdf_path = str(sdf)
    pdbqt = dest / "ligand.pdbqt"
    if pdbqt.exists() and pdbqt.stat().st_size > 0:
        record.pdbqt_path = str(pdbqt)
    record.preparation_manifest["resumed"] = True
    return record


def prepare_ligands(
    input_path: Path,
    output_dir: Path,
    config: AppConfig,
    provenance: ProvenanceTracker,
    workspace: ProjectWorkspace | None = None,
) -> list[LigandRecord]:
    provenance.add_input(input_path)
    records = load_ligand_table(input_path, config.ligands)
    output_dir.mkdir(parents=True, exist_ok=True)
    total = len(records)
    LOGGER.info("ligand_prep_start", extra={"n": total, "input": str(input_path)})
    prepared: list[LigandRecord] = []
    resumed_n = 0
    for idx, record in enumerate(records, start=1):
        dest = output_dir / record.compound_id
        dest.mkdir(exist_ok=True)
        resumed = _resume_prepared(dest, record)
        if resumed is not None:
            prepared.append(resumed)
            resumed_n += 1
        else:
            if record.smiles or record.input_format in {"smi", "smiles", "csv", "tsv"}:
                record = standardize_record(record, config.ligands)
            if has_blocking_errors(record):
                provenance.warn(f"Rejected ligand {record.compound_id}: {[i.message for i in record.issues]}")
            else:
                record = generate_conformers(record, config.ligands, dest / "raw.sdf")
                if config.ligands.minimize_sdf_even_if_3d or not record.had_3d_coordinates:
                    record = minimize_sdf(record, config.ligands, dest / "minimized.sdf")
                if record.sdf_path:
                    prepare_ligand_pdbqt(record, dest / "ligand.pdbqt")
                prepared.append(record)
        if idx == 1 or idx % 100 == 0 or idx == total:
            LOGGER.info(
                "ligand_progress",
                extra={"done": idx, "total": total, "kept": len(prepared), "resumed": resumed_n},
            )
    prepared = detect_duplicate_inchikeys(prepared)
    payload = [item.model_dump(mode="json") for item in prepared]
    (output_dir / "ligands.json").write_text(__import__("json").dumps(payload, indent=2), encoding="utf-8")
    if workspace:
        workspace.write_json("ligands/ligands.json", payload)
        workspace.set_state(WorkflowState.LIGANDS_PREPARED)
    provenance.set_status(WorkflowState.LIGANDS_PREPARED.value)
    LOGGER.info("ligands_prepared", extra={"n": len(prepared)})
    return prepared
