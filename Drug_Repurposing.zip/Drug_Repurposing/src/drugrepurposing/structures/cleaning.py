from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import AppConfig
from drugrepurposing.structures.search import COFACTORS, METALS
from drugrepurposing.structures.seqres import ParsedPDB
from drugrepurposing.utils.io import atomic_write_text


ADDITIVES = {"SO4", "PO4", "GOL", "EDO", "PEG", "DMS", "ACT", "ACY", "TRS", "EPE", "MPD"}


def resolve_altlocs(line: str) -> str | None:
    if not line.startswith(("ATOM  ", "HETATM")):
        return line
    alt = line[16]
    if alt in {" ", "A"}:
        return line[:16] + " " + line[17:]
    return None


def clean_pdb(parsed: ParsedPDB, dest: Path, config: AppConfig, selected_chains: set[str] | None) -> Path:
    lines: list[str] = []
    special: list[str] = []
    atoms_since_ter = False
    for line in parsed.raw.splitlines():
        if line.startswith(("ATOM  ", "HETATM")):
            resolved = resolve_altlocs(line)
            if resolved is None:
                continue
            chain = resolved[21].strip() or "A"
            if selected_chains and chain not in selected_chains:
                continue
            resname = resolved[17:20].strip().upper()
            if resolved.startswith("HETATM"):
                if resname in {"HOH", "WAT"} and not config.structures.keep_relevant_waters:
                    continue
                if resname in ADDITIVES:
                    continue
                if resname in METALS:
                    special.append("metalloprotein")
                    if not config.structures.keep_metals:
                        continue
                if resname in COFACTORS:
                    special.append("cofactor")
                    if not config.structures.keep_cofactors:
                        continue
            lines.append(resolved)
            atoms_since_ter = True
        elif line.startswith("TER"):
            if atoms_since_ter:
                lines.append("TER")
                atoms_since_ter = False
        elif line.startswith(("HEADER", "TITLE", "CRYST1", "END", "SEQRES", "REMARK")):
            lines.append(line)
    if not any(item.startswith("END") for item in lines):
        lines.append("END")
    atomic_write_text(dest, "\n".join(lines) + "\n")
    dest.with_suffix(".special.txt").write_text("\n".join(sorted(set(special))), encoding="utf-8")
    return dest
