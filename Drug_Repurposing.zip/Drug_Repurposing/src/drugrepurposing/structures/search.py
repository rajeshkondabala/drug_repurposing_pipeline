from __future__ import annotations

CRYSTAL_HET = {
    "SO4", "PO4", "GOL", "EDO", "PEG", "DMS", "ACT", "ACY", "CL", "NA", "K", "TRS", "EPE", "MPD",
}

METALS = {"ZN", "MG", "CA", "MN", "FE", "CU", "CO", "NI", "NA", "K"}
COFACTORS = {"HEM", "NAD", "NAP", "FAD", "FMN", "ATP", "GTP", "SAM", "COA", "PLP"}


def is_crystallization_additive(resname: str) -> bool:
    return resname.upper() in CRYSTAL_HET


def ligand_priority(resname: str, n_atoms: int) -> float:
    name = resname.upper()
    if name in CRYSTAL_HET or name in {"HOH", "WAT", "DOD"}:
        return -1.0
    score = min(n_atoms, 60) / 60.0
    if name in COFACTORS:
        score += 0.1
    return score
