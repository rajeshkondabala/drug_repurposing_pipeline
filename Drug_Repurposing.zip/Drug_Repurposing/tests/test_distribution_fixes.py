from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import load_config
from drugrepurposing.provenance import ProvenanceTracker
from drugrepurposing.schemas.structure import StructureRecord
from drugrepurposing.sources.rcsb import RCSBClient
from drugrepurposing.utils.http import HttpError
from drugrepurposing.workflows import ProjectWorkspace
from drugrepurposing.workflows.docking_workflow import receptor_pdb_for_structure
from drugrepurposing.workflows.ligand_workflow import prepare_ligands
from drugrepurposing.workflows.structure_workflow import prepare_structures


def test_receptor_path_uses_matching_target(tmp_path: Path):
    ws = ProjectWorkspace(tmp_path / "proj")
    first = ws.root / "structures" / "TYK2"
    second = ws.root / "structures" / "IL6R"
    first.mkdir(parents=True)
    second.mkdir(parents=True)
    (first / "repaired.pdb").write_text("TYK2", encoding="utf-8")
    (second / "repaired.pdb").write_text("IL6R", encoding="utf-8")
    structure = StructureRecord(
        source_name="RCSB",
        source_url="https://www.rcsb.org/structure/1NFI",
        pdb_id="1NFI",
        target_symbol="IL6R",
        file_path=str(second / "repaired.pdb"),
    )
    resolved = receptor_pdb_for_structure(ws, structure)
    assert resolved.read_text(encoding="utf-8") == "IL6R"


def test_ligand_prep_resumes_existing_sdf(tmp_path: Path):
    cfg = load_config()
    table = tmp_path / "lig.csv"
    table.write_text("compound_id,smiles,name\nAAA,CCO,ethanol\n", encoding="utf-8")
    dest = tmp_path / "ligands" / "AAA"
    dest.mkdir(parents=True)
    (dest / "minimized.sdf").write_text("existing-sdf\n", encoding="utf-8")
    (dest / "ligand.pdbqt").write_text("existing-pdbqt\n", encoding="utf-8")
    prov = ProvenanceTracker(tmp_path / "prov", cfg)
    prepared = prepare_ligands(table, tmp_path / "ligands", cfg, prov)
    assert prepared[0].preparation_manifest.get("resumed") is True
    assert (dest / "minimized.sdf").read_text(encoding="utf-8") == "existing-sdf\n"


def test_local_config_overlay(tmp_path: Path):
    base = tmp_path / "config.yaml"
    local = tmp_path / "config.local.yaml"
    base.write_text("docking:\n  exhaustiveness: 4\n", encoding="utf-8")
    local.write_text("docking:\n  gnina_path: /opt/gnina\n", encoding="utf-8")
    cfg = load_config(base)
    assert cfg.docking.exhaustiveness == 4
    assert cfg.docking.gnina_path == "/opt/gnina"


def test_pdb_download_falls_back_to_mmcif(tmp_path: Path, monkeypatch):
    cfg = load_config()

    class FakeHttp:
        def get_bytes(self, url, **kwargs):
            if url.endswith(".pdb"):
                raise HttpError(f"{url} returned 404")
            assert url.endswith(".cif")
            return b"data_", {"source_url": url, "raw_record_hash": "abc"}

    monkeypatch.setattr(
        "drugrepurposing.sources.rcsb._mmcif_to_pdb_bytes",
        lambda data, pdb_id: b"ATOM      1  N   ALA A   1       0.000   0.000   0.000  1.00 20.00           N\nEND\n",
    )
    client = RCSBClient(cfg, FakeHttp())  # type: ignore[arg-type]
    dest = tmp_path / "raw.pdb"
    path, meta = client.download_pdb("10PI", dest)
    assert path.exists()
    assert meta.get("converted_from") == "mmcif"
    assert "ATOM" in dest.read_text(encoding="utf-8")


def test_prepare_structures_skips_missing_pdb(tmp_path: Path, monkeypatch):
    cfg = load_config()
    ws = ProjectWorkspace(tmp_path / "proj")
    ws.write_json(
        "targets/targets.json",
        [
            {
                "source_name": "Open Targets Platform",
                "source_url": "https://api.platform.opentargets.org/api/v4/graphql",
                "identifiers": {"approved_symbol": "FOO", "uniprot_accessions": ["P00000"]},
            }
        ],
    )
    fixture = Path(__file__).parent / "fixtures" / "mini.pdb"

    def fake_search(self, accession):
        return ["10PI", "1ABC"]

    def fake_meta(self, pdb_id):
        return {
            "accessed_at": "2026-01-01T00:00:00Z",
            "raw_record_hash": pdb_id,
            "payload": {
                "rcsb_entry_info": {"resolution_combined": [2.0]},
                "exptl": [{"method": "X-RAY DIFFRACTION"}],
                "nonpolymer_entities": [{"pdbx_entity_nonpoly": {"comp_id": "LIG"}}],
            },
        }

    def fake_download(self, pdb_id, dest):
        if pdb_id.upper() == "10PI":
            raise HttpError("https://files.rcsb.org/download/10PI.pdb returned 404")
        dest.write_text(fixture.read_text(encoding="utf-8"), encoding="utf-8")
        return dest, {"raw_record_hash": "ok", "source_url": f"https://files.rcsb.org/download/{pdb_id}.pdb"}

    monkeypatch.setattr(RCSBClient, "search_by_uniprot", fake_search)
    monkeypatch.setattr(RCSBClient, "entry_metadata", fake_meta)
    monkeypatch.setattr(RCSBClient, "download_pdb", fake_download)
    monkeypatch.setattr(
        "drugrepurposing.sources.alphafold.AlphaFoldClient.prediction",
        lambda self, uniprot: None,
    )
    prov = ProvenanceTracker(tmp_path / "prov", cfg)
    selected = prepare_structures(cfg, ws, http=None, provenance=prov)  # type: ignore[arg-type]
    assert len(selected) == 1
    assert selected[0].pdb_id == "1ABC"
    assert any("10PI" in w for w in prov.manifest.get("warnings") or [])


def test_skip_docking_does_not_prepare_structures(tmp_path: Path, monkeypatch):
    called: list[str] = []

    def fake_analyze(*args, **kwargs):
        called.append("analyze")

    def track(name):
        def _inner(*args, **kwargs):
            called.append(name)
            raise AssertionError(f"{name} should not run under --skip-docking")

        return _inner

    monkeypatch.setattr("drugrepurposing.workflows.repurposing.analyze_targets", fake_analyze)
    monkeypatch.setattr("drugrepurposing.workflows.repurposing.prepare_structures", track("structures"))
    monkeypatch.setattr("drugrepurposing.workflows.repurposing.prepare_ligands", track("ligands"))
    monkeypatch.setattr("drugrepurposing.workflows.repurposing.dock_project", track("dock"))
    monkeypatch.setattr("drugrepurposing.workflows.repurposing.write_csv_reports", lambda *a, **k: None)
    monkeypatch.setattr("drugrepurposing.workflows.repurposing.write_json_report", lambda *a, **k: None)
    monkeypatch.setattr("drugrepurposing.workflows.repurposing.write_html_report", lambda *a, **k: None)
    monkeypatch.setattr("drugrepurposing.workflows.repurposing.write_license_report", lambda *a, **k: None)

    from drugrepurposing.workflows.repurposing import run_pipeline

    cfg = load_config()
    run_pipeline(
        condition="rheumatoid arthritis",
        ligands=tmp_path / "lig.csv",
        gnina_path="/opt/gnina",
        output=tmp_path / "out",
        config=cfg,
        skip_docking=True,
    )
    assert called == ["analyze"]
