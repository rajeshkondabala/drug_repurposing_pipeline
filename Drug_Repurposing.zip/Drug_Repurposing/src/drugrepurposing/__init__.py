"""drugrepurposing: license-aware drug-repurposing research platform.

This package generates hypotheses. It does not diagnose, treat, or recommend
clinical use of any compound or target.
"""

from __future__ import annotations

__version__ = "0.1.1"
__license__ = "Apache-2.0"

RESEARCH_DISCLAIMER = (
    "This report is for research and hypothesis generation only. Target "
    "prioritization, structure selection, pocket prediction, ligand "
    "preparation, and docking results do not establish efficacy, safety, "
    "clinical benefit, or drug suitability. Experimental validation is required."
)

NOVELTY_DISCLAIMER = (
    "Candidate novel or understudied target based on the searched sources "
    "and date of analysis."
)
