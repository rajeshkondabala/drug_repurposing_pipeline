from __future__ import annotations

from datetime import datetime, timezone

from pydantic import BaseModel, Field


class DockingPose(BaseModel):
    ligand_id: str
    target: str | None = None
    structure_id: str | None = None
    pocket_id: str | None = None
    pose_rank: int
    vina_score: float | None = None
    cnn_score: float | None = None
    cnn_affinity: float | None = None
    rmsd_from_best: float | None = None
    pose_geometry_quality: float | None = None
    pocket_contact_score: float | None = None
    clash_penalty: float | None = None
    docking_score: float | None = None
    final_pose_score: float | None = None
    warnings: list[str] = Field(default_factory=list)
    sdf_path: str | None = None
    pdb_path: str | None = None
    pdbqt_path: str | None = None
    complex_pdb_path: str | None = None
    score_note: str = (
        "Computational docking scores, not calibrated binding free energies."
    )


class DockingRun(BaseModel):
    receptor_path: str
    ligand_path: str
    command: list[str]
    gnina_version: str | None = None
    start_time: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    end_time: datetime | None = None
    exit_code: int | None = None
    stdout: str = ""
    stderr: str = ""
    input_checksums: dict[str, str] = Field(default_factory=dict)
    output_checksums: dict[str, str] = Field(default_factory=dict)
    cuda_env: dict[str, str] = Field(default_factory=dict)
    gpu_info: str | None = None
    poses: list[DockingPose] = Field(default_factory=list)
    resumed: bool = False
