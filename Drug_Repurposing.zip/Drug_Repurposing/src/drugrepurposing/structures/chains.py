from __future__ import annotations

from drugrepurposing.schemas.structure import ChainAnalysis
from drugrepurposing.structures.seqres import AA3TO1, ParsedPDB, seqres_sequence

BACKBONE = {"N", "CA", "C", "O"}


def analyze_chains(parsed: ParsedPDB) -> list[ChainAnalysis]:
    chains = sorted(set(parsed.seqres) | {key[0] for key in parsed.residues})
    analyses: list[ChainAnalysis] = []
    for chain in chains:
        expected = parsed.seqres.get(chain, [])
        observed = [
            res
            for (ch, _seq, _ic), res in parsed.residues.items()
            if ch == chain and not res.hetero
        ]
        observed_keys = {(res.resseq, res.icode) for res in observed}
        missing_internal: list[str] = []
        missing_terminal: list[str] = []
        if expected and observed:
            obs_seq = sorted(res.resseq for res in observed)
            lo, hi = obs_seq[0], obs_seq[-1]
            expected_range = list(range(1, len(expected) + 1))
            for idx, name in zip(expected_range, expected):
                if idx < lo or idx > hi:
                    if (idx, "") not in observed_keys:
                        missing_terminal.append(f"{chain}:{idx}:{name}")
                elif (idx, "") not in observed_keys and idx not in {res.resseq for res in observed}:
                    missing_internal.append(f"{chain}:{idx}:{name}")
            # Compare SEQRES names with ATOM residue numbering where they overlap.
            for res in observed:
                if 1 <= res.resseq <= len(expected):
                    expected_name = expected[res.resseq - 1]
                    if expected_name != res.name and AA3TO1.get(expected_name) != AA3TO1.get(res.name):
                        missing_internal.append(f"{chain}:{res.resseq}:SEQRES/{res.name}")
        missing_bb = [
            f"{res.chain}:{res.resseq}"
            for res in observed
            if not BACKBONE.issubset(res.atoms)
        ]
        missing_sc = [
            f"{res.chain}:{res.resseq}"
            for res in observed
            if res.name != "GLY" and len(res.atoms - BACKBONE) == 0
        ]
        altlocs = [f"{res.chain}:{res.resseq}" for res in observed if res.altlocs]
        nonstd = [f"{res.chain}:{res.resseq}:{res.name}" for res in observed if res.name not in AA3TO1]
        analyses.append(
            ChainAnalysis(
                chain_id=chain,
                seqres_length=len(expected),
                observed_length=len(observed),
                missing_terminal=missing_terminal,
                missing_internal=missing_internal,
                missing_backbone=missing_bb,
                missing_sidechain=missing_sc,
                alternate_locations=altlocs,
                nonstandard_residues=nonstd,
                sequence=seqres_sequence(expected) if expected else "",
            )
        )
    return analyses


def identity(seq_a: str, seq_b: str) -> float:
    if not seq_a or not seq_b:
        return 0.0
    length = min(len(seq_a), len(seq_b))
    matches = sum(a == b for a, b in zip(seq_a[:length], seq_b[:length]))
    return matches / max(len(seq_a), len(seq_b))
