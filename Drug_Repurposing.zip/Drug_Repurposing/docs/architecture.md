# Architecture

`drug-repurposing` is a CLI and Python API. There is no web frontend in this milestone.

## Layout

- `src/drugrepurposing/sources` — optional, cached adapters for public APIs.
- `src/drugrepurposing/evidence` — transparent component scores; novelty labels.
- `src/drugrepurposing/structures` — PDB parsing, chain/pocket logic, PDBFixer adapter.
- `src/drugrepurposing/ligands` — IO, RDKit standardization, conformers, minimization.
- `src/drugrepurposing/docking` — Meeko adapter, GNINA runner, pose ranking.
- `src/drugrepurposing/workflows` — restartable state machine.
- `src/drugrepurposing/reports` — HTML/JSON/CSV plus pose export.

## State machine

`initialized` → `condition_resolved` → `targets_collected` → `evidence_collected` → `targets_ranked` → `structures_selected` → `structures_prepared` → `ligands_prepared` → `docking_completed` → `report_generated` (or `failed`).

## Scoring isolation

The target evidence score and the docking pose score are never multiplied into a single “repurposing score”. Reports store them in separate tables.

## HTTP and cache

`HttpClient` uses timeouts, exponential backoff, a user-agent, and content-addressed JSON/binary caches. Offline mode serves only cache hits.

## Database

SQLAlchemy models in `store.py` default to SQLite (`database.url`). PostgreSQL is supported by changing the URL.
