from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from drugrepurposing.schemas.disease import ProvenanceMixin


class TargetIdentifiers(BaseModel):
    ensembl_gene_id: str | None = None
    approved_symbol: str | None = None
    approved_name: str | None = None
    uniprot_accessions: list[str] = Field(default_factory=list)
    hgnc_id: str | None = None
    alphafold_accession: str | None = None


class DatatypeScore(BaseModel):
    id: str
    score: float


class KnownDrug(BaseModel):
    name: str
    chembl_id: str | None = None
    mechanism_of_action: str | None = None
    phase: str | None = None
    disease_id: str | None = None
    disease_name: str | None = None
    source: str | None = None
    source_url: str | None = None
    license: str | None = None


class CrossConditionAssociation(BaseModel):
    disease_id: str
    disease_name: str
    score: float | None = None
    association_class: str = "biological association"
    notes: str | None = None


class TargetRecord(ProvenanceMixin):
    identifiers: TargetIdentifiers
    association_score: float = 0.0
    datatype_scores: list[DatatypeScore] = Field(default_factory=list)
    known_drugs: list[KnownDrug] = Field(default_factory=list)
    tractability: dict[str, Any] = Field(default_factory=dict)
    safety_liabilities: list[str] = Field(default_factory=list)
    expression_tissues: list[str] = Field(default_factory=list)
    isoforms: list[str] = Field(default_factory=list)
    isoform_selection_reason: str | None = None
    cross_condition: list[CrossConditionAssociation] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)
