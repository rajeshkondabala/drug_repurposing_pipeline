from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from drugrepurposing import RESEARCH_DISCLAIMER, __version__
from drugrepurposing.config import dump_config, load_config
from drugrepurposing.logging_utils import configure_logging
from drugrepurposing.provenance import ProvenanceTracker
from drugrepurposing.reports.tables import write_license_report
from drugrepurposing.sources.opentargets import OpenTargetsClient
from drugrepurposing.utils.cache import ContentAddressedCache
from drugrepurposing.utils.http import HttpClient
from drugrepurposing.workflows import ProjectWorkspace
from drugrepurposing.workflows.docking_workflow import dock_project
from drugrepurposing.workflows.ligand_workflow import prepare_ligands
from drugrepurposing.workflows.repurposing import run_pipeline
from drugrepurposing.workflows.structure_workflow import prepare_structures
from drugrepurposing.workflows.target_workflow import analyze_targets

app = typer.Typer(
    add_completion=False,
    help="Evidence-based drug-repurposing research CLI. Not a clinical device.",
)
console = Console()


def _config(path: Optional[Path]):
    return load_config(path)


def _version_callback(value: bool) -> None:
    if value:
        console.print(__version__)
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False, "--version", help="Show version and exit.", callback=_version_callback, is_eager=True
    ),
    verbose: bool = typer.Option(False, "--verbose"),
) -> None:
    configure_logging("DEBUG" if verbose else "INFO")


@app.command("init-config")
def init_config(output: Path = typer.Option(..., "--output")) -> None:
    dump_config(load_config(), output)
    console.print(f"Wrote {output}")


@app.command("search-condition")
def search_condition(
    condition: str = typer.Option(..., "--condition"),
    config: Optional[Path] = typer.Option(None, "--config"),
    select: Optional[str] = typer.Option(None, "--select", help="Force a disease identifier."),
) -> None:
    cfg = _config(config)
    cache = ContentAddressedCache(Path(cfg.cache.directory), enabled=cfg.cache.enabled)
    with HttpClient(cfg, cache) as http:
        client = OpenTargetsClient(cfg, http)
        resolution = client.search_conditions(condition)
        if select:
            resolution = client.confirm(resolution, select)
        elif resolution.requires_confirmation and resolution.alternatives:
            console.print("Multiple plausible conditions:")
            options = []
            if resolution.selected_condition:
                options.append(resolution.selected_condition)
            options.extend(resolution.alternatives)
            for item in options:
                console.print(f"  {item.id}\t{item.name}\t{item.ontology}")
            if sys.stdin.isatty():
                chosen = typer.prompt("Enter identifier to confirm")
                resolution = client.confirm(resolution, chosen)
        console.print_json(data=json.loads(resolution.model_dump_json()))


@app.command("analyze-targets")
def analyze_targets_cmd(
    condition: str = typer.Option(..., "--condition"),
    config: Optional[Path] = typer.Option(None, "--config"),
    output: Path = typer.Option(..., "--output"),
    select: Optional[str] = typer.Option(None, "--select"),
) -> None:
    cfg = _config(config)
    workspace = ProjectWorkspace(output)
    provenance = ProvenanceTracker(output, cfg)
    cache = ContentAddressedCache(Path(cfg.cache.directory), enabled=cfg.cache.enabled)
    with HttpClient(cfg, cache) as http:
        result = analyze_targets(condition, cfg, workspace, http, provenance, selected_id=select)
        provenance.write()
    console.print(f"Wrote targets to {output}")
    if result.get("awaiting_confirmation"):
        console.print("Re-run with --select DISEASE_ID after reviewing alternatives.")


@app.command("prepare-structures")
def prepare_structures_cmd(
    project: Path = typer.Option(..., "--project"),
    config: Optional[Path] = typer.Option(None, "--config"),
    max_targets: Optional[int] = typer.Option(None, "--max-targets"),
) -> None:
    cfg = _config(config)
    workspace = ProjectWorkspace(project)
    provenance = ProvenanceTracker(project, cfg)
    cache = ContentAddressedCache(Path(cfg.cache.directory), enabled=cfg.cache.enabled)
    with HttpClient(cfg, cache) as http:
        prepare_structures(cfg, workspace, http, provenance, max_targets=max_targets)
        provenance.write()
    console.print(f"Prepared structures in {project / 'structures'}")


@app.command("prepare-ligands")
def prepare_ligands_cmd(
    input: Path = typer.Option(..., "--input"),
    output: Path = typer.Option(..., "--output"),
    config: Optional[Path] = typer.Option(None, "--config"),
    project: Optional[Path] = typer.Option(None, "--project"),
) -> None:
    cfg = _config(config)
    workspace = ProjectWorkspace(project) if project else None
    provenance = ProvenanceTracker(output, cfg)
    prepare_ligands(input, output, cfg, provenance, workspace)
    provenance.write()
    console.print(f"Prepared ligands in {output}")


@app.command("dock")
def dock_cmd(
    project: Path = typer.Option(..., "--project"),
    gnina_path: Optional[Path] = typer.Option(None, "--gnina-path"),
    config: Optional[Path] = typer.Option(None, "--config"),
) -> None:
    cfg = _config(config)
    workspace = ProjectWorkspace(project)
    provenance = ProvenanceTracker(project, cfg)
    dock_project(cfg, workspace, provenance, gnina_path=str(gnina_path) if gnina_path else None)
    from drugrepurposing.reports.html import write_html_report
    from drugrepurposing.reports.json_report import write_json_report
    from drugrepurposing.reports.tables import write_csv_reports

    write_csv_reports(workspace, cfg)
    write_json_report(workspace, cfg, provenance)
    write_html_report(workspace, cfg, provenance)
    write_license_report(workspace, cfg)
    provenance.write()
    console.print(RESEARCH_DISCLAIMER)


@app.command("run")
def run_cmd(
    condition: str = typer.Option(..., "--condition"),
    ligands: Optional[Path] = typer.Option(None, "--ligands"),
    gnina_path: Optional[Path] = typer.Option(None, "--gnina-path"),
    output: Path = typer.Option(..., "--output"),
    config: Optional[Path] = typer.Option(None, "--config"),
    select: Optional[str] = typer.Option(None, "--select"),
    skip_docking: bool = typer.Option(
        False,
        "--skip-docking",
        help="Evidence ranking only: skip structure prep, ligand prep, and GNINA.",
    ),
) -> None:
    cfg = _config(config)
    run_pipeline(
        condition=condition,
        ligands=ligands,
        gnina_path=str(gnina_path) if gnina_path else None,
        output=output,
        config=cfg,
        selected_id=select,
        skip_docking=skip_docking,
    )
    console.print(f"Project written to {output}")
    console.print(RESEARCH_DISCLAIMER)


@app.command("validate-installation")
def validate_installation() -> None:
    problems: list[str] = []
    try:
        import pydantic  # noqa: F401
        import httpx  # noqa: F401
        import yaml  # noqa: F401
        import jinja2  # noqa: F401
        import pandas  # noqa: F401
        import sqlalchemy  # noqa: F401
    except ImportError as exc:
        problems.append(str(exc))
    optional: dict[str, str] = {}
    required_optional = ("rdkit", "pdbfixer", "openmm")
    copyleft_optional = ("meeko", "pyKVFinder")
    for name in (*required_optional, *copyleft_optional):
        try:
            __import__(name)
            optional[name] = "ok"
        except Exception as exc:
            optional[name] = f"unavailable ({type(exc).__name__}: {exc})"
    load_config()
    console.print({"version": __version__, "optional": optional, "problems": problems})
    if problems:
        raise typer.Exit(code=1)
    missing_science = [name for name in required_optional if not optional[name].startswith("ok")]
    if missing_science:
        console.print(
            "Core CLI is installed. Structure/ligand extras missing: "
            + ", ".join(missing_science)
            + ". Install from environment.yml or pip extras [chem,structure]."
        )
    missing_copyleft = [name for name in copyleft_optional if not optional[name].startswith("ok")]
    if missing_copyleft:
        console.print(
            "Copyleft docking extras not installed (expected for a redistributable core env): "
            + ", ".join(missing_copyleft)
            + ". Install with: conda env update -n drug-repurposing -f environment-extras.yml"
        )
    console.print("Installation OK for core CLI. GNINA is user-supplied and was not checked.")


@app.command("show-provenance")
def show_provenance(project: Path = typer.Option(..., "--project")) -> None:
    path = project / "provenance.json"
    if not path.exists():
        path = project / "manifest.json"
    if not path.exists():
        raise typer.BadParameter(f"No provenance.json in {project}")
    console.print_json(path.read_text(encoding="utf-8"))


@app.command("export-license-report")
def export_license_report_cmd(
    project: Path = typer.Option(..., "--project"),
    config: Optional[Path] = typer.Option(None, "--config"),
) -> None:
    cfg = _config(config)
    workspace = ProjectWorkspace(project)
    path = write_license_report(workspace, cfg)
    console.print(f"Wrote {path}")


def run() -> None:
    app()


if __name__ == "__main__":
    run()
