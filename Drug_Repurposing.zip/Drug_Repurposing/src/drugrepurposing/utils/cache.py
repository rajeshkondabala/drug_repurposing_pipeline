from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from drugrepurposing.utils.hashes import sha256_json, sha256_text
from drugrepurposing.utils.io import atomic_write_bytes, atomic_write_text


class ContentAddressedCache:
    def __init__(self, root: Path, enabled: bool = True) -> None:
        self.root = root
        self.enabled = enabled
        for name in ("http", "structures", "alphafold", "literature", "trials", "normalized"):
            (self.root / name).mkdir(parents=True, exist_ok=True)

    def key(self, namespace: str, payload: Any) -> Path:
        digest = sha256_json(payload) if not isinstance(payload, str) else sha256_text(payload)
        return self.root / namespace / f"{digest}.json"

    def get_json(self, namespace: str, payload: Any) -> Any | None:
        if not self.enabled:
            return None
        path = self.key(namespace, payload)
        if not path.exists():
            return None
        return json.loads(path.read_text(encoding="utf-8"))

    def put_json(self, namespace: str, payload: Any, value: Any) -> Path:
        path = self.key(namespace, payload)
        atomic_write_text(path, json.dumps(value, indent=2, default=str))
        return path

    def put_bytes(self, namespace: str, payload: Any, data: bytes, suffix: str = ".bin") -> Path:
        digest = sha256_json(payload)
        path = self.root / namespace / f"{digest}{suffix}"
        atomic_write_bytes(path, data)
        return path

    def get_bytes(self, namespace: str, payload: Any, suffix: str = ".bin") -> bytes | None:
        digest = sha256_json(payload)
        path = self.root / namespace / f"{digest}{suffix}"
        if not path.exists():
            return None
        return path.read_bytes()


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()
