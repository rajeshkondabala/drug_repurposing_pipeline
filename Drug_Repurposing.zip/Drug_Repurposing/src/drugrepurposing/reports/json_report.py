from __future__ import annotations

from drugrepurposing import RESEARCH_DISCLAIMER
from drugrepurposing.config import AppConfig
from drugrepurposing.provenance import ProvenanceTracker
from drugrepurposing.workflows import ProjectWorkspace


def write_json_report(workspace: ProjectWorkspace, config: AppConfig, provenance: ProvenanceTracker) -> None:
    payload = {
        "disclaimer": RESEARCH_DISCLAIMER,
        "condition": workspace.read_json("targets/condition_resolution.json"),
        "targets": workspace.read_json("targets/scores.json"),
        "drugs": workspace.read_json("targets/drugs.json"),
        "structures": workspace.read_json("structures/selected.json"),
        "ligands": workspace.read_json("ligands/ligands.json"),
        "docking": workspace.read_json("docking/poses.json"),
        "provenance": provenance.manifest,
        "config_hash": config.sha256(),
        "note": "Evidence scores and docking scores are stored separately.",
    }
    workspace.write_json("reports/report.json", payload)
    workspace.write_json(
        "reports/evidence_graph.json",
        {
            "targets": [
                {"target": s.get("symbol"), "condition": (payload.get("condition") or {}).get("selected_condition"), "evidence": s.get("evidence_graph")}
                for s in (payload.get("targets") or [])
            ]
        },
    )
