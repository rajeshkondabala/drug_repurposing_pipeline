# drug-repurposing
Apache-2.0

This directory contains third-party notices required for redistribution of
this software. Data retrieved at runtime is not bundled here; generated
project reports include per-run attribution.
