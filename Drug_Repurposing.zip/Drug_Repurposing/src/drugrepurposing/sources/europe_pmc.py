from __future__ import annotations

from datetime import datetime

from drugrepurposing.config import AppConfig
from drugrepurposing.schemas.evidence import EvidenceClass, LiteratureRecord
from drugrepurposing.utils.http import HttpClient, HttpError

CLASS_HINTS = (
    (EvidenceClass.GENETIC, ("gwas", "genome-wide", "mendelian", "variant")),
    (EvidenceClass.HUMAN_CLINICAL, ("randomized", "clinical trial", "phase ii", "phase iii")),
    (EvidenceClass.HUMAN_OBSERVATIONAL, ("cohort", "case-control", "observational")),
    (EvidenceClass.FUNCTIONAL_CELLULAR, ("knockdown", "crispr", "cell line", "in vitro")),
    (EvidenceClass.ANIMAL, ("mouse", "murine", "rat", "zebrafish", "in vivo")),
    (EvidenceClass.MECHANISTIC_BIOCHEMICAL, ("kinase", "binding", "enzym", "pathway")),
    (EvidenceClass.REVIEW_ONLY, ("review", "meta-analysis")),
)


def classify_publication(title: str, pub_type: str | None) -> tuple[EvidenceClass, bool]:
    blob = f"{title} {pub_type or ''}".lower()
    is_review = "review" in blob or (pub_type or "").lower().find("review") >= 0
    for klass, hints in CLASS_HINTS:
        if any(hint in blob for hint in hints):
            return klass, is_review
    if is_review:
        return EvidenceClass.REVIEW_ONLY, True
    return EvidenceClass.COMPUTATIONAL, is_review


class EuropePMCClient:
    def __init__(self, config: AppConfig, http: HttpClient) -> None:
        self.config = config
        self.http = http
        self.base = config.sources.europe_pmc.base_url or (
            "https://www.ebi.ac.uk/europepmc/webservices/rest"
        )

    def search(self, query: str, page_size: int | None = None) -> list[LiteratureRecord]:
        if not self.config.sources.europe_pmc.enabled:
            return []
        size = page_size or self.config.evidence.literature_page_size
        url = f"{self.base}/search"
        try:
            envelope = self.http.request_json(
                "GET",
                url,
                params={"query": query, "format": "json", "pageSize": size},
                namespace="literature",
                source_name="Europe PMC",
                license_or_terms="mixed; retain publisher copyright and attribution",
            )
        except HttpError:
            return []
        results = envelope.get("payload", {}).get("resultList", {}).get("result") or []
        records: list[LiteratureRecord] = []
        year_cut = datetime.utcnow().year - self.config.evidence.recent_years
        for item in results:
            title = item.get("title") or ""
            pub_type = ",".join(item.get("pubTypeList", {}).get("pubType") or [])
            klass, is_review = classify_publication(title, pub_type)
            year = int(item["pubYear"]) if str(item.get("pubYear") or "").isdigit() else None
            records.append(
                LiteratureRecord(
                    source_name="Europe PMC",
                    source_url=url,
                    accessed_at=envelope["accessed_at"],
                    source_version=envelope.get("source_version"),
                    query=query,
                    raw_record_hash=envelope.get("raw_record_hash"),
                    license_or_terms=envelope.get("license_or_terms"),
                    pmid=str(item.get("pmid")) if item.get("pmid") else None,
                    pmcid=item.get("pmcid"),
                    doi=item.get("doi"),
                    title=title,
                    year=year,
                    publication_type=pub_type or None,
                    evidence_class=klass,
                    is_review=is_review,
                    is_recent=bool(year and year >= year_cut),
                )
            )
        return records
