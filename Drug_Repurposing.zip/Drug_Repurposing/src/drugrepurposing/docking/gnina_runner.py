from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path

from drugrepurposing.config import DockingCfg
from drugrepurposing.schemas.docking import DockingRun
from drugrepurposing.utils.hashes import sha256_file
from drugrepurposing.utils.subprocess import SubprocessError, run_command


def gnina_uses_rdkit_io(version: str | None) -> bool:
    text = (version or "").lower()
    return "rdkit" in text


def validate_gnina(path: str) -> str:
    executable = Path(path)
    if not executable.exists():
        raise FileNotFoundError(
            f"GNINA executable not found: {path}. Provide --gnina-path or docking.gnina_path."
        )
    completed = run_command([str(executable), "--version"], timeout=30)
    version = (completed.stdout or completed.stderr).strip().splitlines()[0] if (completed.stdout or completed.stderr) else "unknown"
    return version


def build_gnina_command(
    gnina: str,
    receptor: Path,
    ligand: Path,
    output: Path,
    box: dict[str, float],
    cfg: DockingCfg,
) -> list[str]:
    command = [
        gnina,
        "-r",
        str(receptor),
        "-l",
        str(ligand),
        "--center_x",
        str(box["center_x"]),
        "--center_y",
        str(box["center_y"]),
        "--center_z",
        str(box["center_z"]),
        "--size_x",
        str(box["size_x"]),
        "--size_y",
        str(box["size_y"]),
        "--size_z",
        str(box["size_z"]),
        "--exhaustiveness",
        str(cfg.exhaustiveness),
        "--num_modes",
        str(cfg.num_modes),
        "--cnn_scoring",
        str(cfg.cnn_scoring),
        "--seed",
        str(cfg.seed),
        "--out",
        str(output),
    ]
    if cfg.cnn_model and cfg.cnn_model != "default":
        command.extend(["--cnn", cfg.cnn_model])
    if cfg.cpu:
        command.append("--no_gpu")
    elif cfg.gpu_device is not None:
        command.extend(["--device", str(cfg.gpu_device)])
    return command


def run_gnina(
    gnina: str,
    receptor: Path,
    ligand: Path,
    output: Path,
    box: dict[str, float],
    cfg: DockingCfg,
    log_dir: Path,
) -> DockingRun:
    output.parent.mkdir(parents=True, exist_ok=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    done_marker = output.with_suffix(output.suffix + ".done")
    command = build_gnina_command(gnina, receptor, ligand, output, box, cfg)
    checksums = {
        "receptor": sha256_file(receptor) if receptor.exists() else "",
        "ligand": sha256_file(ligand) if ligand.exists() else "",
    }
    cuda_env = {k: v for k, v in os.environ.items() if "CUDA" in k or k == "NVIDIA_VISIBLE_DEVICES"}
    if done_marker.exists() and output.exists() and output.stat().st_size > 0:
        return DockingRun(
            receptor_path=str(receptor),
            ligand_path=str(ligand),
            command=command,
            input_checksums=checksums,
            output_checksums={"out": sha256_file(output)},
            cuda_env=cuda_env,
            resumed=True,
            exit_code=0,
            end_time=datetime.now(timezone.utc),
        )
    start = datetime.now(timezone.utc)
    try:
        version = validate_gnina(gnina)
        completed = run_command(command, timeout=cfg.timeout_seconds)
        stdout, stderr, code = completed.stdout, completed.stderr, completed.returncode
    except SubprocessError as exc:
        stdout, stderr, code = exc.stdout, exc.stderr, exc.returncode
        version = None
    except FileNotFoundError:
        raise
    (log_dir / "gnina.stdout.txt").write_text(stdout, encoding="utf-8")
    (log_dir / "gnina.stderr.txt").write_text(stderr, encoding="utf-8")
    run = DockingRun(
        receptor_path=str(receptor),
        ligand_path=str(ligand),
        command=command,
        gnina_version=version,
        start_time=start,
        end_time=datetime.now(timezone.utc),
        exit_code=code,
        stdout=stdout[-8000:],
        stderr=stderr[-8000:],
        input_checksums=checksums,
        output_checksums={"out": sha256_file(output)} if output.exists() else {},
        cuda_env=cuda_env,
    )
    if code == 0 and output.exists() and output.stat().st_size > 0:
        done_marker.write_text("ok\n", encoding="utf-8")
    return run
