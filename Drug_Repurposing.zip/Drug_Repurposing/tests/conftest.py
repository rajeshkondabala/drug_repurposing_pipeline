from __future__ import annotations

from pathlib import Path

import pytest

from drugrepurposing.config import load_config
from drugrepurposing.utils.cache import ContentAddressedCache


FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def config(tmp_path: Path):
    cfg = load_config()
    cfg.cache.directory = str(tmp_path / "cache")
    cfg.cache.offline = True
    cfg.condition.require_user_confirmation = True
    return cfg


@pytest.fixture
def cache(tmp_path: Path):
    return ContentAddressedCache(tmp_path / "cache", enabled=True)
