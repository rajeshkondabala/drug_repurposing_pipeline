from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import AppConfig
from drugrepurposing.structures.seqres import ParsedPDB


class PDBFixerUnavailable(RuntimeError):
    pass


def prepare_with_pdbfixer(
    input_pdb: Path,
    output_pdb: Path,
    parsed: ParsedPDB,
    config: AppConfig,
    keep_chains: list[str] | None = None,
) -> dict:
    """Repair missing atoms/residues. Internal pocket loops remain flagged, not trusted."""
    try:
        from pdbfixer import PDBFixer  # type: ignore
        from openmm.app import PDBFile  # type: ignore
    except Exception as exc:  # pragma: no cover - optional dep
        raise PDBFixerUnavailable(
            "PDBFixer/OpenMM are required for structure repair. Install the structure extra."
        ) from exc

    try:
        fixer = PDBFixer(filename=str(input_pdb))
        fixer.findMissingResidues()
        missing = dict(fixer.missingResidues)
        skipped = {}
        for key, residues in list(fixer.missingResidues.items()):
            if len(residues) >= 8:
                skipped[str(key)] = residues
                fixer.missingResidues[key] = []
        fixer.findNonstandardResidues()
        fixer.replaceNonstandardResidues()
        keep_heterogens = True
        fixer.removeHeterogens(keepWater=config.structures.keep_relevant_waters)
        if not config.structures.keep_metals or not config.structures.keep_cofactors:
            keep_heterogens = False
        fixer.findMissingAtoms()
        fixer.addMissingAtoms()
        fixer.addMissingHydrogens(7.0)
        output_pdb.parent.mkdir(parents=True, exist_ok=True)
        with output_pdb.open("w", encoding="utf-8") as handle:
            PDBFile.writeFile(fixer.topology, fixer.positions, handle, keepIds=True)
    except PDBFixerUnavailable:
        raise
    except Exception as exc:
        raise RuntimeError(f"PDBFixer failed on {input_pdb}: {exc}") from exc
    inserted = [f"{k}:{len(v)}" for k, v in missing.items() if v]
    return {
        "repaired": True,
        "inserted_residues": inserted,
        "skipped_long_internal_loops": skipped,
        "keep_heterogens": keep_heterogens,
        "keep_chains": keep_chains or [],
        "warning": (
            "Repaired coordinates are not equivalent to experimental density. "
            "Internal loops omitted from automatic rebuild remain missing."
        ),
    }
