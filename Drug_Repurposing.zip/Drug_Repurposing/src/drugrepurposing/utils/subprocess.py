from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Mapping, Sequence


class SubprocessError(RuntimeError):
    def __init__(self, command: Sequence[str], returncode: int, stdout: str, stderr: str) -> None:
        self.command = list(command)
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr
        super().__init__(f"Command failed ({returncode}): {' '.join(self.command)}\n{stderr}")


def run_command(
    command: Sequence[str],
    *,
    timeout: int | None = None,
    env: Mapping[str, str] | None = None,
    cwd: Path | None = None,
) -> subprocess.CompletedProcess[str]:
    if not command:
        raise ValueError("Empty command")
    merged = os.environ.copy()
    if env:
        merged.update(env)
    completed = subprocess.run(
        list(command),
        capture_output=True,
        text=True,
        timeout=timeout,
        env=merged,
        cwd=str(cwd) if cwd else None,
        check=False,
        shell=False,
    )
    if completed.returncode != 0:
        raise SubprocessError(command, completed.returncode, completed.stdout, completed.stderr)
    return completed
