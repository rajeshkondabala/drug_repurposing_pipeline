from __future__ import annotations

from drugrepurposing.config import AppConfig
from drugrepurposing.schemas.evidence import CompoundRecord
from drugrepurposing.utils.http import HttpClient, HttpError


class ChEMBLClient:
    def __init__(self, config: AppConfig, http: HttpClient) -> None:
        self.config = config
        self.http = http
        self.base = config.sources.chembl.base_url or "https://www.ebi.ac.uk/chembl/api/data"

    def molecule_by_pref_name(self, name: str) -> CompoundRecord | None:
        if not self.config.sources.chembl.enabled:
            return None
        try:
            envelope = self.http.request_json(
                "GET",
                f"{self.base}/molecule/search.json",
                params={"q": name, "limit": 1},
                namespace="http",
                source_name="ChEMBL",
                license_or_terms="CC-BY-SA-3.0",
            )
        except HttpError:
            return None
        molecules = envelope.get("payload", {}).get("molecules") or []
        if not molecules:
            return None
        mol = molecules[0]
        structs = mol.get("molecule_structures") or {}
        return CompoundRecord(
            source_name="ChEMBL",
            source_url=f"{self.base}/molecule/{mol.get('molecule_chembl_id')}",
            accessed_at=envelope["accessed_at"],
            query=name,
            raw_record_hash=envelope.get("raw_record_hash"),
            license_or_terms="CC-BY-SA-3.0",
            compound_id=mol.get("molecule_chembl_id") or name,
            preferred_name=mol.get("pref_name") or name,
            smiles=structs.get("canonical_smiles"),
            inchi=structs.get("standard_inchi"),
            inchikey=structs.get("standard_inchi_key"),
            molecular_formula=(mol.get("molecule_properties") or {}).get("full_molformula"),
            molecular_weight=(mol.get("molecule_properties") or {}).get("full_mwt"),
            development_phase=mol.get("max_phase"),
            approval_status="approved" if mol.get("max_phase") == 4 else None,
        )
