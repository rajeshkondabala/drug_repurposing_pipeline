from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import LigandsCfg
from drugrepurposing.schemas.ligand import LigandIssue, LigandRecord


def _read_table(path: Path) -> list[dict[str, str]]:
    import csv

    dialect = csv.excel_tab if path.suffix.lower() in {".tsv", ".tab"} else csv.excel
    with path.open("r", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, dialect=dialect)
        return [{k.strip(): (v or "").strip() for k, v in row.items() if k} for row in reader]


def _read_smi(path: Path) -> list[dict[str, str]]:
    rows = []
    for idx, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        smiles = parts[0]
        ident = parts[1] if len(parts) > 1 else f"cmp_{idx}"
        rows.append({"compound_id": ident, "smiles": smiles, "name": ident})
    return rows


def load_ligand_table(path: Path, cfg: LigandsCfg) -> list[LigandRecord]:
    suffix = path.suffix.lower()
    records: list[LigandRecord] = []
    if suffix in {".sdf", ".sd"}:
        return [
            LigandRecord(
                compound_id=path.stem,
                name=path.stem,
                input_format="sdf",
                input_path=str(path),
            )
        ]
    if suffix in {".smi", ".smiles"}:
        rows = _read_smi(path)
        fmt = "smi"
    else:
        rows = _read_table(path)
        fmt = suffix.lstrip(".")
    seen_ids: set[str] = set()
    for idx, row in enumerate(rows, start=1):
        cid = row.get(cfg.id_column) or row.get("compound_id") or f"row_{idx}"
        smiles = row.get(cfg.smiles_column) or row.get("smiles") or row.get("SMILES")
        name = row.get(cfg.name_column) or row.get("name")
        issues: list[LigandIssue] = []
        if cid in seen_ids:
            issues.append(LigandIssue(code="duplicate_id", message=f"Duplicate compound_id {cid}"))
        seen_ids.add(cid)
        if not smiles:
            issues.append(LigandIssue(code="empty_structure", message="Empty SMILES"))
        records.append(
            LigandRecord(
                compound_id=cid,
                name=name,
                smiles=smiles,
                input_format=fmt,
                input_path=str(path),
                issues=issues,
            )
        )
    return records
