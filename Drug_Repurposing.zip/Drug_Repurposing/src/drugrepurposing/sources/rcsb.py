from __future__ import annotations

from drugrepurposing.config import AppConfig
from drugrepurposing.schemas.structure import StructureRecord
from drugrepurposing.utils.http import HttpClient, HttpError
from drugrepurposing.utils.io import atomic_write_bytes
from io import StringIO
from pathlib import Path


def _mmcif_to_pdb_bytes(data: bytes, pdb_id: str) -> bytes:
    from Bio.PDB import MMCIFParser, PDBIO  # type: ignore

    parser = MMCIFParser(QUIET=True)
    structure = parser.get_structure(pdb_id, StringIO(data.decode("utf-8", errors="replace")))
    handle = StringIO()
    writer = PDBIO()
    writer.set_structure(structure)
    writer.save(handle)
    text = handle.getvalue()
    if not text.strip():
        raise ValueError(f"mmCIF conversion produced an empty PDB for {pdb_id}")
    return text.encode("utf-8")


class RCSBClient:
    def __init__(self, config: AppConfig, http: HttpClient) -> None:
        self.config = config
        self.http = http
        self.search_url = config.sources.rcsb.search_url or "https://search.rcsb.org/rcsbsearch/v2/query"
        self.data_url = config.sources.rcsb.data_url or "https://data.rcsb.org/rest/v1"
        self.files_url = config.sources.rcsb.files_url or "https://files.rcsb.org/download"

    def search_by_uniprot(self, accession: str) -> list[str]:
        if not self.config.sources.rcsb.enabled:
            return []
        query = {
            "query": {
                "type": "terminal",
                "service": "text",
                "parameters": {
                    "attribute": "rcsb_polymer_entity_container_identifiers.reference_sequence_identifiers.database_accession",
                    "operator": "exact_match",
                    "value": accession,
                },
            },
            "return_type": "entry",
            "request_options": {"paginate": {"start": 0, "rows": 25}},
        }
        try:
            envelope = self.http.request_json(
                "POST",
                self.search_url,
                json_body=query,
                namespace="structures",
                source_name="RCSB PDB",
                license_or_terms="CC0-1.0 for PDB archive/API data",
            )
        except HttpError:
            return []
        return [hit["identifier"] for hit in envelope.get("payload", {}).get("result_set") or [] if hit.get("identifier")]

    def entry_metadata(self, pdb_id: str) -> dict:
        envelope = self.http.request_json(
            "GET",
            f"{self.data_url}/core/entry/{pdb_id.lower()}",
            namespace="structures",
            source_name="RCSB PDB",
            license_or_terms="CC0-1.0",
        )
        return envelope

    def to_structure_record(self, pdb_id: str, envelope: dict, uniprot: str | None = None) -> StructureRecord:
        payload = envelope.get("payload") or {}
        info = payload.get("rcsb_entry_info") or {}
        method = None
        methods = payload.get("exptl") or []
        if methods:
            method = methods[0].get("method")
        ligands = []
        for nonpolymer in payload.get("nonpolymer_entities") or []:
            ident = (nonpolymer.get("pdbx_entity_nonpoly") or {}).get("comp_id")
            if ident:
                ligands.append(ident)
        return StructureRecord(
            source_name="RCSB PDB",
            source_url=f"https://www.rcsb.org/structure/{pdb_id.upper()}",
            accessed_at=envelope["accessed_at"],
            query=pdb_id,
            raw_record_hash=envelope.get("raw_record_hash"),
            license_or_terms="CC0-1.0",
            pdb_id=pdb_id.upper(),
            experimental_method=method,
            resolution=info.get("resolution_combined", [None])[0] if isinstance(info.get("resolution_combined"), list) else info.get("resolution_combined"),
            r_free=(payload.get("refine") or [{}])[0].get("ls_R_factor_R_free") if payload.get("refine") else None,
            r_factor=(payload.get("refine") or [{}])[0].get("ls_R_factor_obs") if payload.get("refine") else None,
            ligand_ids=ligands,
            predicted=False,
            uniprot=uniprot,
        )

    def download_pdb(self, pdb_id: str, dest: Path) -> tuple[Path, dict]:
        pdb_id = pdb_id.upper()
        url = f"{self.files_url}/{pdb_id}.pdb"
        try:
            data, meta = self.http.get_bytes(
                url,
                namespace="structures",
                suffix=".pdb",
                source_name="RCSB PDB",
                license_or_terms="CC0-1.0",
            )
        except HttpError as exc:
            if "returned 404" not in str(exc) and "returned 410" not in str(exc):
                raise
            data, meta = self._download_cif_as_pdb(pdb_id, exc)
        atomic_write_bytes(dest, data)
        return dest, meta

    def _download_cif_as_pdb(self, pdb_id: str, pdb_error: HttpError) -> tuple[bytes, dict]:
        url = f"{self.files_url}/{pdb_id}.cif"
        data, meta = self.http.get_bytes(
            url,
            namespace="structures",
            suffix=".cif",
            source_name="RCSB PDB",
            license_or_terms="CC0-1.0",
        )
        try:
            pdb_bytes = _mmcif_to_pdb_bytes(data, pdb_id)
        except Exception as exc:
            raise HttpError(
                f"PDB format missing for {pdb_id} ({pdb_error}); mmCIF conversion failed: {exc}"
            ) from exc
        meta = dict(meta)
        meta["converted_from"] = "mmcif"
        meta["pdb_download_error"] = str(pdb_error)
        return pdb_bytes, meta
