from __future__ import annotations

from pathlib import Path

from drugrepurposing.schemas.docking import DockingPose
from drugrepurposing.utils.io import atomic_write_text


def export_pose_files(best: DockingPose, receptor: Path, sdf: Path, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    text = sdf.read_text(encoding="utf-8", errors="replace")
    first = text.split("$$$$")[0] + "$$$$\n"
    sdf_out = out_dir / "best_pose.sdf"
    pdb_out = out_dir / "best_pose.pdb"
    atomic_write_text(sdf_out, first)
    pdb_lines = ["REMARK computational docking pose, not a binding affinity\n"]
    for line in first.splitlines():
        if line.startswith(("ATOM", "HETATM")):
            pdb_lines.append(line + "\n")
        elif len(line) >= 52 and line[0:3].isdigit() is False and "V    " in line:
            continue
    if len(pdb_lines) == 1:
        pdb_lines.append("REMARK SDF coordinates stored in best_pose.sdf\nEND\n")
    else:
        pdb_lines.append("END\n")
    atomic_write_text(pdb_out, "".join(pdb_lines))
    complex_path = out_dir / "complex.pdb"
    rec = receptor.read_text(encoding="utf-8", errors="replace") if receptor.exists() else ""
    atomic_write_text(complex_path, rec.rstrip() + "\n" + "".join(pdb_lines))
    best.sdf_path = str(sdf_out)
    best.pdb_path = str(pdb_out)
    best.complex_pdb_path = str(complex_path)
    pdbqt = out_dir / "best_pose.pdbqt"
    atomic_write_text(pdbqt, first)
    best.pdbqt_path = str(pdbqt)
