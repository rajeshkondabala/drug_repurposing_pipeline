from __future__ import annotations

import json
from pathlib import Path

from drugrepurposing.config import load_config
from drugrepurposing.sources.opentargets import OpenTargetsClient
from drugrepurposing.utils.cache import ContentAddressedCache
from drugrepurposing.utils.http import HttpClient

FIXTURES = Path(__file__).parent / "fixtures"


def test_normalize_targets(monkeypatch):
    cfg = load_config()
    client = OpenTargetsClient(cfg, HttpClient(cfg, ContentAddressedCache(Path("."), enabled=False)))
    payload = json.loads((FIXTURES / "ot_targets.json").read_text())

    def fake(query, variables):
        return payload

    monkeypatch.setattr(client, "graphql", fake)
    targets = client.associated_targets("EFO_0000685")
    assert len(targets) == 1
    assert targets[0].identifiers.approved_symbol == "IL6R"
    assert targets[0].identifiers.ensembl_gene_id == "ENSG00000160712"
    assert targets[0].source_name == "Open Targets Platform"
    assert targets[0].license_or_terms
    assert targets[0].raw_record_hash


def test_association_query_uses_current_schema_fields():
    from drugrepurposing.sources.opentargets import ASSOC_QUERY, KNOWN_DRUGS_QUERY

    assert "biotype" in ASSOC_QUERY
    assert "bioType" not in ASSOC_QUERY
    assert "baselineExpression" in ASSOC_QUERY
    assert "expressions" not in ASSOC_QUERY
    assert "drugAndClinicalCandidates" in KNOWN_DRUGS_QUERY
    assert "knownDrugs {" not in KNOWN_DRUGS_QUERY


def test_duplicate_targets_dropped(monkeypatch):
    cfg = load_config()
    client = OpenTargetsClient(cfg, HttpClient(cfg, ContentAddressedCache(Path("."), enabled=False)))
    payload = json.loads((FIXTURES / "ot_targets.json").read_text())
    row = payload["payload"]["data"]["disease"]["associatedTargets"]["rows"][0]
    payload["payload"]["data"]["disease"]["associatedTargets"]["rows"] = [row, row]
    monkeypatch.setattr(client, "graphql", lambda q, v: payload)
    targets = client.associated_targets("EFO_0000685")
    assert len(targets) == 1
