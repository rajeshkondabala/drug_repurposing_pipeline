from __future__ import annotations

from drugrepurposing.schemas.docking import DockingPose


def geometry_quality(pose: DockingPose) -> float:
    score = 1.0
    if pose.vina_score is not None and pose.vina_score > 0:
        score -= 0.4
        pose.warnings.append("Positive Vina score; possible poor pose.")
    if pose.cnn_score is None:
        pose.warnings.append("Missing GNINA CNN score.")
        score -= 0.2
    pose.pose_geometry_quality = max(0.0, score)
    pose.pocket_contact_score = 0.7 if pose.vina_score is not None else 0.4
    pose.clash_penalty = 0.0
    return pose.pose_geometry_quality


def rank_poses(poses: list[DockingPose], weights: dict[str, float]) -> list[DockingPose]:
    ranked: list[DockingPose] = []
    best_vina = None
    if poses:
        numeric = [p.vina_score for p in poses if p.vina_score is not None]
        best_vina = min(numeric) if numeric else None
    for pose in poses:
        geometry_quality(pose)
        if best_vina is not None and pose.vina_score is not None:
            pose.rmsd_from_best = abs(pose.vina_score - best_vina)
        vina_term = 0.0
        if pose.vina_score is not None:
            vina_term = max(0.0, min(1.0, (-pose.vina_score) / 12.0))
        cnn_term = pose.cnn_score if pose.cnn_score is not None else 0.0
        aff_term = 0.0
        if pose.cnn_affinity is not None:
            aff_term = max(0.0, min(1.0, pose.cnn_affinity / 10.0))
        final = (
            weights.get("docking_score", 0.25) * vina_term
            + weights.get("cnn_score", 0.20) * cnn_term
            + weights.get("cnn_affinity", 0.15) * aff_term
            + weights.get("pose_geometry_quality", 0.15) * (pose.pose_geometry_quality or 0)
            + weights.get("pocket_contact_score", 0.15) * (pose.pocket_contact_score or 0)
            - weights.get("clash_penalty", 0.10) * (pose.clash_penalty or 0)
        )
        pose.final_pose_score = round(final, 4)
        ranked.append(pose)
    ranked.sort(key=lambda item: item.final_pose_score or 0, reverse=True)
    for idx, pose in enumerate(ranked, start=1):
        pose.pose_rank = idx
    return ranked
