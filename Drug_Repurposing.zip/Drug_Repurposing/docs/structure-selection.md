# Structure selection

1. Map gene → UniProt / Ensembl / AlphaFold accession; record isoform rationale.
2. Search RCSB by UniProt, then names, then (optionally) sequence.
3. Rank by identity, experimental vs predicted, co-crystal ligand, resolution, pocket completeness, missing residues, mutations, oligomer fit. Resolution is never the sole criterion.
4. Prepare structures for the top ranked evidence targets until `structures.max_prepared_targets` succeed (default 5). Targets without a usable experimental or (if allowed) AlphaFold model are skipped rather than blocking the list.
5. Parse SEQRES and ATOM/HETATM separately. SEQRES is the deposited polymer sequence; observed ATOM records and numbering determine what can actually be used for docking.
6. Identical chains: keep one copy unless the pocket is at an interface, in which case all contacting chains are retained.
7. PDBFixer may add missing atoms/termini. Long internal loops, especially in the pocket, are **not** auto-rebuilt and treated as experimental.
8. AlphaFold DB is used only when no suitable experimental structure exists. Pockets from pyKVFinder (GPL plugin, optional extra) or a geometric fallback are labeled computational.

MODELLER is a user-enabled plugin (`structures.modeller_plugin_enabled`) and is off by default pending license review.
