# drug-repurposing

License-aware computational platform for disease-to-target evidence integration, experimental structure selection, ligand preparation, and GNINA docking.

This is a **research and hypothesis-generation** system. It does not diagnose, treat, or recommend clinical use of any target or compound. Target ranks and docking scores are independent and require experimental validation.

## Install

```bash
conda env create -f environment.yml
conda activate drug-repurposing
python -m pip install -e .
drug-repurposing validate-installation
```

The core environment does **not** install Meeko (LGPL-2.1) or pyKVFinder (GPL-3.0). Those are optional copyleft extras:

```bash
conda env update -n drug-repurposing -f environment-extras.yml
```

GNINA is **not** installed by this environment. Pass `--gnina-path` or set `docking.gnina_path` in a gitignored `examples/config.local.yaml` (see `examples/config.local.yaml.example`). Open Babel is not installed by default.

Optional pip extras: `pip install -e ".[chem,structure,docking-prep,pockets,dev]"`

CUDA-specific GNINA builds are documented in `docs/docking.md`.

Lock the environment on the install machine:

```bash
conda env export --from-history > environment-history.yml
conda list --explicit > environment-lock.txt
```

## Ligand tables

Shipped smoke ligands: `examples/input.csv`.

Do not bundle ChEMBL parent-molecule dumps in a source release (CC-BY-SA-3.0). Clean locally:

```bash
python scripts/clean_chembl_ligands.py /path/to/Drugs_Chembl.csv --out-dir data/ligands
head -n 51 data/ligands/Drugs_Chembl.cleaned.csv > data/ligands/Drugs_Chembl.smoke50.csv
```

## CLI

```bash
drug-repurposing --help
drug-repurposing --version
drug-repurposing init-config --output config.yaml
drug-repurposing search-condition --condition "rheumatoid arthritis" --config examples/config.yaml
drug-repurposing analyze-targets --condition "rheumatoid arthritis" --config examples/config.yaml --output outputs/project_001
drug-repurposing prepare-structures --project outputs/project_001 --config examples/config.yaml
drug-repurposing prepare-ligands --input examples/input.csv --output outputs/project_001/ligands --config examples/config.yaml
drug-repurposing dock --project outputs/project_001 --gnina-path /path/to/gnina --config examples/config.yaml
drug-repurposing run --condition "rheumatoid arthritis" --ligands examples/input.csv --gnina-path /path/to/gnina --output outputs/rheumatoid_arthritis --config examples/config.yaml
drug-repurposing validate-installation
drug-repurposing show-provenance --project outputs/project_001
drug-repurposing export-license-report --project outputs/project_001
```

`prepare-structures` walks ranked evidence targets until `structures.max_prepared_targets` (default 5) succeed. Individual commands resume from cached intermediates under `cache/` and the project directory.

## License

Apache-2.0 for this repository's original code. Dependency licenses and data licenses are tracked separately in `configs/licenses.yaml`, `docs/licensing.md`, and `THIRD_PARTY_NOTICES/`. Restricted sources (DrugBank, BindingDB, DrugCentral, Semantic Scholar) are disabled by default.

## Citation

See `CITATION.cff` and the generated `reports/license_report.csv` for data-source attribution (Open Targets, RCSB PDB, AlphaFold DB, UniProt, PubChem, ChEMBL, Europe PMC, PubMed, ClinicalTrials.gov).
