from __future__ import annotations

import re
from typing import Any

from drugrepurposing.config import AppConfig
from drugrepurposing.logging_utils import get_logger
from drugrepurposing.schemas.disease import ConditionResolution, DiseaseIdentifier
from drugrepurposing.schemas.target import (
    CrossConditionAssociation,
    DatatypeScore,
    KnownDrug,
    TargetIdentifiers,
    TargetRecord,
)
from drugrepurposing.utils.http import HttpClient, HttpError

LOGGER = get_logger("opentargets")

SEARCH_QUERY = """
query search($q: String!) {
  search(queryString: $q, entityNames: ["disease"]) {
    hits {
      id
      name
      entity
      description
      score
    }
  }
}
"""

DISEASE_QUERY = """
query disease($efoId: String!) {
  disease(efoId: $efoId) {
    id
    name
    description
    synonyms { relation terms }
    dbXRefs
    therapeuticAreas { id name }
  }
}
"""

ASSOC_QUERY = """
query associatedTargets($id: String!, $index: Int!, $size: Int!) {
  disease(efoId: $id) {
    id
    name
    associatedTargets(page: {index: $index, size: $size}, orderByScore: "score desc") {
      count
      rows {
        score
        datatypeScores { id score }
        target {
          id
          approvedSymbol
          approvedName
          biotype
          proteinIds { id source }
          tractability { label modality value }
          safetyLiabilities { event datasource }
          baselineExpression(page: {index: 0, size: 25}) {
            rows {
              median
              tissueBiosample { biosampleName }
            }
          }
        }
      }
    }
  }
}
"""

KNOWN_DRUGS_QUERY = """
query knownDrugs($efoId: String!) {
  disease(efoId: $efoId) {
    id
    drugAndClinicalCandidates {
      count
      rows {
        maxClinicalStage
        drug { id name }
      }
    }
  }
}
"""

CROSS_QUERY = """
query associatedDiseases($ensemblId: String!, $size: Int!) {
  target(ensemblId: $ensemblId) {
    id
    approvedSymbol
    associatedDiseases(page: {index: 0, size: $size}) {
      rows {
        score
        disease { id name }
      }
    }
  }
}
"""


def _ontology_from_id(identifier: str) -> str:
    prefix = identifier.split("_")[0].upper()
    mapping = {
        "EFO": "EFO",
        "MONDO": "MONDO",
        "ORPHA": "Orphanet",
        "HP": "HPO",
        "DOID": "DOID",
        "MESH": "MeSH",
        "UMLS": "UMLS",
    }
    return mapping.get(prefix, prefix)


class OpenTargetsClient:
    def __init__(self, config: AppConfig, http: HttpClient) -> None:
        self.config = config
        self.http = http
        self.api_url = config.sources.opentargets.api_url or (
            "https://api.platform.opentargets.org/api/v4/graphql"
        )
        self.license = "CC0-1.0 (Open Targets data); linked evidence retains original licenses"

    def graphql(self, query: str, variables: dict[str, Any]) -> dict[str, Any]:
        record = self.http.request_json(
            "POST",
            self.api_url,
            json_body={"query": query, "variables": variables},
            namespace="http",
            source_name="Open Targets Platform",
            license_or_terms=self.license,
            source_version="graphql-v4",
        )
        errors = (record.get("payload") or {}).get("errors") or []
        if errors:
            messages = "; ".join(str(item.get("message") or item) for item in errors[:5])
            raise HttpError(f"Open Targets GraphQL error: {messages}")
        return record

    def search_conditions(self, text: str) -> ConditionResolution:
        warnings: list[str] = []
        try:
            record = self.graphql(SEARCH_QUERY, {"q": text})
        except HttpError as exc:
            warnings.append(f"Open Targets search failed: {exc}")
            return ConditionResolution(
                input_condition=text,
                warnings=warnings,
                resolution_method="failed",
            )
        hits = (
            record.get("payload", {})
            .get("data", {})
            .get("search", {})
            .get("hits", [])
        )
        diseases: list[DiseaseIdentifier] = []
        for hit in hits[: self.config.condition.max_search_hits]:
            identifier = str(hit.get("id") or "")
            diseases.append(
                DiseaseIdentifier(
                    id=identifier,
                    name=hit.get("name") or identifier,
                    synonyms=[],
                    ontology=_ontology_from_id(identifier),
                    description=hit.get("description"),
                )
            )
        selected, method, requires = self._select(text, diseases)
        if len(diseases) > 1:
            warnings.append(
                "Multiple plausible conditions matched; do not assume unambiguous mapping."
            )
        return ConditionResolution(
            input_condition=text,
            selected_condition=selected,
            alternatives=[d for d in diseases if selected is None or d.id != selected.id],
            requires_confirmation=requires,
            resolution_method=method,
            warnings=warnings,
        )

    def _select(
        self, text: str, diseases: list[DiseaseIdentifier]
    ) -> tuple[DiseaseIdentifier | None, str, bool]:
        if not diseases:
            return None, "no_hits", False
        normalized = re.sub(r"\s+", " ", text.strip().lower())
        exact = [d for d in diseases if d.name.lower() == normalized]
        if len(exact) == 1:
            return exact[0], "exact_name", False
        synonym_hits = [d for d in diseases if normalized in [s.lower() for s in d.synonyms]]
        if len(synonym_hits) == 1:
            return synonym_hits[0], "synonym", False
        id_hits = [d for d in diseases if d.id.lower() == text.strip().upper() or d.id == text.strip()]
        if len(id_hits) == 1:
            return id_hits[0], "identifier", False
        if len(diseases) == 1 and self.config.condition.auto_select_if_unique:
            return diseases[0], "unique_hit", False
        if self.config.condition.require_user_confirmation:
            return None, "needs_confirmation", True
        return diseases[0], "top_hit_unconfirmed", True

    def confirm(self, resolution: ConditionResolution, selected_id: str) -> ConditionResolution:
        pool = []
        if resolution.selected_condition:
            pool.append(resolution.selected_condition)
        pool.extend(resolution.alternatives)
        match = next((item for item in pool if item.id == selected_id), None)
        if match is None:
            raise ValueError(f"Unknown condition id {selected_id}")
        resolution.selected_condition = match
        resolution.alternatives = [item for item in pool if item.id != selected_id]
        resolution.requires_confirmation = False
        resolution.resolution_method = "user_confirmation"
        return resolution

    def associated_targets(self, disease_id: str) -> list[TargetRecord]:
        page_size = self.config.sources.opentargets.page_size or 50
        index = 0
        records: list[TargetRecord] = []
        seen: set[str] = set()
        while len(records) < self.config.targets.max_targets:
            envelope = self.graphql(
                ASSOC_QUERY, {"id": disease_id, "index": index, "size": page_size}
            )
            block = (
                envelope.get("payload", {})
                .get("data", {})
                .get("disease", {})
                .get("associatedTargets", {})
            )
            rows = block.get("rows") or []
            if not rows:
                break
            for row in rows:
                target = row.get("target") or {}
                ensembl = target.get("id")
                if not ensembl or ensembl in seen:
                    continue
                seen.add(ensembl)
                proteins = [
                    p.get("id")
                    for p in target.get("proteinIds") or []
                    if p.get("source") in {"uniprot_swissprot", "uniprot"}
                ]
                score = float(row.get("score") or 0.0)
                if score < self.config.targets.min_association_score:
                    continue
                records.append(
                    TargetRecord(
                        source_name="Open Targets Platform",
                        source_url=self.api_url,
                        accessed_at=envelope["accessed_at"],
                        source_version=envelope.get("source_version"),
                        query=envelope.get("query"),
                        raw_record_hash=envelope.get("raw_record_hash"),
                        license_or_terms=self.license,
                        identifiers=TargetIdentifiers(
                            ensembl_gene_id=ensembl,
                            approved_symbol=target.get("approvedSymbol"),
                            approved_name=target.get("approvedName"),
                            uniprot_accessions=[p for p in proteins if p],
                            alphafold_accession=proteins[0] if proteins else None,
                        ),
                        association_score=score,
                        datatype_scores=[
                            DatatypeScore(id=item["id"], score=float(item.get("score") or 0))
                            for item in row.get("datatypeScores") or []
                            if item.get("id")
                        ],
                        tractability={"entries": target.get("tractability") or []},
                        safety_liabilities=[
                            str(item.get("event"))
                            for item in target.get("safetyLiabilities") or []
                            if item.get("event")
                        ],
                        expression_tissues=[
                            (item.get("tissueBiosample") or {}).get("biosampleName")
                            for item in (target.get("baselineExpression") or {}).get("rows") or []
                            if (item.get("tissueBiosample") or {}).get("biosampleName")
                        ],
                        raw=row,
                    )
                )
                if len(records) >= self.config.targets.max_targets:
                    break
            index += 1
            if index * page_size >= int(block.get("count") or 0):
                break
        return records

    def known_drugs(self, disease_id: str) -> list[KnownDrug]:
        try:
            envelope = self.graphql(KNOWN_DRUGS_QUERY, {"efoId": disease_id})
        except HttpError as exc:
            LOGGER.warning("known_drugs_failed", extra={"error": str(exc)})
            return []
        rows = (
            envelope.get("payload", {})
            .get("data", {})
            .get("disease", {})
            .get("drugAndClinicalCandidates", {})
            .get("rows")
            or []
        )
        drugs: list[KnownDrug] = []
        for row in rows:
            drug = row.get("drug") or {}
            drugs.append(
                KnownDrug(
                    name=drug.get("name") or drug.get("id") or "unknown",
                    chembl_id=drug.get("id"),
                    mechanism_of_action=None,
                    phase=str(row.get("maxClinicalStage")) if row.get("maxClinicalStage") is not None else None,
                    disease_id=disease_id,
                    source="Open Targets Platform",
                    source_url=self.api_url,
                    license=self.license,
                )
            )
        return drugs

    def cross_condition(self, ensembl_id: str) -> list[CrossConditionAssociation]:
        try:
            envelope = self.graphql(CROSS_QUERY, {"ensemblId": ensembl_id, "size": 25})
        except HttpError as exc:
            LOGGER.warning("cross_condition_failed", extra={"error": str(exc)})
            return []
        rows = (
            envelope.get("payload", {})
            .get("data", {})
            .get("target", {})
            .get("associatedDiseases", {})
            .get("rows")
            or []
        )
        out: list[CrossConditionAssociation] = []
        for row in rows:
            disease = row.get("disease") or {}
            score = float(row.get("score") or 0)
            out.append(
                CrossConditionAssociation(
                    disease_id=disease.get("id") or "",
                    disease_name=disease.get("name") or "",
                    score=score,
                    association_class="biological association",
                    notes=(
                        "Association with another disease is not proof of utility "
                        "for the requested condition."
                    ),
                )
            )
        return out
