from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

AA3TO1 = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "ILE": "I",
    "LEU": "L", "LYS": "K", "MET": "M", "PHE": "F", "PRO": "P",
    "SER": "S", "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V",
    "SEC": "U", "PYL": "O", "MSE": "M",
}


@dataclass
class Residue:
    chain: str
    resseq: int
    icode: str
    name: str
    atoms: set[str] = field(default_factory=set)
    altlocs: set[str] = field(default_factory=set)
    hetero: bool = False
    coords: list[tuple[float, float, float]] = field(default_factory=list)


@dataclass
class ParsedPDB:
    seqres: dict[str, list[str]]
    residues: dict[tuple[str, int, str], Residue]
    hetatms: list[Residue]
    header: str = ""
    raw: str = ""


def _parse_xyz(line: str) -> tuple[float, float, float]:
    if len(line) >= 54:
        try:
            return float(line[30:38]), float(line[38:46]), float(line[46:54])
        except ValueError:
            pass
    parts = line.split()
    floats = []
    for token in parts:
        try:
            floats.append(float(token))
        except ValueError:
            continue
    if len(floats) < 4:
        raise ValueError(f"Cannot parse coordinates from PDB line: {line}")
    # serial, x, y, z, occupancy...
    return floats[1], floats[2], floats[3]


def parse_pdb(text: str) -> ParsedPDB:
    seqres: dict[str, list[str]] = {}
    residues: dict[tuple[str, int, str], Residue] = {}
    hetatms: list[Residue] = []
    for line in text.splitlines():
        if line.startswith("SEQRES"):
            chain = line[11].strip() or line[11]
            names = line[19:].split()
            seqres.setdefault(chain, []).extend(names)
        elif line.startswith(("ATOM  ", "HETATM")):
            name = line[17:20].strip()
            chain = line[21].strip() or "A"
            resseq = int(line[22:26])
            icode = line[26].strip()
            atom = line[12:16].strip()
            alt = line[16].strip() if len(line) > 16 else ""
            x, y, z = _parse_xyz(line)
            key = (chain, resseq, icode)
            hetero = line.startswith("HETATM")
            residue = residues.get(key)
            if residue is None:
                residue = Residue(chain=chain, resseq=resseq, icode=icode, name=name, hetero=hetero)
                residues[key] = residue
                if hetero:
                    hetatms.append(residue)
            residue.atoms.add(atom)
            if alt:
                residue.altlocs.add(alt)
            residue.coords.append((x, y, z))
    return ParsedPDB(seqres=seqres, residues=residues, hetatms=hetatms, raw=text)


def parse_pdb_file(path: Path) -> ParsedPDB:
    return parse_pdb(path.read_text(encoding="utf-8", errors="replace"))


def seqres_sequence(names: list[str]) -> str:
    return "".join(AA3TO1.get(name, "X") for name in names)
