from __future__ import annotations

from pydantic import BaseModel, Field


class LigandIssue(BaseModel):
    code: str
    message: str
    severity: str = "error"


class LigandRecord(BaseModel):
    compound_id: str
    name: str | None = None
    smiles: str | None = None
    canonical_smiles: str | None = None
    inchi: str | None = None
    inchikey: str | None = None
    input_format: str
    input_path: str | None = None
    had_3d_coordinates: bool = False
    stereochemistry_undefined: bool = False
    tautomer_ambiguous: bool = False
    covalent_or_reactive: bool = False
    salt_stripped: bool = False
    force_field: str | None = None
    energy_before: float | None = None
    energy_after: float | None = None
    sdf_path: str | None = None
    pdbqt_path: str | None = None
    issues: list[LigandIssue] = Field(default_factory=list)
    preparation_manifest: dict[str, str | float | int | bool | None] = Field(default_factory=dict)
