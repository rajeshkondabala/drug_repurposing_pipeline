from __future__ import annotations

from pathlib import Path

from drugrepurposing.config import AppConfig
from drugrepurposing.docking.gnina_runner import gnina_uses_rdkit_io, run_gnina, validate_gnina
from drugrepurposing.docking.grid import box_from_pocket, validate_box
from drugrepurposing.docking.meeko_adapter import prepare_receptor_pdbqt
from drugrepurposing.docking.pose_selection import rank_poses
from drugrepurposing.docking.rescoring import attach_notes
from drugrepurposing.docking.validation import parse_gnina_sdf
from drugrepurposing.logging_utils import get_logger
from drugrepurposing.provenance import ProvenanceTracker
from drugrepurposing.reports.pdb_export import export_pose_files
from drugrepurposing.schemas.docking import DockingPose
from drugrepurposing.schemas.structure import PocketDefinition, StructureRecord
from drugrepurposing.store import WorkflowState
from drugrepurposing.workflows import ProjectWorkspace

LOGGER = get_logger("docking")


def receptor_pdb_for_structure(workspace: ProjectWorkspace, structure: StructureRecord) -> Path:
    """Resolve the prepared receptor for this structure, not the first PDB in the project."""
    candidates: list[Path] = []
    if structure.target_symbol:
        candidates.append(workspace.root / "structures" / structure.target_symbol / "repaired.pdb")
    if structure.file_path:
        file_path = Path(structure.file_path)
        candidates.append(file_path)
        candidates.append(file_path.with_name("repaired.pdb"))
        if file_path.parent.name:
            candidates.append(workspace.root / "structures" / file_path.parent.name / "repaired.pdb")
    for pdb_id in filter(None, (structure.pdb_id, structure.alphafold_id)):
        for directory in (workspace.root / "structures").glob("*"):
            meta = directory / "structure.json"
            if not meta.exists():
                continue
            text = meta.read_text(encoding="utf-8")
            if pdb_id in text:
                candidates.append(directory / "repaired.pdb")
    for candidate in candidates:
        if candidate.exists() and candidate.stat().st_size > 0:
            return candidate
    raise RuntimeError(
        f"No repaired receptor PDB for structure {structure.pdb_id or structure.alphafold_id or 'unknown'}"
    )


def dock_project(
    config: AppConfig,
    workspace: ProjectWorkspace,
    provenance: ProvenanceTracker,
    gnina_path: str | None = None,
) -> list[DockingPose]:
    gnina = gnina_path or config.docking.gnina_path
    if not gnina:
        raise RuntimeError("GNINA path is required via --gnina-path or docking.gnina_path")
    version = validate_gnina(gnina)
    provenance.set_tool_version("gnina_version", version)
    rdkit_io = gnina_uses_rdkit_io(version)
    if rdkit_io:
        provenance.warn(
            "GNINA binary reports an RDKit build; ligands are docked from SDF and the "
            "receptor from PDB. Meeko PDBQT with AutoDock aromatic type A is not used."
        )
    provenance.warn(
        "Do not assume this GNINA binary is commercially redistributable without inspecting "
        "its exact build, bundled libraries, model files, and notices."
    )
    structures = [
        StructureRecord.model_validate(item)
        for item in (workspace.read_json("structures/selected.json") or [])
    ]
    ligands = workspace.read_json("ligands/ligands.json") or []
    if not structures:
        raise RuntimeError("No prepared structures. Run prepare-structures first.")
    if not ligands:
        raise RuntimeError("No prepared ligands. Run prepare-ligands first.")
    pose_weights = (config.scoring or {}).get("pose_ranking") or {}
    all_poses: list[DockingPose] = []
    for structure in structures:
        receptor_prepared = receptor_pdb_for_structure(workspace, structure)
        rec_pdbqt = receptor_prepared.with_suffix(".pdbqt")
        if not rec_pdbqt.exists() or rec_pdbqt.stat().st_size == 0:
            prepare_receptor_pdbqt(receptor_prepared, rec_pdbqt)
        receptor_for_gnina = receptor_prepared if rdkit_io else rec_pdbqt
        pockets = structure.pockets or [
            PocketDefinition(
                pocket_id="default",
                method="unspecified",
                center=(0.0, 0.0, 0.0),
                dimensions=(20.0, 20.0, 20.0),
                experimental=not structure.predicted,
                warnings=["Default box used"],
            )
        ]
        for pocket in pockets:
            box = box_from_pocket(pocket)
            for warning in validate_box(box):
                provenance.warn(warning)
            for ligand in ligands:
                if rdkit_io:
                    lig_input = Path(ligand.get("sdf_path") or ligand.get("pdbqt_path") or "")
                else:
                    lig_input = Path(ligand.get("pdbqt_path") or "")
                if not lig_input.exists():
                    provenance.warn(f"Missing ligand file for {ligand.get('compound_id')}: {lig_input}")
                    continue
                out_dir = workspace.root / "docking" / (structure.pdb_id or structure.alphafold_id or "struct") / pocket.pocket_id / ligand["compound_id"]
                out_sdf = out_dir / "poses.sdf"
                run = run_gnina(gnina, receptor_for_gnina, lig_input, out_sdf, box, config.docking, out_dir)
                workspace.write_json(str(out_dir.relative_to(workspace.root) / "run.json"), run.model_dump(mode="json"))
                if run.exit_code != 0 or not out_sdf.exists() or out_sdf.stat().st_size == 0:
                    provenance.warn(
                        f"Docking failed for {ligand['compound_id']}: "
                        f"{(run.stderr or run.stdout)[-400:]}"
                    )
                    continue
                poses = parse_gnina_sdf(
                    out_sdf,
                    ligand_id=ligand["compound_id"],
                    structure_id=structure.pdb_id or structure.alphafold_id or "unknown",
                    pocket_id=pocket.pocket_id,
                    target=None,
                )
                poses = attach_notes(rank_poses(poses, pose_weights))
                if poses:
                    export_pose_files(poses[0], receptor_prepared, out_sdf, out_dir)
                    all_poses.extend(poses)
    workspace.write_json("docking/poses.json", [p.model_dump(mode="json") for p in all_poses])
    workspace.set_state(WorkflowState.DOCKING_COMPLETED)
    provenance.set_status(WorkflowState.DOCKING_COMPLETED.value)
    LOGGER.info("docking_complete", extra={"n_poses": len(all_poses)})
    return all_poses
