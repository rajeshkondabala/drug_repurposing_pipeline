from __future__ import annotations

import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from drugrepurposing import RESEARCH_DISCLAIMER, __version__
from drugrepurposing.config import AppConfig
from drugrepurposing.utils.hashes import sha256_file
from drugrepurposing.utils.io import atomic_write_text


class ProvenanceTracker:
    def __init__(self, project_dir: Path, config: AppConfig) -> None:
        self.project_dir = project_dir
        self.config = config
        self.manifest: dict[str, Any] = {
            "package_version": __version__,
            "python_version": sys.version,
            "operating_system": platform.platform(),
            "cuda_version": None,
            "gnina_version": None,
            "meeko_version": None,
            "pdbfixer_version": None,
            "rdkit_version": None,
            "config_hash": config.sha256(),
            "random_seeds": {
                "project": config.project.random_seed,
                "ligands": config.ligands.random_seed,
                "docking": config.docking.seed,
            },
            "input_files": {},
            "commands": [],
            "data_sources": [],
            "licenses": config.licenses,
            "warnings": [],
            "errors": [],
            "workflow_status": "initialized",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "disclaimer": RESEARCH_DISCLAIMER,
        }

    def add_input(self, path: Path) -> None:
        if path.exists() and path.is_file():
            self.manifest["input_files"][str(path)] = sha256_file(path)

    def add_command(self, command: list[str]) -> None:
        self.manifest["commands"].append(
            {"command": command, "at": datetime.now(timezone.utc).isoformat()}
        )

    def add_source(self, record: dict[str, Any]) -> None:
        self.manifest["data_sources"].append(
            {
                "source_name": record.get("source_name"),
                "source_url": record.get("source_url"),
                "accessed_at": record.get("accessed_at"),
                "source_version": record.get("source_version"),
                "license_or_terms": record.get("license_or_terms"),
                "raw_record_hash": record.get("raw_record_hash"),
            }
        )

    def warn(self, message: str) -> None:
        self.manifest["warnings"].append(message)

    def error(self, message: str) -> None:
        self.manifest["errors"].append(message)

    def set_status(self, status: str) -> None:
        self.manifest["workflow_status"] = status

    def set_tool_version(self, name: str, version: str | None) -> None:
        self.manifest[name] = version

    def write(self) -> Path:
        path = self.project_dir / "provenance.json"
        atomic_write_text(path, json.dumps(self.manifest, indent=2, default=str))
        atomic_write_text(self.project_dir / "manifest.json", json.dumps(self.manifest, indent=2, default=str))
        return path
