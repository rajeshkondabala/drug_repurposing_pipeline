from __future__ import annotations

from drugrepurposing.schemas.evidence import ClinicalPhase
from drugrepurposing.sources.clinicaltrials import normalize_phase


def test_phase_normalization():
    assert normalize_phase("PHASE2") == ClinicalPhase.PHASE_2
    assert normalize_phase(["PHASE1", "PHASE2"]) == ClinicalPhase.PHASE_2
    assert normalize_phase("Phase 1/Phase 2") == ClinicalPhase.PHASE_1_2
    assert normalize_phase("NA") == ClinicalPhase.NOT_APPLICABLE
    assert normalize_phase(None) == ClinicalPhase.UNKNOWN
    assert normalize_phase("EARLY_PHASE1") == ClinicalPhase.PHASE_1
