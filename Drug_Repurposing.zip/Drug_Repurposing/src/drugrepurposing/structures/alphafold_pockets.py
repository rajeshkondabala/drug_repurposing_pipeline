from __future__ import annotations

from drugrepurposing.schemas.structure import PocketDefinition
from drugrepurposing.structures.ligand_pocket import heavy_atom_box
from drugrepurposing.structures.seqres import ParsedPDB


def _try_pykvfinder(pdb_path: str) -> list[dict] | None:
    try:
        import pyKVFinder  # type: ignore
    except Exception:
        return None
    try:
        results = pyKVFinder.run_workflow(pdb_path)
        cavities = getattr(results, "cavities", None) or []
        parsed: list[dict] = []
        for idx, cavity in enumerate(cavities):
            parsed.append(
                {
                    "id": getattr(cavity, "name", f"AF_pocket_{idx+1}"),
                    "volume": float(getattr(cavity, "volume", 0.0) or 0.0),
                    "depth": float(getattr(cavity, "depth", 0.0) or 0.0),
                    "points": list(getattr(cavity, "points", []) or []),
                }
            )
        return parsed
    except Exception:
        return None


def fallback_grid_pockets(parsed: ParsedPDB, n: int = 3) -> list[PocketDefinition]:
    protein_coords = [xyz for res in parsed.residues.values() if not res.hetero for xyz in res.coords]
    if not protein_coords:
        raise ValueError("No protein coordinates for pocket detection")
    # Simple spatial bins as a conservative fallback when pyKVFinder is unavailable.
    xs, ys, zs = zip(*protein_coords)
    cx, cy, cz = (sum(xs) / len(xs), sum(ys) / len(ys), sum(zs) / len(zs))
    seeds = [
        (cx, cy, cz),
        (min(xs) + 8, cy, cz),
        (cx, min(ys) + 8, cz),
    ][:n]
    pockets: list[PocketDefinition] = []
    for idx, seed in enumerate(seeds, start=1):
        nearby = [pt for pt in protein_coords if sum((a - b) ** 2 for a, b in zip(pt, seed)) ** 0.5 < 10]
        if len(nearby) < 5:
            nearby = protein_coords[:30]
        center, size, radius = heavy_atom_box(nearby, 5.0)
        pockets.append(
            PocketDefinition(
                pocket_id=f"AF_fallback_{idx}",
                method="alphafold_grid_fallback",
                center=center,
                dimensions=size,
                radius=radius,
                volume=size[0] * size[1] * size[2],
                experimental=False,
                warnings=[
                    "Pocket predicted computationally from an AlphaFold model; not experimentally validated.",
                    "pyKVFinder was unavailable; a conservative geometric fallback was used.",
                ],
            )
        )
    return pockets


def rank_alphafold_pockets(
    pdb_path: str,
    parsed: ParsedPDB,
    plddt_by_residue: dict[int, float] | None,
    top_n: int,
) -> list[PocketDefinition]:
    found = _try_pykvfinder(pdb_path)
    if not found:
        pockets = fallback_grid_pockets(parsed, n=top_n)
    else:
        scored = sorted(found, key=lambda item: (item.get("volume", 0), item.get("depth", 0)), reverse=True)
        pockets = []
        for item in scored[:top_n]:
            points = item.get("points") or []
            coords = [(float(p[0]), float(p[1]), float(p[2])) for p in points[:50]] or [(0.0, 0.0, 0.0)]
            center, size, radius = heavy_atom_box(coords, 4.0)
            plddts = list((plddt_by_residue or {}).values())
            mean_p = sum(plddts) / len(plddts) if plddts else None
            warnings = ["Pocket predicted computationally from an AlphaFold model; not experimentally validated."]
            if mean_p is not None and mean_p < 70:
                warnings.append("Low AlphaFold confidence near pocket residues.")
            pockets.append(
                PocketDefinition(
                    pocket_id=str(item.get("id")),
                    method="pyKVFinder",
                    center=center,
                    dimensions=size,
                    radius=radius,
                    volume=float(item.get("volume") or 0),
                    plddt_mean=mean_p,
                    experimental=False,
                    warnings=warnings,
                )
            )
    return pockets
