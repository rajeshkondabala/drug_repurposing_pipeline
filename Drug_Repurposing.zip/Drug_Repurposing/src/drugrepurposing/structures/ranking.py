from __future__ import annotations

from drugrepurposing.config import AppConfig
from drugrepurposing.schemas.structure import ChainAnalysis, StructureRecord
from drugrepurposing.structures.chains import identity


def group_identical_chains(chains: list[ChainAnalysis], threshold: float = 0.95) -> list[list[str]]:
    groups: list[list[str]] = []
    assigned: set[str] = set()
    for i, chain in enumerate(chains):
        if chain.chain_id in assigned or not chain.sequence:
            continue
        group = [chain.chain_id]
        assigned.add(chain.chain_id)
        for other in chains[i + 1 :]:
            if other.chain_id in assigned or not other.sequence:
                continue
            if identity(chain.sequence, other.sequence) >= threshold:
                group.append(other.chain_id)
                assigned.add(other.chain_id)
        groups.append(group)
    return groups


def choose_chain(
    chains: list[ChainAnalysis],
    groups: list[list[str]],
    pocket_residues: set[str],
    interface: bool,
) -> list[ChainAnalysis]:
    by_id = {chain.chain_id: chain for chain in chains}
    if interface:
        involved = {res.split(":")[0] for res in pocket_residues}
        for chain in chains:
            if chain.chain_id in involved:
                chain.selected = True
                chain.interface_pocket = True
                chain.selection_reason = "Retained because the pocket appears at a chain interface."
        return chains

    for group in groups:
        ranked = sorted(
            (by_id[cid] for cid in group if cid in by_id),
            key=lambda c: (
                -sum(1 for res in pocket_residues if res.startswith(f"{c.chain_id}:")),
                len(c.missing_internal),
                len(c.alternate_locations),
                len(c.missing_backbone),
            ),
        )
        if not ranked:
            continue
        winner = ranked[0]
        winner.selected = True
        winner.selection_reason = (
            "Selected among identical/near-identical chains for pocket completeness "
            "and fewest missing residues."
        )
    if not any(chain.selected for chain in chains):
        if chains:
            chains[0].selected = True
            chains[0].selection_reason = "Only chain available or no SEQRES grouping."
    return chains


def rank_structures(records: list[StructureRecord], config: AppConfig) -> list[StructureRecord]:
    weights = (config.scoring or {}).get("structure_ranking") or {}
    experimental_available = any(not item.predicted for item in records)
    ranked: list[StructureRecord] = []
    for record in records:
        if record.predicted and experimental_available and config.structures.experimental_only_if_available:
            continue
        if record.resolution and record.resolution > config.structures.minimum_resolution:
            continue
        identity_score = 1.0 if record.uniprot else 0.6
        experimental = 0.0 if record.predicted else 1.0
        ligand = 1.0 if record.ligand_ids else 0.2
        resolution = 0.0
        if record.resolution:
            resolution = max(0.0, 1.0 - (record.resolution - 1.0) / 3.5)
        completeness = record.pocket_completeness if record.pocket_completeness is not None else 0.5
        missing = max(0.0, 1.0 - record.missing_residue_count / 50.0)
        mutations = max(0.0, 1.0 - record.mutation_count / 10.0)
        oligomer = 0.7
        score = (
            weights.get("identity_match", 0.22) * identity_score
            + weights.get("experimental_bonus", 0.18) * experimental
            + weights.get("ligand_pocket", 0.16) * ligand
            + weights.get("resolution", 0.12) * resolution
            + weights.get("pocket_completeness", 0.12) * completeness
            + weights.get("missing_residues", 0.08) * missing
            + weights.get("mutations", 0.06) * mutations
            + weights.get("oligomer_fit", 0.06) * oligomer
        )
        record.structure_score = round(score, 4)
        reasons = []
        if not record.predicted:
            reasons.append("experimental structure preferred over predicted")
        if record.ligand_ids:
            reasons.append("co-crystallized ligand present")
        if record.resolution:
            reasons.append(f"resolution {record.resolution} Å (not used as the sole criterion)")
        record.selection_reason = "; ".join(reasons) or "fallback ranking"
        ranked.append(record)
    ranked.sort(key=lambda item: item.structure_score, reverse=True)
    if not ranked and config.structures.allow_predicted_structure:
        predicted = [item for item in records if item.predicted]
        predicted.sort(key=lambda item: item.plddt_mean or 0, reverse=True)
        return predicted
    return ranked
