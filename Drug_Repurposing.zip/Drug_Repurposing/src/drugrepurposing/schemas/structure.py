from __future__ import annotations

from pydantic import BaseModel, Field

from drugrepurposing.schemas.disease import ProvenanceMixin


class PocketDefinition(BaseModel):
    pocket_id: str
    method: str
    ligand_resname: str | None = None
    ligand_chain: str | None = None
    ligand_residue_number: int | None = None
    residue_ids: list[str] = Field(default_factory=list)
    center: tuple[float, float, float]
    dimensions: tuple[float, float, float]
    radius: float | None = None
    volume: float | None = None
    plddt_mean: float | None = None
    experimental: bool = True
    warnings: list[str] = Field(default_factory=list)


class ChainAnalysis(BaseModel):
    chain_id: str
    seqres_length: int = 0
    observed_length: int = 0
    missing_terminal: list[str] = Field(default_factory=list)
    missing_internal: list[str] = Field(default_factory=list)
    missing_backbone: list[str] = Field(default_factory=list)
    missing_sidechain: list[str] = Field(default_factory=list)
    alternate_locations: list[str] = Field(default_factory=list)
    nonstandard_residues: list[str] = Field(default_factory=list)
    sequence: str = ""
    selected: bool = False
    selection_reason: str | None = None
    interface_pocket: bool = False


class StructureRecord(ProvenanceMixin):
    pdb_id: str | None = None
    alphafold_id: str | None = None
    chain_id: str | None = None
    experimental_method: str | None = None
    resolution: float | None = None
    r_factor: float | None = None
    r_free: float | None = None
    ligand_ids: list[str] = Field(default_factory=list)
    pocket_completeness: float | None = None
    missing_residue_count: int = 0
    mutation_count: int = 0
    structure_score: float = 0.0
    selection_reason: str | None = None
    predicted: bool = False
    uniprot: str | None = None
    assembly_id: str | None = None
    plddt_mean: float | None = None
    chains: list[ChainAnalysis] = Field(default_factory=list)
    pockets: list[PocketDefinition] = Field(default_factory=list)
    repaired: bool = False
    inserted_residues: list[str] = Field(default_factory=list)
    special_handling: list[str] = Field(default_factory=list)
    file_path: str | None = None
    checksum: str | None = None
    target_symbol: str | None = None
