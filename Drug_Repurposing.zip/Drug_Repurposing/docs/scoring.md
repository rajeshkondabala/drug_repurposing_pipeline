# Target scoring

Configurable weights live in `configs/scoring.yaml`.

\[
S = w_a S_a + w_g S_g + w_l S_l + w_c S_c + w_d S_d + w_m S_m + w_t S_t + w_{ti} S_{ti} - w_r S_r - w_k S_k - w_p S_p
\]

Components (each explained in the target JSON/HTML):

- association (Open Targets overall)
- genetic
- literature (typed classes + recency; **not** raw publication count)
- clinical (normalized phases; existence ≠ success)
- drug
- mechanistic
- tractability
- tissue
- safety risk, conflict, completeness penalty

Novelty categories: `established_target`, `clinically_active_target`, `preclinical_target`, `understudied_target`, `candidate_novel_target`, `insufficient_evidence`.

`candidate_novel_target` requires strong association or mechanism, multiple independent sources, successful searches, completeness above threshold, and no approved/clinical-stage program in **searched** sources. Wording is always:

> Candidate novel or understudied target based on the searched sources and date of analysis.

Docking scores are excluded from \(S\).
