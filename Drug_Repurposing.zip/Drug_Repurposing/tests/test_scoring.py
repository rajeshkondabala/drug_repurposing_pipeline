from __future__ import annotations

from drugrepurposing.config import load_config
from drugrepurposing.evidence.novelty import classify_novelty
from drugrepurposing.evidence.target_scoring import score_target
from drugrepurposing.schemas.evidence import NoveltyCategory
from drugrepurposing.schemas.target import KnownDrug, TargetIdentifiers, TargetRecord


def _target() -> TargetRecord:
    return TargetRecord(
        source_name="Open Targets Platform",
        source_url="https://api.platform.opentargets.org/api/v4/graphql",
        identifiers=TargetIdentifiers(approved_symbol="IL6R", ensembl_gene_id="ENSG1"),
        association_score=0.84,
    )


def test_score_has_components_and_explanation():
    cfg = load_config()
    breakdown = score_target(
        _target(),
        weights=cfg.scoring["weights"],
        literature_weights=cfg.scoring["literature_components"],
        novelty_cfg=cfg.scoring["novelty"],
        literature=[],
        trials=[],
        drugs=[KnownDrug(name="tocilizumab", phase="4")],
        search_succeeded=True,
        condition_id="EFO_0000685",
    )
    assert "association" in breakdown.components
    assert breakdown.explanation
    assert breakdown.overall_score >= 0
    assert breakdown.novelty_category == NoveltyCategory.ESTABLISHED


def test_candidate_novel_requires_completeness():
    cat, text = classify_novelty(
        target=_target(),
        association=0.8,
        mechanistic=0.7,
        completeness=0.2,
        independent_sources=3,
        trials=[],
        drugs=[],
        search_succeeded=True,
        min_association_or_mechanistic=0.45,
        min_completeness=0.4,
        min_independent_sources=2,
    )
    assert cat == NoveltyCategory.INSUFFICIENT
    cat2, text2 = classify_novelty(
        target=_target(),
        association=0.8,
        mechanistic=0.7,
        completeness=0.9,
        independent_sources=3,
        trials=[],
        drugs=[],
        search_succeeded=True,
        min_association_or_mechanistic=0.45,
        min_completeness=0.4,
        min_independent_sources=2,
    )
    assert cat2 == NoveltyCategory.CANDIDATE_NOVEL
    assert "searched sources" in text2.lower()
