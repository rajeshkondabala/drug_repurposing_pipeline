# Ligand tables (local)

Do **not** commit cleaned ChEMBL dumps here. ChEMBL compound data is CC-BY-SA-3.0; bundling it in an Apache-2.0 source release has share-alike implications.

Generate locally:

```bash
python scripts/clean_chembl_ligands.py /path/to/Drugs_Chembl.csv --out-dir data/ligands
head -n 51 data/ligands/Drugs_Chembl.cleaned.csv > data/ligands/Drugs_Chembl.smoke50.csv
```

The platform default example ligands are `examples/input.csv` (two public SMILES for smoke tests).
