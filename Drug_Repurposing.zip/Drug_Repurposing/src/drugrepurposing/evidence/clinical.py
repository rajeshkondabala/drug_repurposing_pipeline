from __future__ import annotations

from drugrepurposing.schemas.evidence import ClinicalPhase, ClinicalTrialRecord

PHASE_SCORE = {
    ClinicalPhase.PHASE_4: 1.0,
    ClinicalPhase.PHASE_3: 0.85,
    ClinicalPhase.PHASE_2_3: 0.75,
    ClinicalPhase.PHASE_2: 0.6,
    ClinicalPhase.PHASE_1_2: 0.45,
    ClinicalPhase.PHASE_1: 0.3,
    ClinicalPhase.PRECLINICAL: 0.15,
    ClinicalPhase.NOT_APPLICABLE: 0.1,
    ClinicalPhase.UNKNOWN: 0.05,
}


def clinical_score(trials: list[ClinicalTrialRecord]) -> tuple[float, str]:
    if not trials:
        return 0.0, "No registered trials found in searched sources. Trial absence is not proof of novelty or failure."
    best = max(PHASE_SCORE.get(trial.phase, 0.05) for trial in trials)
    explanation = (
        f"{len(trials)} trial record(s) found. Highest normalized phase score is {best:.2f}. "
        "Trial existence does not imply clinical success."
    )
    return best, explanation
