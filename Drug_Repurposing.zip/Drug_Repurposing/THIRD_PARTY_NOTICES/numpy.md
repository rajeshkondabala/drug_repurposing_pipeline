NumPy — BSD-3-Clause
https://numpy.org/license.html

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the copyright notice and
disclaimer are retained.
